package da.ises.wikipedia.ui;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.swing.EventComboBoxModel;
import ca.odell.glazedlists.swing.EventSelectionModel;
import ca.odell.glazedlists.util.concurrent.Lock;
import com.jidesoft.popup.JidePopup;
import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.InformationObjectFactory;
import da.ises.magicmap.ui.information.search.WikipediaSearch;
import da.ises.magicmap.ui.util.PopupTextField;
import da.ises.magicmap.ui.extractor.ExtractorUI;
import da.ises.wikipedia.extractor.WikipediaExtractor;
import net.sf.magicmap.client.utils.AbstractModel;
import net.sf.magicmap.client.utils.DocumentAdapter;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.net.URLCodec;
import org.apache.commons.collections15.MultiMap;
import org.apache.commons.collections15.Predicate;
import org.apache.commons.collections15.multimap.MultiHashMap;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.io.IOException;
import java.util.List;

/**
 *
 */
public class WikipediaExtractorUI extends AbstractModel implements ExtractorUI {
    private WikipediaSearch search;
    private JList foundNamesList;
    private DocumentAdapter urlAdapter;
    private PopupTextField nameField;

    private Action action;
    private boolean valid;

    private BasicEventList<String> articleList = new BasicEventList<String>();
    private EventComboBoxModel<String> articleModel = new EventComboBoxModel<String>(articleList);
    private EventSelectionModel<String> selectedArticles = new EventSelectionModel<String>(articleList);
    private MultiMap<String, String> searchCache = new MultiHashMap<String, String>();
    private String currentUrl;
    private final WikipediaExtractor wikipediaExtractor;

    private final JidePopup popup = new JidePopup();
        final URLCodec codec = new URLCodec();

    private long typeTimeLast = -1;
    private boolean terminated = false;
    private final Object keyThread = new Object();

    private final Runnable keyWatcher = new Runnable() {
        public void run() {
            while (!terminated) {
                if (nameField.hasFocus())  {
                    final long now = System.currentTimeMillis();
                    long delta = now - typeTimeLast;
                    String text = nameField.getText();
                    if (delta > 500 && text != null && !text.equals(currentUrl) && text.length() > 0) {
                        searchArticles(nameField.getText());
                        checkValid();
                    }
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        synchronized (keyThread) {
                            System.out.print("Nunanna wait");
                            keyThread.wait();
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace(); 
                    }
                }
            }
        }
    };

    public WikipediaExtractorUI(String lang, WikipediaExtractor wikipediaExtractor) {
        this.wikipediaExtractor = wikipediaExtractor;
        search = new WikipediaSearch(lang);
        nameField = new PopupTextField(popup);
        urlAdapter = new DocumentAdapter(nameField) {
            public void handleChange(String s) {
                typeTimeLast = System.currentTimeMillis();
            }
        };

        foundNamesList = new JList(articleModel);
        foundNamesList.setSelectionModel(selectedArticles);
        foundNamesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        foundNamesList.setFocusable(true);
        popup.getContentPane().add(foundNamesList);
        
        selectedArticles.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        EventList<String> selected = selectedArticles.getSelected();
                        if (selected.size() == 1) {
                            urlAdapter.setDocumentContents(selectedArticles.getSelected().get(0));
                            checkValid();
                        }
                    }
                });

            }
        });



        nameField.setShowPopupPredicate(new Predicate() {
            public boolean evaluate(Object o) {
                return articleList.size() > 0;
            }
        });

        nameField.setKeyUpAction(new Runnable() {
            public void run() {
                if (articleList.size() == 0) return;
                int index = Math.max(selectedArticles.getLeadSelectionIndex()-1, 0);
                foundNamesList.setSelectedIndex(index);
                System.out.println("index = " + index);

            }
        });
        nameField.setKeyDownAction(new Runnable() {
            public void run() {
                if (articleList.size() == 0) return;
                int index = Math.min(selectedArticles.getLeadSelectionIndex()+1, articleList.size()-1);
                foundNamesList.setSelectedIndex(index);
                System.out.println("index = " + index);

            }
        });


        popup.setOwner(nameField);
        popup.setResizable(true);
        popup.setMovable(false);
        popup.setAttachable(true);
        new Thread(keyWatcher).start();
        nameField.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                synchronized (keyThread) {
                    keyThread.notify();
                }                
            }

            public void focusLost(FocusEvent e) {
                synchronized (keyThread) {
                    keyThread.notify();
                }
            }
        });
    }


    /**
     *
     * @param name
     */
    private void searchArticles(final String name) {
        if (currentUrl != null && currentUrl.equals(name)) return;
        currentUrl = name;
        if (name != null && name.length() >= 1) {

            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    Lock lock = articleList.getReadWriteLock().writeLock();
                    try {
                        lock.lock();
                        articleList.clear();
                        if (searchCache.containsKey(name)) {
                            articleList.addAll(searchCache.get(name));
                        } else {
                            List<String> foundArticles = search.search(codec.encode(name));
                            articleList.addAll(foundArticles);
                            searchCache.putAll(name,foundArticles);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        articleList.clear();
                        action.setEnabled(false);
                    } catch (EncoderException e) {
                        e.printStackTrace();
                    } finally {
                        lock.unlock();
                        checkValid();
                        if (!popup.isPopupVisible()) {
                            popup.showPopup(nameField);
                        }
                    }
                }
            });
        }
    }

    /**
     *
     */                 
    private void checkValid() {
        String text = nameField.getText();
        if (articleList.contains(text)){
            nameField.setBackground(Color.WHITE);
            setValid(true);
            foundNamesList.setSelectedIndex(articleList.indexOf(text));
        } else {
            nameField.setBackground(Color.RED);
            setValid(false);
        }

    }

    private void setValid(boolean valid) {
        if (this.valid != valid) {
            this.valid = valid;
            this.action.setEnabled(valid);
            firePropertyChange("valid", !valid, valid);
        }
    }

    public boolean isValid() {
        return valid;
    }

    public String getName() {
        return "Geben Sie einen WikipediaFactory Artikel ein";
    }

    public String getDescription() {
        return "Eine Artikel aus der WikipediaFactory";
    }

    public JComponent getView() {
        return nameField;
    }

    /**
     * 
     * @return
     */
    public InformationObject load(InformationObjectFactory factory) throws IOException {
        return wikipediaExtractor.load(getUrl(),factory);
    }


    public String getUrl() {
        try {
            return "http://de.wikipedia.org/wiki/" + codec.encode(urlAdapter.getDocumentContents());
        } catch (EncoderException e) {
            throw new IllegalStateException("Java.... my gosh! " + e.getMessage());
        }

    }

    public void setLoadAction(Action action) {
        this.action = action;
    }

   
}
