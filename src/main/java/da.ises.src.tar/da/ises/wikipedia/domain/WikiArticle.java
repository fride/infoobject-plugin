package da.ises.wikipedia.domain;

/**
 * 
 */
public class WikiArticle extends WikiPage{

    public WikiArticle(String title, Wikipedia wikipedia) {
        super(title, wikipedia);
    }

    public Type getPageType() {
        return Type.ARTICLE;
    }
    
}
