package da.ises.wikipedia.domain;

import java.util.Set;
import java.util.HashSet;

/**
 * 
 */
public abstract class WikiPage {
    private final String title;

    private final Wikipedia wikipedia;

    private Set<String> categories = new HashSet<String>();
    public enum Type {
        ARTICLE,
        CATEGORY,
        SPECIAL,
        USER

    }

    public WikiPage(String title, Wikipedia wikipedia) {
        this.title = title;
        this.wikipedia = wikipedia;
    }

    public String getTitle() {
        return title;
    }

    public WikiCategory addCategory(String title) {
        WikiCategory category = (WikiCategory) wikipedia.add(title, Type.CATEGORY);
        wikipedia.addCategory(category, this);
        return category;
    }
    public Set<WikiCategory> getCategories() {
        return new HashSet<WikiCategory>(wikipedia.getCategories(this));
    }

    public Wikipedia getWikipedia() {
        return wikipedia;
    }

    public abstract Type getPageType();
}
