package da.ises.wikipedia.domain;


import org.bushe.swing.event.EventBus;
import org.apache.commons.collections15.MultiMap;
import org.apache.commons.collections15.multimap.MultiHashMap;

import java.net.URL;
import java.net.MalformedURLException;
import java.util.*;

import da.ises.magicmap.ui.log.LogEvent;

/**
 * 
 */
public class Wikipedia {

    private String language;
    private Map<String, WikiArticle> articles = new HashMap<String, WikiArticle>();
    private Map<String, WikiCategory> categories = new HashMap<String, WikiCategory>();
    private MultiMap<String, WikiCategory> pagecategories = new MultiHashMap<String, WikiCategory>();
    private MultiMap<String, WikiPage> categoryPages = new MultiHashMap<String, WikiPage>();
    // cache for categories

    /**
     * 
     * @param language
     */
    public Wikipedia(String language) {
        this.language = language;
    }

    public URL getPageUrl(String page) {
        try {
            return new URL(getBaseUri() + "/" + page);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }


    public URL getBaseUri() {
        try {
            return new URL("http://" + language + ".wikipedia.org/wiki");
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    public WikiCategory getCategory(String title) {
        return categories.get(title);
    }
    public WikiArticle getArticle(String title) {
        return articles.get(title);
        
    }
    public WikiPage add(String title, WikiPage.Type type) {
        WikiPage page = null;
        switch (type){
            case ARTICLE:
                if (articles.containsKey(title)) {
                    page = articles.get(title);
                } else {
                    page = new WikiArticle(title,this);
                    articles.put(title, (WikiArticle) page);
                    EventBus.publish(new LogEvent("New wiki article " + title, LogEvent.Type.INFO));
                }
                break;
            case CATEGORY:
                if (categories.containsKey(title)) {
                    page = categories.get(title);
                } else {
                    page = new WikiCategory(title,this);
                    categories.put(title, (WikiCategory) page);
                    EventBus.publish(new LogEvent("New wiki category " + title, LogEvent.Type.INFO));
                }
                break;
        }

        return page;
    }

    public Set<WikiCategory> getCategories(WikiPage wikiPage) {
        return new HashSet<WikiCategory>(pagecategories.get(wikiPage.getTitle()));
    }

    public Set<WikiPage> getArticles(WikiCategory wikiCategory) {
        return new HashSet<WikiPage>(categoryPages.get(wikiCategory.getTitle()));
    }

    void addCategory(WikiCategory category, WikiPage wikiPage) {
        categoryPages.put(category.getTitle(), wikiPage);
        pagecategories.put(wikiPage.getTitle(), category);
    }
}
