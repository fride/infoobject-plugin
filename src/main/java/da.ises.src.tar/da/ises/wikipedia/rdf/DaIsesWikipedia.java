package da.ises.wikipedia.rdf;

/**
 * Vocabulary
 */
public class DaIsesWikipedia {
    
}
