package da.ises.wikipedia.rdf;

import org.openrdf.model.ValueFactory;
import org.openrdf.model.URI;
import org.openrdf.model.impl.ValueFactoryImpl;

/**
 * 
 */
public class WikiOnt {
    public static final String NAMESPACE = "http://fake.onto#";

    public static final URI Category;
    public static final URI Article;
    public static final URI User;
    public static final URI hasArticle;
    public static final URI hasCategory;

    static {
        ValueFactory factory = new ValueFactoryImpl();
        Category = factory.createURI(NAMESPACE, "Category");
        Article = factory.createURI(NAMESPACE, "Article");
        User = factory.createURI(NAMESPACE, "Agent");
        hasArticle = factory.createURI(NAMESPACE, "hasArticle");
        hasCategory = factory.createURI(NAMESPACE, "hasCategory");
    }


}
