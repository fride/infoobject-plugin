package da.ises.wikipedia;

import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.facet.FacetHandler;
import da.ises.core.facet.FacetHandlerRegistry;
import da.ises.core.extractor.ExtractorListener;
import da.ises.magicmap.ui.util.HtmlSaxParserFactory;
import da.ises.wikipedia.domain.WikiPage;
import da.ises.wikipedia.domain.Wikipedia;
import da.ises.wikipedia.extractor.WikipediaExtractor;
import da.ises.wikipedia.rdf.WikiOnt;
import da.ises.wikipedia.ui.WikipediaExtractorUI;
import net.sf.magicmap.client.utils.HtmlSaxParser;
import org.openrdf.model.Graph;
import org.openrdf.model.Statement;
import org.openrdf.model.URI;
import org.openrdf.model.impl.URIImpl;
import org.openrdf.model.vocabulary.RDF;

import java.util.Iterator;

/**
 *
 */
public class WikipediaFactory {

    private WikipediaExtractor extractor;
    private final HtmlSaxParser parser;
    private WikipediaExtractorUI ui;
    private Wikipedia wiki = new Wikipedia("de");

    private FacetHandler handler = new FacetHandler() {
        public boolean canHandle(InformationObject object) {
            return object.getFacetTypes().contains("wikipedia");
        }

        public void handle(InformationObject object) {

        }
    };

    static WikipediaFactory instance;


    private final ExtractorListener extrctorListene  = new ExtractorListener() {
        public void extractionSarted(InformationObject object) {

        }

        public void extractionFinished(InformationObject object) {
            if (object.getFacetTypes().contains(WikipediaExtractor.WIKIPEDIA_FACET)) {
                addWikiPage(object);
            }
        }

        public void extractionFailed(InformationObject object) {

        }
    };

    private void addWikiPage(InformationObject object) {
        URI uri = new URIImpl(object.getId());
        Graph metaData = object.getMetaData();
        String title = object.getTitle().getTitle();
        WikiPage page = null;
        if (metaData.match(uri, RDF.TYPE, WikiOnt.Article).hasNext()){
            page = wiki.add(title, WikiPage.Type.ARTICLE);
        } else if (metaData.match(uri, RDF.TYPE, WikiOnt.Category).hasNext()){
            page = wiki.add(title, WikiPage.Type.CATEGORY);
        }
        if (page != null) {
            Iterator<Statement> statements = metaData.match(uri, WikiOnt.hasCategory, null);
            while (statements.hasNext()) {
                page.addCategory(statements.next().getObject().stringValue());
            }
        }
    }

    public static WikipediaFactory get() {
        if (instance == null) {
            instance = new WikipediaFactory(HtmlSaxParserFactory.getSaxParser());
        }
        return instance;
    }

    private  WikipediaFactory(HtmlSaxParser parser) {
        this.parser = parser;
        FacetHandlerRegistry.get().register(handler);
    }

    public WikipediaExtractor getWikipediaExtractor() {
        if (extractor == null) {
            extractor = new WikipediaExtractor();
            extractor.addExtractorListener(extrctorListene);
        }
        return extractor;
    }

    /**
     *
     * @return
     */
    public WikipediaExtractorUI getWikipediaExtractorUI() {
        if (ui == null) {
            ui = new WikipediaExtractorUI("de",getWikipediaExtractor());
        }
        return ui;
    }
}
