package da.ises.wikipedia.extractor;

import da.ises.core.domain.entity.MimeType;
import da.ises.core.domain.entity.Title;
import da.ises.core.domain.entity.Version;
import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.InformationObjectFactory;
import da.ises.core.extractor.AbstractHtmlExtractor;
import da.ises.core.extractor.DataSource;
import da.ises.core.extractor.ExtractorListener;
import da.ises.wikipedia.rdf.WikiOnt;
import org.dom4j.Document;
import org.dom4j.Node;
import org.openrdf.model.Graph;
import org.openrdf.model.URI;
import org.openrdf.model.ValueFactory;
import org.openrdf.model.impl.GraphImpl;
import org.openrdf.model.impl.URIImpl;
import org.openrdf.model.vocabulary.RDF;
import org.openrdf.model.vocabulary.RDFS;

import java.io.IOException;
import java.net.URL;
import java.util.List;

/**
 *
 */
public class WikipediaExtractor extends AbstractHtmlExtractor {


    private String categoriesPath= "//*[@id='mw-normal-catlinks']/*[name()='span' and position() > 1]/*[name()='a']";
    private String chekWikiPagePath= "//*[name()='body' and contains(concat(' ', @class, ' '), ' mediawiki ')]";
    public static final String WIKIPEDIA_FACET = "wikipedia";


    /**
     *
     * @param uri
     * @param factory
     * @return
     */
    public InformationObject load(String uri, InformationObjectFactory factory) throws IOException {
        final InformationObject information = factory.createInformationObject(uri);
        final Version version = information.getVersion();
        final Graph g = new GraphImpl();
        if (version == null) {
            load(information, g);
        }
        return information;

    }

    /**
     *
     * @param information an information.
     * @param graph graph to put metadat in
     * @throws java.io.IOException  ...
     */
    @SuppressWarnings({"unchecked"})
    private void load(InformationObject information, Graph graph) throws IOException {
        for (ExtractorListener l : getExtractorListeners()){
            l.extractionFinished(information);
        }
        URI uri = new URIImpl(information.getId());
        DataSource dataSource = new DataSource(new URL(uri.toString()));

        if (!"text/html".equals(dataSource.getMimeType())){
            throw new IOException("Cant extract Mime: " + dataSource.getMimeType());
        }
        //ValueFactory factory = graph.getValueFactory();

        try {
            information.setSize(dataSource.getContentsSize());
            information.setMimeType(MimeType.mimeType(dataSource.getMimeType()));
            Document xml = getDocument(dataSource);


            System.out.println("xml.asXML() = " + xml.asXML());
            checkMediaWiki(xml);



            //String title = xml.valueOf("//*[@id='content']/*[name()='h1']");
            String title = xml.valueOf("//*[name()='title']");
            if (title == null || title.length() < 1) {
                throw new IllegalArgumentException("Not a valid wiki page") ;
            }

            information.getFacetTypes().add(WIKIPEDIA_FACET);
            String english = xml.valueOf("//*[@class='interwiki-en']/*[name()='a']/@href");
            if (english != null && english.length() > 0) {
                getRdf(english, graph);
            }
            information.setTitle(Title.title(title));
            System.out.println(xml.asXML());

            ValueFactory factory = information.getMetaData().getValueFactory();
            if (null != xml.selectSingleNode("//*[@id='ca-nstab-category']")){
                information.getMetaData().add(uri, RDF.TYPE, WikiOnt.Category);    
            }
            else if (null != xml.selectSingleNode("//*[@id='ca-nstab-main']")){
                information.getMetaData().add(uri, RDF.TYPE, WikiOnt.Article);                
            }
            else if (null != xml.selectSingleNode("//*[@id='ca-nstab-user']")){
                information.getMetaData().add(uri, RDF.TYPE, WikiOnt.User);                
            }
            List<Node> nodeList = xml.selectNodes(categoriesPath);


            for (Node node:nodeList) {
                URL url = new URL(dataSource.getUrl(), node.valueOf("@href"));
                String categoryTitle = node.valueOf("substring-after(@title, ':')");
                URI categoryUri = factory.createURI(url.toString());

                information.getMetaData().add(categoryUri, RDF.TYPE, WikiOnt.Category);
                information.getMetaData().add(categoryUri, WikiOnt.hasArticle, uri);
                information.getMetaData().add(categoryUri, RDF.TYPE, WikiOnt.Category);
                information.getMetaData().add(uri, WikiOnt.hasCategory, categoryUri);
                information.getMetaData().add(categoryUri, RDFS.LABEL, factory.createLiteral(categoryTitle));

            }
            //information.getMetaData().add(information.getResourceId(), DaIsesInfo.Facet, factory.createLiteral(WIKIPEDIA_FACET));
            for (ExtractorListener l : getExtractorListeners()){
                l.extractionFinished(information);
            }

        } catch (Exception e) {
            for (ExtractorListener l : getExtractorListeners()){
                l.extractionFailed(information);
            }
            throw new IOException("Cant parse XML: " + e.getMessage());
        } finally{
            dataSource.dispose();
        }
    }

    private boolean checkMediaWiki(Document xml) {
        String name = xml.valueOf("//title/meta[@name='generator']/@content");
        return name != null && name.toLowerCase().startsWith("mediawiki");
    }

    private void getRdf(String english, Graph graph) {

    }

    public static void main(String[] args) throws IOException {

        WikipediaExtractor extractor = new WikipediaExtractor();
        InformationObject object = new InformationObject("http://de.wikipedia.org/wiki/Berlin");
        extractor.load(object,new GraphImpl());
        System.out.println("object = " + object.getMetaData());


    }
}
