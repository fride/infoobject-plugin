package da.ises.wikipedia.extractor;

import da.ises.core.rdf.RDFContainer;
import da.ises.html.base.extractor.XmlHandler.XsltExtractor;
import org.dom4j.Document;

import java.io.IOException;
import java.net.URL;

/**
 * <p>
 * Class MediaWikiXsltExtractor ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 02.08.2008
 *         Time: 13:57:48
 */
public class MediaWikiXsltExtractor implements XsltExtractor {

    public String getName() {
        return "html/mediawiki";
    }

    public URL getXsltResource() {
        return getClass().getClassLoader().getResource("da/ises/xslt/mediawiki.xsl");
    }

    /**
     * @param object
     * @param document
     * @throws java.io.IOException
     */
    public void extract(RDFContainer object, Document document) throws IOException {
        System.out.println("document = " + document.asXML());

    }
}