package da.ises.openrdf.repository.bindingset;

import da.ises.core.infoobject.Tagging;
import org.apache.commons.collections15.Transformer;
import org.openrdf.model.Literal;
import org.openrdf.query.BindingSet;

/**
 * <p>
 * Class TaggingTransformer ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 23:29:03
 */
public class TaggingTransformer implements Transformer<BindingSet, Tagging> {


    public Tagging transform(BindingSet binding) {
        Tagging tagging = null;
        if (binding.hasBinding("tagged")){
            String tagged = binding.getBinding("tagged").getValue().stringValue();
            String agentid = binding.getBinding("tag_creator").getValue().stringValue();
            String tag = binding.getBinding("raw").getValue().stringValue();
            boolean positive = ((Literal)binding.getBinding("positive").getValue()).booleanValue();

            tagging = new Tagging(tagged, tag, positive, agentid);
            tagging.setId(binding.getBinding("tagging").getValue().stringValue());
        }
        return tagging;
    }
}
