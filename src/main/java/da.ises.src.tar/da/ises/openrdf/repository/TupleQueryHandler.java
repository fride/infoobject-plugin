package da.ises.openrdf.repository;

/**
 * <p>
 * Class TupleQueryHandler ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 21:56:56
 */
public interface TupleQueryHandler {


}
