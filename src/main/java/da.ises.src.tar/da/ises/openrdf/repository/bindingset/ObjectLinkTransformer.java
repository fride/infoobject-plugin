package da.ises.openrdf.repository.bindingset;

import da.ises.core.infoobject.ObjectLink;
import da.ises.core.infoobject.ObjectName;
import org.apache.commons.collections15.Transformer;
import org.openrdf.query.BindingSet;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * <p>
 * Class ObjectLinkTransformer ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 23:30:58
 */
public class ObjectLinkTransformer implements Transformer<BindingSet, ObjectLink> {
    final Map<String, ObjectLink> objects = new HashMap<String, ObjectLink>();

    public ObjectLink transform(BindingSet binding) {
        String id = binding.getValue("link").stringValue();
        boolean created = false;
        ObjectLink objectLink = objects.get(id);
        if (objectLink == null){
            created = true;
            objectLink = new ObjectLink();
            objectLink.setUri(binding.getValue("info").stringValue());
            objectLink.setObject(ObjectName.fromUri(binding.getValue("linked_object").stringValue()));
            objectLink.setAgentId(binding.getValue("link_creator").stringValue());
            objectLink.setLinkTypes(new HashSet<String>());
            objects.put(id,objectLink);

        }
        if (binding.hasBinding("link_type")){
            objectLink.getLinkTypes().add(binding.getValue("link_type").stringValue());
        }
        return created ? objectLink : null;
    }
    public Collection<ObjectLink> getLinks(){
        return objects.values();
    }

}
