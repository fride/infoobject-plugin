package da.ises.openrdf.repository;

import da.ises.core.domain.entity.Description;
import da.ises.core.domain.entity.Title;
import da.ises.core.domain.user.Agent;
import da.ises.core.infoobject.*;
import da.ises.openrdf.util.OpenRdfTemplate;
import da.ises.openrdf.util.BindingSetMapper;
import da.ises.openrdf.util.RdfException;
import da.ises.openrdf.repository.bindingset.InformationObject2Transformer;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryException;
import org.openrdf.repository.sail.SailRepository;
import org.openrdf.rio.RDFHandlerException;
import org.openrdf.rio.n3.N3Writer;
import org.openrdf.sail.memory.MemoryStore;
import org.openrdf.query.BindingSet;
import org.antlr.stringtemplate.StringTemplateGroup;
import org.antlr.stringtemplate.StringTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * <p>
 * Class ObjectRdfInformationObjectRepository ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 21:31:15
 */
public class ObjectRdfInformationObjectRepository implements InformationObjectRepository {
    private InformationDataDao informationDataDao;
    private TaggingDao taggingDao;
    private ObjectLinkDao objectLinkDao;
    private Repository repository;
    private OpenRdfTemplate rdfTemplate;
    static StringTemplateGroup templates = new StringTemplateGroup("queries");

    /**
     * 
     * @param repository
     * @throws RepositoryException
     */
    public ObjectRdfInformationObjectRepository(Repository repository) throws RepositoryException {
        this.repository = repository;
        rdfTemplate = new OpenRdfTemplate();
        rdfTemplate.setRepository(repository);
        this.repository.initialize();
        informationDataDao = new InformationDataDao(repository);
        taggingDao = new TaggingDao(repository);
        objectLinkDao = new ObjectLinkDao(repository);
    }


    /**
     * @param name
     * @return
     */
    public List<InformationObject2> findInformationsByObject(ObjectName name) {
        StringTemplate objectTemplate = templates.getInstanceOf("da/ises/query/informationobject");

        objectTemplate.setAttribute("POSITION", name.toString());
        String query = objectTemplate.toString();
        System.out.println("query = " + query);


        final InformationObject2Transformer tr = new InformationObject2Transformer();
        try {
            return this.rdfTemplate.queryList(query, new BindingSetMapper<InformationObject2>() {
                public InformationObject2 map(BindingSet binding, int row) {
                    System.out.println(
                            "real_object = " + binding.getValue("real_object") + " => " +
                            binding.getValue("info").stringValue());

                    return tr.transform(binding);
                }
            });
        } catch (RdfException e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * @param tags
     * @return
     */
    public List<InformationObject2> findTaggings(Iterable<Tag> tags) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<Tag> findTags(){
        return this.taggingDao.findTags();
    }

    
    /**
     * Publish the taggings.
     * @param taggings
     * @param title
     * @param description
     */
    public void publishTaggings(Iterable<Tagging> taggings, Title title, Description description){
        for (Tagging tagging: taggings){
            taggingDao.set(tagging);
        }
        taggingDao.commit();
    }

    

    /**
     * 
     * @param links
     */
    public void publishObjectLinks(Iterable<ObjectLink> links){
        for (ObjectLink link:links){
            objectLinkDao.set(link);
        }
        objectLinkDao.commit();
    }

    public void publishInformations(Iterable<InformationData> data){
        for (InformationData d:data){
            this.informationDataDao.set(d);
        }
        this.informationDataDao.commit();
    }
    public void deleteTagging(Tagging tagging){

    }


    public static void main(String[] args) throws RepositoryException, RDFHandlerException {
        Repository r = new SailRepository(new MemoryStore());
        ObjectRdfInformationObjectRepository repos = new ObjectRdfInformationObjectRepository(r);

        ArrayList<Tagging> dao = new ArrayList<Tagging>();
        dao.add(new Tagging("http://www.heise.de", "Zeitung", true, "jabber:jan@googlemail.com"));
        dao.add(new Tagging("http://www.heise.de", "Zeitschrift", true, "jabber:jan@googlemail.com"));
        dao.add(new Tagging("http://www.heise.de", "Online", true, "jabber:jan@googlemail.com"));
        dao.add(new Tagging("http://www.heise.de", "Deutsch", true, "jabber:jan@googlemail.com"));
        dao.add(new Tagging("http://www.heise.de", "Trollwiese", true, "jabber:jan@googlemail.com"));
        dao.add(new Tagging("http://www.heise.de", "IT", true, "jabber:jan@googlemail.com"));

        dao.add(new Tagging("http://www.heise.de", "Zeitschrift", false, "jabber:niemand@googlemail.com"));
        dao.add(new Tagging("http://www.heise.de", "Trollwiese", true, "jabber:niemand@googlemail.com"));


        dao.add(new Tagging("http://www.golem.de", "Zeitschrift", false, "jabber:niemand@googlemail.com"));
        dao.add(new Tagging("http://www.golem.de", "Trollwiese", true, "jabber:niemand@googlemail.com"));
        dao.add(new Tagging("http://www.golem.de", "IT", true, "jabber:niemand@googlemail.com"));

        dao.add(new Tagging("http://friderici.net", "IT", true, "jabber:niemand@googlemail.com"));
        dao.add(new Tagging("http://friderici.net", "Java", true, "jabber:jan@googlemail.com"));
        dao.add(new Tagging("http://friderici.net", "Len", true, "jabber:kerstin@googlemail.com"));
        dao.add(new Tagging("http://friderici.net", "Jabba", true, "jabber:len@googlemail.com"));

        repos.publishTaggings(dao,null,null);

        ObjectLink link = new ObjectLink();
        link.setAgentId("jan@googlemail.com");
        link.setObject(ObjectName.positionName("client2", "http:/www.de"));
        link.setUri("http://friderici.net");
        link.getLinkTypes().add("Homepage");
        link.getLinkTypes().add("Meine");
        link.getLinkTypes().add("So was");
        link.setCreator(Agent.ANONYMOUS);

        repos.publishObjectLinks(Collections.singletonList(link));
        link.getLinkTypes().remove("Meine");
        repos.publishObjectLinks(Collections.singletonList(link));


        link = new ObjectLink();
        link.setAgentId("len@googlemail.com");
        link.setObject(ObjectName.positionName("client31", "http:/www.de"));
        link.setUri("http://www.heise.de");
        link.getLinkTypes().add("Verlagssitz");
        link.getLinkTypes().add("Firmensitz");
        link.setCreator(Agent.ANONYMOUS);

        repos.publishObjectLinks(Collections.singletonList(link));


        link = new ObjectLink();
        link.setAgentId("len@googlemail.com");
        link.setObject(ObjectName.positionName("client1", "http:/www.de"));
        link.setUri("http://www.heise.de");
        link.getLinkTypes().add("Verlagssitz");
        link.getLinkTypes().add("Firmensitz");
        link.setCreator(Agent.ANONYMOUS);

        repos.publishObjectLinks(Collections.singletonList(link));


        link = new ObjectLink();
        link.setAgentId("len@googlemail.com");
        link.setObject(ObjectName.positionName("client1", "http:/www.de"));
        link.setUri("http://www.golem.de");
        link.getLinkTypes().add("Verlagssitz");
        link.getLinkTypes().add("Firmensitz");
        link.setCreator(Agent.ANONYMOUS);

        repos.publishObjectLinks(Collections.singletonList(link));

        r.getConnection().export(new N3Writer(System.out));

        final List<InformationObject2> list = repos.findInformationsByObject(link.getObject());
        System.out.println(list);

    }

}
