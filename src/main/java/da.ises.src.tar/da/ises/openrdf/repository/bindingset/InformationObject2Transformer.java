package da.ises.openrdf.repository.bindingset;

import da.ises.core.infoobject.Tagging;
import da.ises.core.infoobject.ObjectLink;
import da.ises.core.infoobject.InformationObject2;
import da.ises.core.infoobject.InformationData;
import org.apache.commons.collections15.Transformer;
import org.openrdf.query.BindingSet;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * Class InformationObject2Transformer ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 23:33:19
 */
public class InformationObject2Transformer implements Transformer<BindingSet, InformationObject2> {
    final TaggingTransformer taggingTransformer = new TaggingTransformer();
    final ObjectLinkTransformer objectLinkTransformer = new ObjectLinkTransformer();
    final Map<String, InformationObject2> infoMap = new HashMap<String, InformationObject2>();


    public InformationObject2Transformer() {
    }

    public InformationObject2 transform(BindingSet bindingSet) {
        final String infoUri = bindingSet.getValue("info").stringValue();
        InformationObject2 info = infoMap.get(infoUri);
        boolean newInfo = info == null;
        if (newInfo){
            info = new InformationObject2();
            info.setMetadata(new InformationData());
            info.getMetadata().setUri(infoUri);
            infoMap.put(infoUri,info);

        }
        
        final Tagging tagging = taggingTransformer.transform(bindingSet);
        if (tagging != null){
            info.getTaggings().put(tagging.getId(),tagging);
        }
        final ObjectLink objectLink = objectLinkTransformer.transform(bindingSet);
        if (objectLink != null) {
            info.getObjectLinks().put(objectLink.getObject(), objectLink);
        }
        return newInfo ? info : null;
    }

}
