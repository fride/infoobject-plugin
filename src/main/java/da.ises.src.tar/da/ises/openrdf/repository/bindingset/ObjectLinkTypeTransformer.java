package da.ises.openrdf.repository.bindingset;

import org.apache.commons.collections15.Transformer;
import org.openrdf.query.BindingSet;

/**
 * <p>
 * Class ObjectLinkTypeTransformer ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 23:48:21
 */
public class ObjectLinkTypeTransformer implements Transformer<BindingSet, String>{
    public String transform(BindingSet bindingSet) {
        return  (bindingSet.hasBinding("link_type")) ?
            bindingSet.getValue("link_type").stringValue()
        : null;
    }
}
