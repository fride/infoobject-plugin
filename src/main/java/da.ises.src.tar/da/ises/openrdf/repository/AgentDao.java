package da.ises.openrdf.repository;

import da.ises.core.domain.user.Agent;
import da.ises.core.rdf.voc.FOAF;
import da.ises.core.rdf.voc.InformationObjectVoc;
import da.ises.openrdf.util.ConnectionCallback;
import da.ises.openrdf.util.RdfException;
import da.ises.openrdf.util.BindingSetMapper;
import org.openrdf.model.Literal;
import org.openrdf.model.BNode;
import org.openrdf.model.vocabulary.RDF;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.query.BindingSet;

import java.util.List;

/**
 * <p>
 * Class TagDao ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 20:19:03
 */
public class AgentDao extends OpenRdfDao<Agent>{
    public AgentDao(Repository repos) {
        super(repos);
    }

    /**
     * @param entity
     */
    public void set(Agent agent) {
        final BNode agentNode = getRdfTemplate().createBNode();
        final Literal name = getRdfTemplate().createLiteral(agent.getUserName());
        final Literal id = getRdfTemplate().createLiteral(agent.getUserName());


        try {
            getRdfTemplate().withConnection(new ConnectionCallback() {
                public void doInConnection(RepositoryConnection cnx) throws Exception {
                    cnx.add(agentNode, RDF.TYPE, FOAF.AGENT);
                    cnx.add(agentNode, InformationObjectVoc.magicAgentId, id);
                }
            });
        } catch (RdfException e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * @return
     */
    public List<Agent> findAll() {
        String query = getQueryPrefix() +
                " select * where {[ a foaf:Agent] :magicAgentId ?id";

        try {
            return getRdfTemplate().queryList(query, new BindingSetMapper<Agent>() {
                public Agent map(BindingSet binding, int row) {
                    Agent agent = new Agent();
                    agent.setId(binding.getValue("id").stringValue());
                    return agent;
                }
            });
        } catch (RdfException e) {
            throw new IllegalStateException(e);
        }
    }
}
