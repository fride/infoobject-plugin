package da.ises.openrdf.repository;

import da.ises.core.infoobject.ObjectLink;
import da.ises.core.infoobject.ObjectName;
import da.ises.core.domain.user.Agent;
import da.ises.core.rdf.voc.DC;
import da.ises.core.rdf.voc.InformationObjectVoc;
import da.ises.core.util.Digest;
import da.ises.openrdf.util.BindingSetMapper;
import da.ises.openrdf.util.ConnectionCallback;
import da.ises.openrdf.util.RdfException;
import org.openrdf.model.URI;
import org.openrdf.model.ValueFactory;
import org.openrdf.model.vocabulary.RDF;
import org.openrdf.query.BindingSet;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.RepositoryException;
import org.openrdf.repository.sail.SailRepository;
import org.openrdf.rio.RDFHandlerException;
import org.openrdf.rio.n3.N3Writer;
import org.openrdf.sail.memory.MemoryStore;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Class ObjectLinkDao ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 20:35:08
 */
public class ObjectLinkDao extends OpenRdfDao<ObjectLink>{

    private final String linkUri = "http://www.magicmap.de/objectlink/";

    public ObjectLinkDao(Repository repos) {
        super(repos);
    }

    /**
     * @param link
     */
    public void set(final ObjectLink link) {
        final ValueFactory factory = getRdfTemplate().getValueFactory();
        final URI objectId = link.getObject().getNodeUri(factory);
        final URI infoUri = getRdfTemplate().createURI(link.getUri());
        final URI linkNode = getRdfTemplate().createURI(linkUri, Digest.md5(link.getUri(), objectId.toString()));
        try {
            getRdfTemplate().withConnection(new ConnectionCallback() {
                public void doInConnection(RepositoryConnection cnx) throws Exception {
                    cnx.remove(linkNode,null,null);
                    cnx.add(linkNode, RDF.TYPE, InformationObjectVoc.ObjectLink);
                    cnx.add(linkNode, InformationObjectVoc.hasInformation, infoUri);
                    cnx.add(linkNode, InformationObjectVoc.hasObject, objectId);
                    cnx.add(linkNode, DC.creator, getAgentUri(link.getCreator()));
                    cnx.add(infoUri, InformationObjectVoc.hasObjectLink, linkNode);
                    for (String type: link.getLinkTypes()){
                        cnx.add(linkNode, InformationObjectVoc.linkType, factory.createLiteral(type));
                    }
                }
            });
        } catch (RdfException e) {
            throw new IllegalArgumentException(e);
        }

    }

    /**
     * @return
     */
    public List<ObjectLink> findAll() {
        final Map<String, ObjectLink> objects = new HashMap<String, ObjectLink>();
        String query = getQueryPrefix() +
                " select * where {" +
                "   ?link a :ObjectLink; " +
                "       :hasInformation ?info; " +
                "       :hasObject ?position ;" +
                "       dc:creator ?creator ." +
                "   optional {" +
                "       ?link :linkType ?link_type ." +
                "   }" +
                "}";
        try {
            return getRdfTemplate().queryList(query, new BindingSetMapper<ObjectLink>() {
                public ObjectLink map(BindingSet binding, int row) {
                    String id = binding.getValue("link").stringValue();
                    boolean created = false;
                    ObjectLink objectLink = objects.get(id);
                    if (objectLink == null){
                        created = true;
                        objectLink = new ObjectLink();
                        objectLink.setUri(binding.getValue("info").stringValue());
                        objectLink.setObject(ObjectName.fromUri(binding.getValue("position").stringValue()));
                        objectLink.setAgentId(binding.getValue("creator").stringValue());
                        objectLink.setLinkTypes(new HashSet<String>());
                        objects.put(id,objectLink);

                    }
                    if (binding.hasBinding("link_type")){
                        objectLink.getLinkTypes().add(binding.getValue("link_type").stringValue());
                    }
                    return created ? objectLink : null;
                }
            });
        } catch (RdfException e) {
            throw new IllegalStateException(e);
        }
    }
    public static void main(String[] args) throws RepositoryException, RDFHandlerException {
        Repository repos = new SailRepository(new MemoryStore());
        repos.initialize();
        ObjectLinkDao dao = new ObjectLinkDao(repos);
        ObjectLink link = new ObjectLink();
        link.setAgentId("jan@googlemail.com");
        link.setObject(ObjectName.positionName("clident1", "http:/www.de"));
        link.setUri("http://friderici.net");
        link.getLinkTypes().add("Homepage");
        link.getLinkTypes().add("Meine");
        link.getLinkTypes().add("So was");
        link.setCreator(Agent.ANONYMOUS);
        dao.set(link);
        dao.commit();
        repos.getConnection().export(new N3Writer(System.out));

        System.out.println("link = " + dao.findAll());
    }


}
