package da.ises.openrdf.repository;

import da.ises.core.infoobject.InformationData;
import da.ises.core.rdf.voc.DC;
import da.ises.core.rdf.voc.InformationObjectVoc;
import da.ises.openrdf.util.ConnectionCallback;
import da.ises.openrdf.util.RdfException;
import org.openrdf.model.Literal;
import org.openrdf.model.URI;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;

import java.util.List;

/**
 * <p>
 * Class InformationMetaDao ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 21:06:50
 */
public class InformationDataDao extends OpenRdfDao<InformationData>{
    public InformationDataDao(Repository repos) {
        super(repos);
    }

    /**
     * @param entity
     */
    public void set(InformationData entity) {
        final URI infoUri = getRdfTemplate().createURI(entity.getUri());
        final Literal title = getRdfTemplate().createLiteral(entity.getTitle());
        final Literal size = getRdfTemplate().createLiteral(entity.getSize());
        final Literal crawlDate = getRdfTemplate().createLiteral(System.currentTimeMillis());

        try {
            getRdfTemplate().withConnection(new ConnectionCallback() {
                public void doInConnection(RepositoryConnection cnx) throws Exception {
                    cnx.add(infoUri, DC.Title,title);
                    cnx.add(infoUri, InformationObjectVoc.size, size);
                    cnx.add(infoUri, InformationObjectVoc.crawlDate, crawlDate);                    
                }
            });
        } catch (RdfException e) {
            throw new IllegalArgumentException(e);
        }


    }

    /**
     * @return
     */
    public List<InformationData> findAll() {
        return null;
    }
}
