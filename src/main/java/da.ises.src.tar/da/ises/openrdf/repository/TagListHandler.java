package da.ises.openrdf.repository;

import org.openrdf.query.BindingSet;
import org.openrdf.query.TupleQueryResultHandler;
import org.openrdf.query.TupleQueryResultHandlerException;

import java.util.List;
import java.util.LinkedList;

/**
 * <p>
 * Class TagListHandler ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 22:04:55
 */
public class TagListHandler implements TupleQueryResultHandler {

    private final List<String> tags = new LinkedList<String>();
    public void startQueryResult(List<String> strings) throws TupleQueryResultHandlerException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void endQueryResult() throws TupleQueryResultHandlerException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void handleSolution(BindingSet bindingSet) throws TupleQueryResultHandlerException {
        if (bindingSet.hasBinding("tag")){
            tags.add(bindingSet.getValue("tag").stringValue());
        }
    }

    public List<String> getTags() {
        return tags;
    }
}
