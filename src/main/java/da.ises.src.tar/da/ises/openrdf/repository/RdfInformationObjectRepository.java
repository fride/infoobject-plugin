package da.ises.openrdf.repository;

import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.Position;
import da.ises.core.domain.infoobject.PositionAnnotation;
import da.ises.core.domain.infoobject.TagAnnotation;
import da.ises.core.domain.repository.InformationObjectPosts;
import da.ises.core.domain.repository.InformationObjectRepository;
import da.ises.core.infoobject.Tag;
import da.ises.core.domain.user.Agent;
import da.ises.core.rdf.voc.DC;
import da.ises.core.rdf.voc.DaIses;
import da.ises.core.util.Digest;
import org.openrdf.model.*;
import org.openrdf.model.impl.GraphImpl;
import org.openrdf.model.vocabulary.RDF;
import org.openrdf.model.vocabulary.RDFS;
import org.openrdf.query.*;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.RepositoryException;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Class RdfInformationObjectRepository ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 21:55:39
 */
public class RdfInformationObjectRepository implements InformationObjectRepository {
    private Repository repository;
    private String jabberId;
    
    private String prefix =
            "prefix rdfs:   <http://www.w3.org/2000/01/rdf-schema#>\n" +
            "prefix rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n" +
            "prefix dc:     <http://purl.org/dc/elements/1.1/> \n" +
            "prefix :       <http://www.magicmap.de/2008/07/daises#> \n" +
            "prefix xmlns:       <http://www.w3.org/2001/XMLSchema#> \n" +
            "prefix owl: <http://www.w3.org/2002/07/owl#> \n" +
            "prefix skos: <http://www.w3.org/2004/02/skos/core#> \n";


    public RdfInformationObjectRepository(Repository repository) {
        this.repository = repository;
    }

    /**
     * 
     * @param queryStr
     * @param handler
     * @throws RepositoryException
     * @throws MalformedQueryException
     * @throws TupleQueryResultHandlerException
     * @throws QueryEvaluationException
     */
    public void query(String queryStr, TupleQueryResultHandler handler) throws RepositoryException{
        RepositoryConnection connection = null;
        try{
            connection =  repository.getConnection();
            System.out.println("" + prefix + queryStr);
            final TupleQuery query = connection.prepareTupleQuery(QueryLanguage.SPARQL,  queryStr);
            query.evaluate(handler);
        } catch (TupleQueryResultHandlerException e) {
            e.printStackTrace();
        } catch (MalformedQueryException e) {
            e.printStackTrace();
        } catch (QueryEvaluationException e) {
            e.printStackTrace();
        } finally {
            if (connection != null){
                connection.commit();
                connection.close();
            }
        }
    }

    /**
     * 
     * @param g
     * @param context
     * @throws RepositoryException
     */
    protected void addStatements(Graph g, Resource... context) throws RepositoryException {
        RepositoryConnection connection = null;
        try{
            connection =  repository.getConnection();
            if (context != null && context.length > 0){
                connection.add(g,context);
            } else {
                connection.add(g);
            }
        } catch (RepositoryException e) {
            e.printStackTrace();
        } finally {
            if (connection != null){
                connection.commit();
                connection.close();
            }
        }

    }
    protected void doQuery(String query, TupleQueryResultHandler handler){
        try {
            query(query, handler);
        } catch (RepositoryException e) {
            e.printStackTrace();
        } 
    }


    /**
     * Get an information and all its annotations  with the provided uri.
     *
     * @param uri the inormation objects uri.
     * @return an information object.
     */
    public InformationObjectPosts get(String uri) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * Create or saves a new information object.
     *
     * @param object the object to update or save
     * @return
     */
    public InformationObject set(InformationObject object) {
        Graph g = new GraphImpl();
        URI uri  = g.getValueFactory().createURI(object.getId());
        g.add(uri, RDF.TYPE, DaIses.InfoObject);
        if (object.getMimeType() != null){
            g.add(uri, DC.Format, g.getValueFactory().createLiteral(object.getMimeType().getMimeType()));
        }
        if (object.getTitle() != null){
            g.add(uri, RDFS.LABEL, g.getValueFactory().createLiteral(object.getTitle().getTitle()));
        }
        if (object.getSize() != null){
            g.add(uri, DaIses.objectSize, g.getValueFactory().createLiteral(object.getSize()));
        }
        try {
            addStatements(g);
        } catch (RepositoryException e) {
            e.printStackTrace();
        }
        return object;
    }

    /**
     * @param uri the infos uri.
     * @return an information object or null if none is known.
     */
    public InformationObject getInformation(String uri) {
        
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @param uri      the infos uri.
     * @param position the position.
     * @return
     */
    public PositionAnnotation set(String uri, PositionAnnotation annotation) {
        Graph g = new GraphImpl();
        final ValueFactory factory = g.getValueFactory();
        final URI infoUri = factory.createURI(uri);
        final Agent creator = annotation.getCreator();

        String id = "jid:fake.de/positions/" + Digest.sha1(uri, annotation.getNodeServer(), annotation.getNodeName());
        URI positionUri = factory.createURI(id);
        
        g.add(infoUri, DaIses.hasPositionPost, positionUri);
        g.add(positionUri, RDF.TYPE, DaIses.PositionPost);
        g.add(positionUri, DaIses.hasInformation, infoUri);
        g.add(positionUri, DaIses.hasPosition, factory.createURI(annotation.getNodeServer(),annotation.getNodeName()));
        g.add(positionUri, DC.creator, factory.createURI("jabberhash:",creator.getId()));
        g.add(positionUri, DaIses.hasInformation, infoUri);
        
        if (annotation.getTitle() != null){
            g.add(positionUri, RDFS.LABEL, factory.createLiteral(annotation.getTitle().getTitle()));
        }
        
        try {
            addStatements(g);
        } catch (RepositoryException e) {
            e.printStackTrace();
        }
        return annotation;
    }

    /**
     * @param position
     * @return
     */
    public boolean remove(PositionAnnotation position) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @param uri
     * @param tagging
     * @return
     */
    public TagAnnotation set(String uri, TagAnnotation annotation) {
        Graph g = new GraphImpl();
        final ValueFactory factory = g.getValueFactory();
        final URI infoUri = factory.createURI(uri);
        final Agent creator = annotation.getCreator();
        final String id = "jid:fake.de/taggings/" + Digest.sha1(uri, annotation.getCreator().getId());
        final URI tagPost = factory.createURI(id);

        g.add(tagPost, RDF.TYPE, DaIses.TagPost);
        g.add(tagPost, DC.creator, factory.createURI("jabberhash:",creator.getId()));
        g.add(tagPost, RDFS.LABEL, factory.createLiteral(annotation.getTitle().getTitle()));
        g.add(tagPost, DaIses.hasInformation, infoUri);
        g.add(infoUri, DaIses.hasTagPost, tagPost);

        for (Map.Entry<Tag, Boolean> tag: annotation.getTags().entrySet()){
            final BNode tagging = factory.createBNode();
            final URI tagUri = factory.createURI("http://localhost/tags/", tag.getKey().getNormalizedValue());
            g.add(tagPost, DaIses.hasTagging, tagging);
            g.add(tagging, DaIses.tags, infoUri);
            g.add(tagging, DaIses.hasTag, tagUri);
            g.add(tagging, DaIses.isPositive, factory.createLiteral(tag.getValue()));
            g.add(tagging, RDF.TYPE, DaIses.Tagging);
            g.add(tagUri, DaIses.tagRaw, factory.createLiteral(tag.getKey().getRawValue()));
            g.add(tagUri, RDF.TYPE, DaIses.Tag);
        }
        try {
            addStatements(g);
        } catch (RepositoryException e) {
            e.printStackTrace();
        }
        return annotation;
    }

    public boolean remove(TagAnnotation annotation) {
        final String id = "jid:fake.de/taggings/" + Digest.sha1(annotation.getInformation().getId(), annotation.getCreator().getId());
        final URI tagPost = repository.getValueFactory().createURI(id);
        RepositoryConnection connection = null;
        try {
            connection = repository.getConnection();
            //connection.remove(repository.getValueFactory().createURI(tagPost), null,null);
        } catch (RepositoryException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return false; 
    }

    /**
     * @return
     */
    public List<InformationObject> list() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @param tags
     * @return
     */
    public List<InformationObjectPosts> findByTags(Collection<String> tags) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @param position
     * @return
     */
    public List<InformationObjectPosts> findByPosition(Position position) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @return
     */
    public List<Tag> loadTags() {
        
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
