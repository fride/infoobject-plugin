package da.ises.openrdf.util;

import org.openrdf.repository.RepositoryConnection;

/**
 *
 */
public interface ConnectionCallback {

    /**
     *
     * @param cnx
     * @throws Exception
     */
    void doInConnection(RepositoryConnection cnx) throws Exception;
}
