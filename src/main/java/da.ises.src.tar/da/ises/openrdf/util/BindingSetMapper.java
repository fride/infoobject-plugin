package da.ises.openrdf.util;

import org.openrdf.query.BindingSet;

/**
 *
 */
public interface BindingSetMapper<T> {
    /**
     *
     * @param binding a binding set
     * @param row the current row
     * @return an object for the current row
     */
    T map(BindingSet binding, int row);
}
