package da.ises.openrdf.util;

/**
 * <p>
 * Class RdfException ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 19:14:40
 */
public class RdfException extends Exception{
    public RdfException() {
    }

    public RdfException(String s) {
        super(s);
    }

    public RdfException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public RdfException(Throwable throwable) {
        super(throwable);
    }
}
