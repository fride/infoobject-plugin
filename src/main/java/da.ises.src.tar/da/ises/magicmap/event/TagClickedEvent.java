package da.ises.magicmap.event;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: Jul 13, 2008
 * Time: 12:50:16 AM
 * To change this template use File | Settings | File Templates.
 */
public class TagClickedEvent {
    private String tag;

    public TagClickedEvent(String tag) {
        this.tag = tag;
    }

    public String getTag() {
        return tag;
    }
}
