package da.ises.magicmap.event;

/**
 *
 */
public class FacetClickedEvent {
    String facet;

    public FacetClickedEvent(String facet) {
        this.facet = facet;
    }

    public String getFacet() {
        return facet;
    }
}
