package da.ises.magicmap.event;

/**
 * 
 */
public class InformationClickedEvent {
    private String uri;

    public InformationClickedEvent(String uri) {
        this.uri = uri;
    }

    public String getUri() {
        return uri;
    }
}
