package da.ises.magicmap.ui.node.action;

import da.ises.magicmap.domain.node.InformationObjectNode;
import edu.umd.cs.piccolo.event.PInputEvent;
import net.sf.magicmap.client.gui.MainGUI;
import net.sf.magicmap.client.gui.utils.MagicAction;
import net.sf.magicmap.client.gui.views.ConsoleView;
import net.sf.magicmap.client.interfaces.MapViewListener;
import net.sf.magicmap.client.model.node.Node;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.net.URI;

/**
 * <p>
 * Class NodeDoubleClickAction ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 22:52:50
 */
public class NodeDoubleClickAction extends MagicAction implements MapViewListener {

    private String command = "tell application \"Safari\"\n" +
            "\tmake new document at end of documents\n" +
            "\tset URL of document 1 to \"$URI$/\"\n" +
            "\tdo JavaScript \"alert('Von Magic Map')\" in document 1\n" +
            "end tell";
    
    public NodeDoubleClickAction() {
        super("Information laden");
    }

    public void actionPerformed(ActionEvent event) {
        loadSelectedInformation();
    }

    /**
     * 
     */
    public void loadSelectedInformation() {
        Node selectedNode = MainGUI.getInstance().getNodeSelectionModel().getSelectedNode();
        if (selectedNode instanceof InformationObjectNode){
            String uri = ((InformationObjectNode)selectedNode).getInformationObject().getId();
            /*Runtime runtime = Runtime.getRuntime();
            try {
                runtime.exec(" osascript  -e '" + command.replace("$URI$", uri) + "'");
            } catch (IOException e) {
                e.printStackTrace(); 
            } */
            try {
                Desktop.getDesktop().browse(new URI(uri));
            } catch (Exception e) {
                e.printStackTrace();
                ConsoleView v = (ConsoleView) MainGUI.getInstance().getJComponent("consoleView");
                v.append(e.getLocalizedMessage());
            } 
        }
    }

    public void nodeClicked(Node node, PInputEvent event) {
        if (node instanceof InformationObjectNode){
            if (event.getClickCount() == 2){
                loadSelectedInformation();
            }
        }
    }

    public void nodeRightClicked(Node node, PInputEvent event) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void rightClicked(PInputEvent event) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void nodeFixiated(Node node) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void leftClicked(PInputEvent event) {

    }
}
