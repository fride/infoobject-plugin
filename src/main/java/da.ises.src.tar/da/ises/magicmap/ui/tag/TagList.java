package da.ises.magicmap.ui.tag;

import net.sf.magicmap.client.interfaces.NodeModelListener;

/**
 * <p>
 * Class TagList ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 21.07.2008
 *         Time: 00:46:14
 */
public class TagList{
}
