package da.ises.magicmap.ui.components;

import net.sf.magicmap.client.model.node.MapNode;
import da.ises.core.domain.user.Agent;
import da.ises.core.util.Startable;

public interface ComponentContainer extends Startable{
	
	void setUser(Agent agent);
	
	/**
	 * 
	 * @param map
	 */
	void setCurrentMap(MapNode map);
	

}
