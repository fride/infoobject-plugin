package da.ises.magicmap.ui.graph;

import da.ises.core.domain.infoobject.InformationObject;
import edu.umd.cs.piccolo.PNode;

/**
 * <p>
 * Class InformationDetailsNode ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 01:16:25
 */
public class InformationDetailsNode extends PNode {
    private InformationObject information;
}
