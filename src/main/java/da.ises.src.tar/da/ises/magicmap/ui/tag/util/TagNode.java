package da.ises.magicmap.ui.tag.util;

import da.ises.core.infoobject.Tag;

/**
 *
 */
public class TagNode implements TagNodeInterface{
    private Tag tag;

    /**
     * 
     * @param tag
     */
    public TagNode(Tag tag) {
        this.tag = tag;
    }

    public TagNodeInterface getParent() {
        return null;
    }

    public String getTag() {
        return tag.getRawValue();
    }

    public String getUser() {
        return "-";
    }

    public String isPositive() {
        return "-";
    }

    public String getTaggedName() {
        return "-";
    }

    public int getChildCount() {
        return 0;
    }
}
