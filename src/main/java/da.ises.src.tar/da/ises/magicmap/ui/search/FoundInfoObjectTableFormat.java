package da.ises.magicmap.ui.search;

import ca.odell.glazedlists.gui.AdvancedTableFormat;
import da.ises.core.domain.infoobject.InformationObject;

import java.util.Comparator;
import java.util.Date;

/**
 * <p>
 * Class InformationObjectSearchTableFormat ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 22.03.2008
 *         Time: 14:20:54
 */
public class FoundInfoObjectTableFormat implements AdvancedTableFormat<InformationObject> {

    private final Comparator<String> strComp = new Comparator<String>() {
        public int compare(String s, String s1) {
            return s.compareTo(s1);
        }
    };
    private final Comparator<Date> dateComp = new Comparator<Date>() {
        public int compare(Date s, Date s1) {
            return s.compareTo(s1);
        }
    };

    private final String[] names = new String[]{
            "Name",
            "Url",
            "Typ",
            "Gr��e",
            "Neu",
    };

    private final Class[] clazzes = new Class[] {
            String.class,
            String.class,
            String.class,
            Integer.class,
            Boolean.class
    };

    public Class getColumnClass(int i) {
        return clazzes[i];
    }

    /**
     *
     * @param i
     * @return
     */
    public Comparator getColumnComparator(int i) {
        return i == 4? dateComp : strComp;
    }

    public int getColumnCount() {
        return names.length;
    }

    public String getColumnName(int i) {
        return names[i];
    }

    public Object getColumnValue(InformationObject informationObject, int column) {
        switch (column) {
            case 0:
                return informationObject.getTitle().getTitle();
            case 1:
                return informationObject.getId();
            case 2:
                return informationObject.getMimeType().getMimeType();
            case 3:
                return informationObject.getSize();
            case 4:
                return informationObject.getVersion() == null;
        }
        throw new IllegalStateException("Column not known.....");
    }
}

