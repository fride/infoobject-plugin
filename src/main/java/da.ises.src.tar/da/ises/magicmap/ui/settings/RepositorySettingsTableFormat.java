package da.ises.magicmap.ui.settings;

import ca.odell.glazedlists.gui.WritableTableFormat;
import ca.odell.glazedlists.gui.AdvancedTableFormat;
import da.ises.magicmap.application.settings.RemoteRepositorySettings;

import java.util.Comparator;

/**
 *
 */
public class RepositorySettingsTableFormat implements WritableTableFormat<RemoteRepositorySettings>, AdvancedTableFormat<RemoteRepositorySettings> {
    private String columns[] = new String[]{
            "url",
            "user",
            "id",
            "local"

    };

    private String homeId;
    private final Comparator strcmp = new Comparator<String>() {
        public int compare(String o1, String o2) {
            return o1.compareTo(o2);
        }
    };

    private final Comparator boolcmp = new Comparator<Boolean>() {
        public int compare(Boolean o1, Boolean o2) {
            return o1.compareTo(o2);
        }
    };

    public int getColumnCount() {
        return columns.length;
    }

    public String getColumnName(int i) {
        return columns[i];
    }

    public Object getColumnValue(RemoteRepositorySettings settingsRemote, int column) {
        switch (column) {
            case 0:
                return settingsRemote.getUrl();
            case 1:
                return settingsRemote.getUser();
            case 2:
                return settingsRemote.getRepositoryId();
            case 3:
                return settingsRemote.isLocal();
            case 4:
                return homeId != null && homeId.equals(settingsRemote.getRepositoryId());
        }
        throw new IllegalStateException("Unknown column");
    }

    public boolean isEditable(RemoteRepositorySettings remoteRepositorySettings, int i) {
        return i < 3;
    }

    public RemoteRepositorySettings setColumnValue(RemoteRepositorySettings remoteRepositorySettings, Object value, int column) {
        switch (column) {
            case 0:
                remoteRepositorySettings.setUrl((String)value);
                break;
            case 1:
                remoteRepositorySettings.setUser((String)value);
                break;
            case 2:
                remoteRepositorySettings.setRepositoryId((String)value);
                break;
            default:
                throw new IllegalStateException("Invalid column");
        }
        return null;
    }


    public String getHomeId() {
        return homeId;
    }

    public void setHomeId(String homeId) {
        this.homeId = homeId;
    }

    public Class getColumnClass(int i) {
        return (i == 3 || i == 4) ? Boolean.class : String.class;
    }

    public Comparator getColumnComparator(int i) {
        return (i == 3 || i == 4) ? boolcmp : strcmp;
    }
}
