package da.ises.magicmap.ui.node;

import da.ises.html.base.extractor.HtmlExtractor;
import da.ises.html.base.ui.GenericUrlExtractorUI;
import da.ises.magicmap.controller.node.InformationNodeManager;
import da.ises.magicmap.domain.ModelFactory;
import da.ises.magicmap.domain.node.AbstractInformationNode;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.ui.components.GuiComponentFactory;
import da.ises.magicmap.ui.extractor.ExtractorRegistryUi;
import da.ises.magicmap.ui.node.action.*;
import da.ises.magicmap.ui.node.filter.NodeFilterSettingsView;
import da.ises.magicmap.ui.util.HtmlSaxParserFactory;
import da.ises.wikipedia.WikipediaFactory;
import net.sf.magicmap.client.gui.MainFrame;
import net.sf.magicmap.client.gui.ViewTabPanel;
import net.sf.magicmap.client.gui.utils.GUIBuilder;
import net.sf.magicmap.client.gui.utils.menu.NodeMenuContainer;
import net.sf.magicmap.client.gui.views.MapView;
import net.sf.magicmap.client.gui.views.OutlineView;

import javax.swing.*;

/**
 *  UI responsible for nodes.
 *
 */
public class NodeGuiAssembler {
    private final ModelFactory app;
    private final OutlineView outlineView;
    private final MapView mapView;
    private MainFrame mainFrame;

    private AnnotateNodeAction annotateAction;
    private GuiComponentFactory componentFactory;

    private LoadAnnotationsAction loadAnnotationsAction;
    private InformationNodeManager nodeManager;
    private NodeFilterSettingsView filterSettingsView;
    private static final String INFOOBEKTE_MENU = "Infoobekte";
    private CreatePlacemarkAction createPlacemarkAction;
    private CreateVehicleNodeAction createVehicleNodeAction;
    /**
     * Register all.....
     *
     */
    protected void registerMenus() {
        JMenu infoMenu = componentFactory.getInfoObjectMenu();

        infoMenu.add(new JMenuItem(filterSettingsView.getShowFilterSettingsAction()));
        infoMenu.add(new JMenuItem(createVehicleNodeAction));
        infoMenu.addSeparator();
        infoMenu.add(new JMenuItem(createPlacemarkAction));

        JMenu menu = new JMenu("informationen");
        menu.add(new JMenuItem(loadAnnotationsAction));
        menu.add(new JMenuItem(annotateAction));
        infoMenu.add(menu);
        infoMenu.addSeparator();

        NodeMenuContainer container = componentFactory.getMapView().getMenuContainer();
        menu.addSeparator();
        menu.add(new JMenuItem(createPlacemarkAction));
        menu = new JMenu("informationen");
        menu.add(new JMenuItem(loadAnnotationsAction));
        menu.add(new JMenuItem(annotateAction));
        container.addNodeMenuItem(this, menu);

        
        container = componentFactory.getOutlineView().getMenuContainer();
        menu.addSeparator();
        menu.add(new JMenuItem(createPlacemarkAction));
        menu = new JMenu("informationen");
        menu.add(new JMenuItem(annotateAction));
        menu.add(new JMenuItem(loadAnnotationsAction));

        container.addNodeMenuItem(this, menu);

        GUIBuilder.createToolButton(filterSettingsView.getShowFilterSettingsAction());

        componentFactory.getOutlineModel().addCategory(InformationObjectNode.NODE_TYPE, "Informationen");
        //componentFactory.getOutlineModel().addUnderParentNode(InformationPositionNode.class);

    }

    public AnnotateNodeAction getAnnotateAction() {
        return annotateAction;
    }

    public LoadAnnotationsAction getLoadAnnotationsAction() {
        return loadAnnotationsAction;
    }


    public NodeGuiAssembler(ModelFactory app, GuiComponentFactory componentFactory, InformationNodeManager nodeManager) {
        this.app = app;
        this.nodeManager = nodeManager;
        this.outlineView = componentFactory.getOutlineView();
        this.mapView = componentFactory.getMapView();
        mainFrame = componentFactory.getMainFrame();
        this.componentFactory = componentFactory;

        
        ExtractorRegistryUi extractorRegistryUi = new ExtractorRegistryUi();

        extractorRegistryUi.addExtractor(new GenericUrlExtractorUI(new HtmlExtractor(HtmlSaxParserFactory.getSaxParser())));
        extractorRegistryUi.addExtractor(WikipediaFactory.get().getWikipediaExtractorUI());

        annotateAction = new AnnotateNodeAction(extractorRegistryUi, nodeManager);

        this.componentFactory = componentFactory;

        componentFactory.getNodeSelectionModel().addNodeModelSelectionListener(annotateAction);

        loadAnnotationsAction = new LoadAnnotationsAction(nodeManager);

        componentFactory.getNodeSelectionModel().addNodeModelSelectionListener(loadAnnotationsAction);


        ViewTabPanel panel = (ViewTabPanel) componentFactory.getMainGUI().getJComponent("bottomRightTabPanel");
        InformationNodeView infoNodeView = new InformationNodeView();
        componentFactory.getNodeSelectionModel().addNodeModelSelectionListener(infoNodeView);
        panel.addView(infoNodeView);

        filterSettingsView = new NodeFilterSettingsView(app.getNodeModel(), app.getInformationTagModel());
        componentFactory.getNodeCanvas().addMapViewListener(new InformationNodeClickHandler());
        createPlacemarkAction = new CreatePlacemarkAction("Placemark Knoten anlegen", nodeManager);
        componentFactory.getNodeCanvas().addMapViewListener(createPlacemarkAction);

        mapView.getNodeCanvas().addMapViewListener(new NodeDoubleClickAction());
        createVehicleNodeAction = new CreateVehicleNodeAction(nodeManager);
    }

    private void handleDouble(AbstractInformationNode abstractInformationNode) {
        //To change body of created methods use File | Settings | File Templates.
    }


    public void start() {
        registerMenus();
    }
}
