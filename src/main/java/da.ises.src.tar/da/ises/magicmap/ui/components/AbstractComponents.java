package da.ises.magicmap.ui.components;

public abstract class AbstractComponents implements ComponentContainer{

	
}
