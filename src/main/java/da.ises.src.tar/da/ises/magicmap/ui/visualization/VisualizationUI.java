package da.ises.magicmap.ui.visualization;

import da.ises.magicmap.controller.association.AssociationManager;
import da.ises.magicmap.ui.util.MenuBarUtils;
import net.sf.magicmap.client.gui.MainFrame;
import net.sf.magicmap.client.gui.MainGUI;
import net.sf.magicmap.client.gui.views.MapView;
import net.sf.magicmap.client.gui.views.OutlineView;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: 20.06.2008
 * Time: 14:22:58
 * To change this template use File | Settings | File Templates.
 */
public class VisualizationUI {
    private AssociationManager associationManager;
    private final OutlineView outlineView;
    private final MapView mapView;

    public VisualizationUI(AssociationManager associationManager, OutlineView outlineView, MapView mapView) {
        this.associationManager = associationManager;
        this.outlineView = outlineView;
        this.mapView = mapView;
    }

    public void start() {
        MainFrame frame = MainGUI.getInstance().getMainFrame();
        JMenuBar bar = frame.getJMenuBar();
        MenuBarUtils utils = new MenuBarUtils();


    }
}
