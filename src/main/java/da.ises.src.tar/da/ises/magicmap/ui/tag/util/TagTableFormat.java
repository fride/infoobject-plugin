package da.ises.magicmap.ui.tag.util;

import ca.odell.glazedlists.gui.AdvancedTableFormat;

import java.util.Comparator;

/**
 * 
 */
public class TagTableFormat implements AdvancedTableFormat<TagItem> {

    /**
     * 
     */
    private final String columns[] = new String[]{
        "Tag", "Agent", "Uri", "Positiv"
    };



    /**
     * 
     * @return
     */
    public int getColumnCount() {
        return columns.length;
    }

    /**
     * 
     * @param i
     * @return
     */
    public String getColumnName(int i) {
        return columns[i];
    }

    /**
     * 
     * @param tag
     * @param i
     * @return
     */
    public Object getColumnValue(TagItem tag, int i) {
        switch(i) {
            case 0:
                return tag.getTagRaw();
            case 1:
                return tag.getAuthorName();
            case 2:
                return tag.getServerId();
            case 3:
                return tag.isPositive();
            default:
                throw new IllegalStateException("invalid column");
        }
    }

    public Class getColumnClass(int i) {
        return i ==3 ? Boolean.class : String.class;
    }

    public Comparator getColumnComparator(int i) {
        return null;
    }
}
