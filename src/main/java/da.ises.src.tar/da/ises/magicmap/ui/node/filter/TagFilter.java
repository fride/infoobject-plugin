package da.ises.magicmap.ui.node.filter;

import da.ises.magicmap.domain.node.NodeFilter;
import da.ises.magicmap.domain.node.InformationNodeModel;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.domain.tag.InformationTagModel;
import da.ises.core.infoobject.Tag;
import net.sf.magicmap.client.model.node.Node;

import java.util.Set;
import java.util.HashSet;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: Jul 14, 2008
 * Time: 7:33:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class TagFilter implements NodeFilter {
    private Set<Integer> filteredNodes = new HashSet<Integer>();
    private Set<String> tags = new HashSet<String>();
    private final static Logger log = LoggerFactory.getLogger(TagFilter.class);
    private final InformationTagModel tagModel;
    private final InformationNodeModel nodeModel;
    private boolean enbled;
    /**
     * 
     * @param tagModel
     */
    public TagFilter(InformationTagModel tagModel, InformationNodeModel nodeModel) {
        this.tagModel = tagModel;
        this.nodeModel = nodeModel;
    }

    public boolean evaluate(Node node) {
        return checkPhysical(node) || checkTags(node);
    }

    public void setEnabled(boolean enabled) {
        if (this.enbled == enabled) return;
        if (enabled) {
            nodeModel.addFilter(this);
        } else {
            nodeModel.removeFilter(this);
        }
        this.enbled = enabled;
        nodeModel.filterChanged();
    }
    
    public void addTag(String tag) {
        this.tags.add(tag);
        nodeModel.filterChanged();
    }
    public void removeTag(String tag) {
        this.tags.remove(tag);
        nodeModel.filterChanged();
    }

    /**
     * 
     * @param node
     * @return
     */
    private boolean checkTags(Node node) {
        Set<Tag> tagSet = (node instanceof InformationObjectNode) ? ((InformationObjectNode)node).getTags() : new HashSet<Tag>();

        for (Tag tag: tagSet) {
            if (this.tags.contains(tag.getRawValue())) return true;
        }
        log.info("No tags found {}", tagSet);
        return false;
    }

    private boolean checkPhysical(Node node) {
        return node.isPhysical();
    }

    public void setTags(Collection<String> tags) {
        this.tags.clear();
        this.tags.addAll(tags);
    }
}
