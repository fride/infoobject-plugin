package da.ises.magicmap.ui.node.forms;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import da.ises.magicmap.ui.node.util.NodeCellrenderer;
import da.ises.magicmap.ui.node.util.NodeSelectionUI;
import net.sf.magicmap.client.model.node.NodeModel;

import javax.swing.*;
import javax.swing.text.Document;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.ResourceBundle;

/**
 * <p>
 * Class EditPositionForm ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 27.07.2008
 *         Time: 18:22:12
 */
public class EditAnnotationForm {

    private final NumberFormat nf = new DecimalFormat("##,###.## kb");
    private JTextField titleField = new JTextField();
    private JTextField descriptionField = new JTextField();
    private JTextField tagField = new JTextField();
    private JList yourTagList = new JList();
    private JList recomendedTagList = new JList();

    private JPanel view;
    private FormLayout layout;

    public EditAnnotationForm() {
        yourTagList.setCellRenderer(new NodeCellrenderer());
        yourTagList.setVisibleRowCount(3);

        recomendedTagList.setCellRenderer(new NodeCellrenderer());
        recomendedTagList.setVisibleRowCount(3);
    }



    public Document getTitle(){
        return titleField.getDocument();
    }

    public Document getDescriptionDocument(){
        return descriptionField.getDocument();
    }

    public Document getTagDocument(){
        return tagField.getDocument();
    }

    public JComponent getView(){
        if (view == null){
            layout = new FormLayout("right:p");
            CellConstraints cc = new CellConstraints();
            PanelBuilder b = new DefaultFormBuilder(layout, ResourceBundle.getBundle("da/ises/forms/forms"));

            b.appendRelatedComponentsGapColumn();
            b.appendColumn("p:grow");

            b.appendRow("p");
            b.addLabel("Titel", cc.xy(1,b.getRowCount()));
            b.add(titleField, cc.xy(3,b.getRowCount()));

            b.appendRelatedComponentsGapRow();
            b.appendRow("p");
            b.addLabel("Beschreibung", cc.xy(1,b.getRowCount()));
            b.add(descriptionField, cc.xy(3,b.getRowCount()));

            b.appendRelatedComponentsGapRow();
            b.appendRow("p");
            b.addLabel("Tags", cc.xy(1,b.getRowCount()));
            b.add(tagField, cc.xy(3,b.getRowCount()));

            b.appendRelatedComponentsGapRow();
            b.appendRow("p");
            b.addLabel("recommended_tags", cc.xy(1,b.getRowCount()));
            b.add(new JScrollPane(recomendedTagList), cc.xy(3,b.getRowCount()));

            b.appendRelatedComponentsGapRow();
            b.appendRow("p");
            b.addLabel("your_tags", cc.xy(1,b.getRowCount()));
            b.add(new JScrollPane(yourTagList), cc.xy(3,b.getRowCount()));

            view = b.getPanel();

        }
        return view;
    }

    public void setTags(Iterable<String> tags){
        StringBuilder b = new StringBuilder("");
        Iterator<String> stringIterator = tags.iterator();
        while(stringIterator.hasNext()){
            b.append(stringIterator.next());
            if (stringIterator.hasNext()){
                b.append(", ");
            }
        }
        this.tagField.setText(b.toString());
    }
    /**
     *
     * @param model
     */
    public void setYourTagModel(ListModel model){
        this.yourTagList.setModel(model);
    }

    public void setRecomendedTagModel(ListModel model){
        this.recomendedTagList.setModel(model);
    }
    public static void main(String[] args) {
        NodeModel m = new NodeModel();
        NodeSelectionUI ui = new NodeSelectionUI(m);
        JFrame f = new JFrame();
        EditAnnotationForm form = new EditAnnotationForm();

        f.getContentPane().add(form.
                getView());
        f.pack();
        f.setVisible(true);
    }

    public void setTitel(String title) {
        this.titleField.setText(title);
    }
}
