package da.ises.magicmap.ui.extractor;

import javax.swing.*;
import javax.swing.plaf.basic.BasicComboBoxRenderer;
import java.awt.*;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.util.concurrent.Lock;
import ca.odell.glazedlists.swing.EventComboBoxModel;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.builder.DefaultFormBuilder;
import net.sf.magicmap.client.utils.AbstractModel;
import net.sf.magicmap.client.gui.forms.UserInterface;
import da.ises.html.base.ui.GenericUrlExtractorUI;
import da.ises.wikipedia.ui.WikipediaExtractorUI;
import da.ises.wikipedia.extractor.WikipediaExtractor;

/**
 * User interface for Extractors.
 */
public class ExtractorRegistryUi extends AbstractModel implements UserInterface {

    private AbstractAction loadAction;
    private BasicEventList<ExtractorUI> extractorListUI = new BasicEventList<ExtractorUI>();
    private EventComboBoxModel<ExtractorUI> extractors = new EventComboBoxModel<ExtractorUI>(extractorListUI);

    private JComboBox extractorBox = new JComboBox(extractors);

    private CardLayout cards;
    private JPanel view;
    private JPanel cardPanel;

    private boolean enabled;

    /**
     * 
     * @param
     */
    public ExtractorRegistryUi() {

        extractorBox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                final ExtractorUI ex = getSelectedExtractor();
                cards.show(cardPanel,ex.getName());
            }
        });

        extractorBox.setRenderer(new BasicComboBoxRenderer(){
            public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                final JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                final ExtractorUI extractorUI = (ExtractorUI) value;
                label.setText(extractorUI != null ? extractorUI.getName(): " -- Aktion w�hlen -- ");
                return label;
            }
        });
        cards = new CardLayout();
        cardPanel = new JPanel();
        cardPanel.setLayout(cards);
        //addExtractor(new GenericUrlExtractorUI());
        //addExtractor(new WikipediaExtractorUI("de", new WikipediaExtractor()));
    }

    public AbstractAction getLoadAction() {
        return loadAction;
    }

    /**
     * 
     * @param loadAction
     */
    public void setLoadAction(AbstractAction loadAction) {
        this.loadAction = loadAction;
        for (ExtractorUI extractorUI: extractorListUI) {
            extractorUI.setLoadAction(loadAction);
        }
    }

    public boolean isEnabled() {
        return enabled;
    }
    

    /**
     * 
     * @param enabled
     */
    public void setEnabled(boolean enabled) {
        if (this.enabled != enabled) {
            this.enabled = enabled;
            this.extractorBox.setEnabled(enabled);
            this.loadAction.setEnabled(enabled);
            for (ExtractorUI ui: extractorListUI) {
                ui.getView().setEnabled(enabled);
            }
            firePropertyChange("enabled", !enabled, enabled);
        }
    }

    /**
     *
     * @param extractorUI
     */
    public void addExtractor(ExtractorUI extractorUI) {
        Lock lock = this.extractorListUI.getReadWriteLock().writeLock();
        lock.lock();
        try {
            extractorListUI.add(extractorUI);
            cardPanel.add(extractorUI.getView(), extractorUI.getName());
            extractorUI.setLoadAction(loadAction);
        } finally {
            lock.unlock();
        }
    }

    protected JPanel getView() {
        if (view == null) {
            final FormLayout l = new FormLayout("p,3dlu,p:grow,3dlu,p", "p");
            final CellConstraints cc = new CellConstraints();
            final PanelBuilder b = new DefaultFormBuilder(l);
            b.add(extractorBox, cc.xy(1,1));


            b.add(cardPanel, cc.xy(3,1, CellConstraints.FILL, CellConstraints.FILL));
            b.add(new JButton(loadAction), cc.xy(5,1));
            view = b.getPanel();
            cardPanel.add(new JLabel("Bitte w�hlen Sie eine Aktion"), "default");

        }
        return view;
    }


    /**
     * 
     * @return
     */
    public ExtractorUI getSelectedExtractor() {
        return (ExtractorUI) extractors.getSelectedItem();
    }

    public JComponent visualProxy(String name, JComponent parent) throws IllegalArgumentException {
        JComponent proxy = null;
        if ("settings".equals(name)) {

        } else if (name == null) {
            proxy = getView();
        }
        return proxy;
    }
}
