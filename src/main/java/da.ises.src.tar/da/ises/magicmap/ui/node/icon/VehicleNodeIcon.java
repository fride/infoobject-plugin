package da.ises.magicmap.ui.node.icon;

import da.ises.magicmap.domain.node.BusNode;
import da.ises.magicmap.domain.node.CarNode;
import da.ises.magicmap.domain.node.PlaneNode;
import da.ises.magicmap.domain.node.ShipNode;
import net.sf.magicmap.client.gui.utils.GUIBuilder;
import net.sf.magicmap.client.gui.utils.icon.INodeIcon;
import net.sf.magicmap.client.model.node.Node;

import javax.swing.*;
import java.awt.*;

/**
 * <p>
 * Class VehicleNodeIcon ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 23:48:44
 */
public class VehicleNodeIcon implements INodeIcon {

    private ImageIcon car = GUIBuilder.getToolIcon("auto.png","NodeIcons");
    private ImageIcon bus = GUIBuilder.getToolIcon("bus.png","NodeIcons");
    private ImageIcon train = GUIBuilder.getToolIcon("zug_unspezifisch.png","NodeIcons");
    private ImageIcon ship = GUIBuilder.getToolIcon("schiff.png","NodeIcons");
    private ImageIcon plane = GUIBuilder.getToolIcon("flugzeug_gross.png","NodeIcons");

    
    public Icon getIcon(Node node) {
        if (node instanceof ShipNode){
            return ship;
        } else if (node instanceof BusNode){
            return bus;
        } else if (node instanceof CarNode){
            return car;
        } else if (node instanceof PlaneNode){
            return plane;
        }
        return null;
    }

    public Color getFgColor(Node node) {
        return Color.BLACK;
    }

    public Color getBgColor(Node node) {
        return Color.WHITE;
    }
}
