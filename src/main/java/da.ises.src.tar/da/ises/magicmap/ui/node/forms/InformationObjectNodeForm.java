package da.ises.magicmap.ui.node.forms;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import da.ises.magicmap.ui.node.util.NodeSelectionUI;

import javax.swing.*;
import javax.swing.text.Document;
import java.awt.*;
import java.util.ResourceBundle;

/**
 * <p>
 * Class EditInfoPositionForm ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 27.07.2008
 *         Time: 18:09:22
 */
public class InformationObjectNodeForm {
    private final NodeSelectionUI nodeUI;
    private final JComponent extractor;
    private final EditAnnotationForm positionDetails;
    private final EditAnnotationForm infoDetails;
    private JTextField uri = new JTextField();

    private JPanel view;
    private FormLayout layout;
    private JButton saveButton = new JButton("Speichern");
    private JPanel cardsPanel = new JPanel();
    private CardLayout cards = new CardLayout();
    private JLabel messageLabel = new JLabel();
    private JProgressBar progress;

    public InformationObjectNodeForm(NodeSelectionUI nodeUI, JComponent extractor, EditAnnotationForm positionDetails, EditAnnotationForm infoDetails) {
        this.nodeUI = nodeUI;
        this.extractor = extractor;
        this.positionDetails = positionDetails;
        this.infoDetails = infoDetails;
        progress = new JProgressBar();
        progress.setIndeterminate(true);
        progress.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        messageLabel.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
    }

    public void showMessage(String message){
        messageLabel.setText(message);
        cards.show(cardsPanel, "msg");
        getView().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    }

    public void showForms(){
        cards.show(cardsPanel,"tabs");
        getView().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    }

    public void showWait(){
        cards.show(cardsPanel, "wait");
        getView().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

    }

    public JComponent getView(){
        if (view == null){

            JTabbedPane tabs = new JTabbedPane();
            JComponent view_temp = infoDetails.getView();
            view_temp.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
            tabs.addTab("information", view_temp);
            view_temp =positionDetails.getView();
            view_temp.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
            tabs.addTab("position", view_temp);

            cardsPanel.setLayout(cards);
            cardsPanel.add(messageLabel,    "msg");
            cardsPanel.add(progress,        "wait");
            cardsPanel.add(tabs,            "tabs");

            layout = new FormLayout("right:p");

            CellConstraints cc = new CellConstraints();
            PanelBuilder b = new DefaultFormBuilder(layout, ResourceBundle.getBundle("da/ises/forms/forms"));

            b.appendRelatedComponentsGapColumn();
            b.appendColumn("p:grow");
            b.appendRelatedComponentsGapColumn();
            b.appendColumn("p");

            b.appendRow("p");
            b.addLabel("Knoten", cc.xy(1,b.getRowCount()));
            b.add(nodeUI.visualProxy("combo",null), cc.xyw(3, b.getRowCount(),3));

            b.appendRelatedComponentsGapRow();
            b.appendRow("p");
            b.addLabel("Information", cc.xy(1,b.getRowCount()));
            b.add(extractor, cc.xyw(3, b.getRowCount(),3));

            b.appendUnrelatedComponentsGapRow();
            b.appendRow("p:grow");


            b.add(cardsPanel, cc.xyw(1,b.getRowCount(), b.getColumnCount(), CellConstraints.FILL, CellConstraints.FILL));

            b.appendUnrelatedComponentsGapRow();
            b.appendRow("p");
            b.add(ButtonBarFactory.buildCenteredBar(saveButton), cc.xyw(1,b.getRowCount(), b.getColumnCount()));


            view = b.getPanel();

        }
        return this.view;
    }

    public void setSaveAction(Action a){
        this.saveButton.setAction(a);
    }

  

    public Document getUriDocument() {
        return this.uri.getDocument();
    }
}
