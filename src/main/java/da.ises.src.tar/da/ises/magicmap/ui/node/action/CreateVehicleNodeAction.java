package da.ises.magicmap.ui.node.action;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.swing.EventComboBoxModel;
import ca.odell.glazedlists.util.concurrent.Lock;
import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import da.ises.magicmap.controller.node.InformationNodeManager;
import da.ises.magicmap.domain.node.*;
import net.sf.magicmap.client.gui.MainGUI;
import net.sf.magicmap.client.utils.DocumentAdapter;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * <p>
 * Class CreateVehicleNodeAction ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 23:55:30
 */
public class CreateVehicleNodeAction extends AbstractNodeAction{

    private EventList<String> dinger = new BasicEventList<String>();
    private EventComboBoxModel<String> dingerModel = new EventComboBoxModel<String>(dinger);
    
    /**
     * @param s
     * @param manager
     */
    public CreateVehicleNodeAction(InformationNodeManager manager) {
        super("Fahrzeuge...", manager);
        Lock lock = dinger.getReadWriteLock().writeLock();
        lock.lock();
        dinger.add("Pkw");
        dinger.add("Lkw");
        dinger.add("Flugzeug");
        dinger.add("Schiff");
        lock.unlock();
        setEnabled(true);

    }

    public void actionPerformed(ActionEvent event) {

        final JDialog dlg = new JDialog(MainGUI.getInstance().getMainFrame());
        FormLayout l = new FormLayout("p");
        CellConstraints cc = new CellConstraints();
        PanelBuilder b = new DefaultFormBuilder(l);
        b.appendRelatedComponentsGapColumn();
        b.appendColumn("p:grow");
        b.appendRow("p");
        b.add(new JLabel("Typ"), cc.xy(1,1));
        b.add(new JComboBox(dingerModel), cc.xy(3,1));

        b.appendRelatedComponentsGapRow();
        b.appendRow("p");
        b.add(new JLabel("Name"), cc.xy(1,b.getRowCount()));
        JTextField field = new JTextField();
        final DocumentAdapter name = new DocumentAdapter(field) {
            public void handleChange(String s) {

            }
        };
        b.add(field, cc.xy(3,b.getRowCount()));

        b.appendUnrelatedComponentsGapRow();
        b.appendRow("p");

        Action create = new AbstractAction("Anlegen") {
            public void actionPerformed(ActionEvent event) {
                create(name.getDocumentContents());
                dlg.setVisible(false);
            }
        };

        b.add(ButtonBarFactory.buildCenteredBar(new JButton(create)), cc.xyw(1,b.getRowCount(), b.getColumnCount()));
        dlg.getContentPane().add(b.getPanel());
        dlg.pack();
        dlg.setVisible(true);

    }

    @Override
    protected boolean checkEnable() {
        return true;
    }

    private void create(String documentContents) {
        InformationNodeModel nodeModel = getNodeManager().getNodeModel();
        if ("Pkw".equals(dingerModel.getSelectedItem())){
            CarNode node = new CarNode(nodeModel);
            node.setDisplayName(documentContents);
            nodeModel.addNode(node);
        }

        if ("Lkw".equals(dingerModel.getSelectedItem())){
            BusNode node = new BusNode(nodeModel);
            node.setDisplayName(documentContents);
            nodeModel.addNode(node);
        }
        if ("Flugzeug".equals(dingerModel.getSelectedItem())){
            PlaneNode node = new PlaneNode(nodeModel);
            node.setDisplayName(documentContents);
            nodeModel.addNode(node);
        }
        if ("Schiff".equals(dingerModel.getSelectedItem())){
            ShipNode node = new ShipNode(nodeModel);
            node.setDisplayName(documentContents);
            nodeModel.addNode(node);
        }
    }
}
