package da.ises.magicmap.ui.search;


import da.ises.core.domain.infoobject.InformationObject;

import java.util.List;

/**
 * <p>
 * Class SearchEngine ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 22.03.2008
 *         Time: 12:25:48
 */
public interface SearchEngine {

    String getQueryString();

    /**
     * 
     * @return
     */
    String getName();

    /**
     *
     * @return
     */
    String getDescription();

    /**
     *
     * @param query
     * @param callback
     */
    void search(String query, SearchEngineCallback callback);

    /**
     *
     * @return
     */
    List<InformationObject> getLinks();

    /**
     *
     * @return
     */
    int getMaxResults();

    /**
     *
     * @param results
     */
    void setMaxResults(int results);

    /**
     *
     */
    static interface SearchEngineCallback{
        void searchFinished(SearchEngine engine);
        void searchFailed(SearchEngine engine, Throwable throwable);
    }

}
