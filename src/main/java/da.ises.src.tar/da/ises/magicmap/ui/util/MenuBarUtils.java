package da.ises.magicmap.ui.util;

import javax.swing.*;



/**
 *
 *
 */
public class MenuBarUtils {

	/**
	 * @param title
	 * @param bar
	 * @return
	 */
	public JMenu getMenu(String title, JMenuBar bar) {
		for (int i = 0; i < bar.getMenuCount(); ++i) {
			JMenu jMenu = bar.getMenu(i);
			if (title.equals(jMenu.getName())) {
				return jMenu;
			}
		}

		JMenu menu = new JMenu();
		menu.setName(title);
        menu.setText(title);
        bar.add(menu);
		return menu;
	}

	public JMenu addMenuItem(String title, JMenuBar bar, JMenuItem item) {
		for (int i = 0; i < bar.getMenuCount(); ++i) {
			JMenu jMenu = bar.getMenu(i);
			if (title.equals(jMenu.getName())) {
				jMenu.add(item);
				return jMenu;
			}
		}

		JMenu menu = new JMenu(title);
		menu.setName(title);
		menu.add(item);
		bar.add(menu);
		return menu;
	}

	public JMenu addSubMenu(String title, JMenuBar bar, JMenu newMenu) {
		for (int i = 0; i < bar.getMenuCount(); ++i) {
			JMenu jMenu = bar.getMenu(i);
			if (title.equals(jMenu.getName())) {
				jMenu.add(newMenu);
				return jMenu;
			}
		}

		JMenu parent_menu = new JMenu(title);
		newMenu.setName(title);
		parent_menu.add(newMenu);
		bar.add(parent_menu);
		return parent_menu;
	}
}
