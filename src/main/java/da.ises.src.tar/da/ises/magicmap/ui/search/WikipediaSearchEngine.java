package da.ises.magicmap.ui.search;


import da.ises.core.domain.infoobject.InformationObject;
import org.openrdf.model.impl.URIImpl;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * <p>
 * Class WikipediaSearchEngine ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 16.03.2008
 *         Time: 16:35:26
 */
public class WikipediaSearchEngine extends OpenSearchEngine {

    static String wiki_query_template = "http://$LANG$.wikipedia.org/w/api.php?action=opensearch&search=$QUERY$";
    private String baseURL;

    public WikipediaSearchEngine(String language) {
        super(wiki_query_template, "In WikipediaFactory " + language + " suchen", "<html>Durchsucht die WikipediaFactory nach Artikeln</html>");
        addSearchParam("LANG", language);
        this.baseURL = "http://" + language + ".wikipedia.org/wiki/";
    }

    /**
     * 
     * @param list
     * @return
     */
    protected Collection<InformationObject> getLinks(List<String> list) {
        ArrayList<InformationObject> links= new ArrayList<InformationObject>(list.size());
        for (String article: list) {
            final InformationObject informationObject = new InformationObject(new URIImpl((baseURL + URLEncoder.encode(article.replace(" ", "_")))) );
            //informationObject.setName(article);
            //informationObject.setMimeType("text/html");
            //informationObject.setInformationType("text/html/wiki");
            links.add(informationObject);
        }
        return links;
    }
    
}
