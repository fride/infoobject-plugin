package da.ises.magicmap.ui.node.icon;

import net.sf.magicmap.client.gui.utils.icon.INodeIcon;
import net.sf.magicmap.client.gui.utils.icon.OverlayIcon;
import net.sf.magicmap.client.gui.utils.GUIBuilder;
import net.sf.magicmap.client.model.node.Node;

import javax.swing.*;
import java.awt.*;

/**
 * <p>
 * Class PlacemarkNodeIcon ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 26.07.2008
 *         Time: 10:01:10
 */
public class PlacemarkNodeIcon implements INodeIcon {

    private ImageIcon placemarkIcon = GUIBuilder.getToolIcon("placemark_ungerichtet.png","NodeIcons");
    private ImageIcon overLay = GUIBuilder.getToolIcon("overlay_fixiert.png","NodeIcons");
    private OverlayIcon icon = new OverlayIcon(placemarkIcon.getImage(), overLay);

    public PlacemarkNodeIcon() {

    }


    public Icon getIcon(Node node) {

        icon.setShowOverlay(node.isFix());

        return icon;
    }

    public Color getFgColor(Node node) {
        return Color.blue;
    }

    public Color getBgColor(Node node) {
        return Color.WHITE;
    }
}
