package da.ises.magicmap.ui.node;

import da.ises.magicmap.domain.node.AbstractInformationNode;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.domain.node.ObjectNodeLink;
import da.ises.magicmap.event.FacetClickedEvent;
import da.ises.magicmap.event.InformationClickedEvent;
import net.sf.magicmap.client.gui.views.View;
import net.sf.magicmap.client.model.node.INodeModelSelectionListener;
import net.sf.magicmap.client.model.node.NodeModelSelectionEvent;
import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateGroup;
import org.bushe.swing.event.EventBus;

import javax.swing.*;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.Element;

/**
 *
 */
public class InformationNodeView extends View implements INodeModelSelectionListener {

    private JEditorPane pane;
    private JScrollPane scroll;
    static StringTemplateGroup templates = new StringTemplateGroup("views");

    public InformationNodeView() {
    }

    public String getName() {
        return "Information";
    }

    protected JComponent buildViewComponent() {
        if (pane == null) {
            pane = new JEditorPane("text/html", "");
            pane.setEditable(false);
            pane.addHyperlinkListener(new HyperlinkListener() {
                public void hyperlinkUpdate(HyperlinkEvent e) {
                    if (HyperlinkEvent.EventType.ACTIVATED.equals(e.getEventType())) {
                        String description = e.getDescription();
                        if (description != null && description.startsWith("nfo:")) {
                            linkClicked(description.substring("nfo:".length()));
                        } else if (description != null && description.startsWith("facet")) {
                            facetClicked(description.substring("facet:".length()));
                        }
                    }
                    Element sourceElement = e.getSourceElement();
                    System.out.println("sourceElement = " + sourceElement.getAttributes());;
                    System.out.println("href = " + sourceElement.getAttributes().getAttribute("href"));
                }
            });
            scroll = new JScrollPane(pane);
            scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        }

        return scroll;
    }

    private void facetClicked(String facet) {
        EventBus.publish(new FacetClickedEvent(facet));
    }

    private void linkClicked(String href) {
        EventBus.publish(new InformationClickedEvent(href));
    }

    public void selectionChanged(NodeModelSelectionEvent event) {
        if (event.getSelectedNode() instanceof AbstractInformationNode) {
            //loadInformations((AbstractInformationNode)event.getSelectedNode());
        }
    }

    private void loadInformations(AbstractInformationNode node) {
        /*StringTemplate nodeTemplate = templates.getInstanceOf("da/ises/templates/view/information_node");
        if (node.getType() == InformationObjectNode.NODE_TYPE) {
            InformationObjectNode info = (InformationObjectNode) node;
            nodeTemplate.setAttribute("informationObject", getObjectText(info));
            nodeTemplate.setAttribute("positions", getPositionText(info.getPositions()));
        }
        pane.setText(nodeTemplate.toString());*/
    }

    private String getPositionText(Iterable<ObjectNodeLink> children) {
        StringTemplate objectTemplate = templates.getInstanceOf("da/ises/templates/view/information_position_list");
        objectTemplate.setAttribute("positions",children);
        return objectTemplate.toString();

    }

    protected String getObjectText(InformationObjectNode node) {
        StringTemplate objectTemplate = templates.getInstanceOf("da/ises/templates/view/information_object");
        objectTemplate.setAttribute("node",node);
        return objectTemplate.toString();
    }



}
