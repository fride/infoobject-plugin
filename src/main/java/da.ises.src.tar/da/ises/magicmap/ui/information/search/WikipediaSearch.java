package da.ises.magicmap.ui.information.search;

import net.sf.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 */
public class WikipediaSearch extends OpenSearch{

    static String wiki_query_template = "http://$LANG$.wikipedia.org/w/api.php?action=opensearch&search=$QUERY$";
    private String baseURL;
    
    public WikipediaSearch(String language) {
        super(wiki_query_template, "In WikipediaFactory " + language + " suchen", "<html>Durchsucht die WikipediaFactory nach Artikeln</html>");
        addSearchParam("LANG", language);
        this.baseURL = "http://" + language + ".wikipedia.org/wiki/";

    }

    protected List<String> getLinks(JSONArray jsonArray) {
        ArrayList<String> links= new ArrayList<String>(jsonArray.size());
        for (Object article: jsonArray) {
            links.add(article.toString());
        }
        return links;
    }
}
