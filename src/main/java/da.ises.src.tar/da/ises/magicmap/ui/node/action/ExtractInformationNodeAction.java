package da.ises.magicmap.ui.node.action;

import da.ises.magicmap.controller.node.InformationNodeManager;
import da.ises.magicmap.domain.node.InformationObjectNode;
import net.sf.magicmap.client.model.node.Node;

import java.awt.event.ActionEvent;

/**
 * <p>
 * Class ExtractInformationNodeAction ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 02.08.2008
 *         Time: 00:04:18
 */
public class ExtractInformationNodeAction extends AbstractNodeAction{
    /**
     * @param s
     * @param manager
     */
    public ExtractInformationNodeAction(String s, InformationNodeManager manager) {
        super(s, manager);
    }

    protected boolean checkEnable() {
        return super.enabled && (getSelectedNode() instanceof InformationObjectNode);
    }
    
    /**
     * 
     * @param event
     */
    public void actionPerformed(ActionEvent event) {
        Node node = getSelectedNode();
        if (node instanceof InformationObjectNode){
            getNodeManager().explodeNode(node, 1);
        }

    }
}
