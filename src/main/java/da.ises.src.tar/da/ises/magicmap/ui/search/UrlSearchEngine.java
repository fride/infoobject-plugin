package da.ises.magicmap.ui.search;


import da.ises.core.domain.entity.MimeType;
import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.InformationObjectFactory;

import java.net.URL;
import java.net.URLConnection;
import java.util.Collections;
import java.util.List;

/**
 * <p>
 * Class UrlSearchEngine ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 22.03.2008
 *         Time: 12:39:59
 */
public class UrlSearchEngine implements SearchEngine {
    private InformationObject link;
    private String querySting;
    private InformationObjectFactory factory;

    public UrlSearchEngine(InformationObjectFactory factory) {
        this.factory = factory;
    }

    public String getQueryString() {
        return  querySting;
    }

    public String getName() {
        return "Neue URL anlegen";
    }

    /**
     * @return
     */
    public String getDescription() {
        return "<html>Sie k�nnen eine neue URL anlegen.</html>";
    }

    /**
     * @param query
     */
    public void search(String query, SearchEngineCallback callback) {
        querySting = query;
        try {
            URL u = new URL(query);
            link = factory.createInformationObject(u.toString());
            final URLConnection urlConnection = u.openConnection();
            link.setMimeType(MimeType.mimeType(urlConnection.getContentType()));
            link.setSize((long)urlConnection.getContentLength());
            callback.searchFinished(this);   
        } catch (Throwable e) {
            callback.searchFailed(this,e);
        }
    }

    /**
     * @return
     */
    @SuppressWarnings({"unchecked"})
    public List<InformationObject> getLinks() {
        return (List<InformationObject>) (link == null ? Collections.emptyList() : Collections.singletonList(link));
    }

    /**
     * @return
     */
    public int getMaxResults() {
        return 1;
    }

    /**
     * @param results
     */
    public void setMaxResults(int results) {
        
    }
}
