package da.ises.magicmap.ui.log;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: Jul 9, 2008
 * Time: 6:37:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class LogEvent {
    public enum Type{
        INFO,
        MESSAGE,
        WARNING,
        ERROR
    }
    private final String message;
    private final Type type;

    public LogEvent(String message, Type type) {
        this.message = message;
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public Type getType() {
        return type;
    }
}
