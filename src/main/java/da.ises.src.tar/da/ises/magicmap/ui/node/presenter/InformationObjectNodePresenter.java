package da.ises.magicmap.ui.node.presenter;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.swing.EventComboBoxModel;
import ca.odell.glazedlists.util.concurrent.Lock;
import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.TagAnnotation;
import da.ises.core.domain.repository.InformationObjectPosts;
import da.ises.core.domain.user.Agent;
import da.ises.magicmap.controller.node.InformationNodeManager;
import da.ises.magicmap.controller.node.InformationPositionNodeBuilder;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.ui.extractor.ExtractorRegistryUi;
import da.ises.magicmap.ui.node.forms.InformationObjectNodeForm;
import da.ises.magicmap.ui.node.util.NodeSelectionUI;
import net.sf.magicmap.client.gui.utils.MagicAction;
import net.sf.magicmap.client.model.node.Node;
import net.sf.magicmap.client.utils.AbstractModel;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Collection;
import java.util.Collections;

/**
 * <p>
 * Class InformationObjectPresenter ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 27.07.2008
 *         Time: 22:13:21
 */
public class InformationObjectNodePresenter extends AbstractModel {
    private EditAnnotationPresenter infoPresenter = new EditAnnotationPresenter();
    private EditAnnotationPresenter positionPresenter = new EditAnnotationPresenter();
    private InformationObjectNodeForm form;
    private NodeSelectionUI nodeSelection;
    private Node selectedNode;
    private final ExtractorRegistryUi extractorRegistry;
    private final InformationNodeManager manager;
    private InformationObject info;

    private EventList<String> positionTags = new BasicEventList<String>();
    private EventComboBoxModel positionTagModel = new EventComboBoxModel(positionTags);

    private EventList<String> infoTags = new BasicEventList<String>();
    private EventComboBoxModel infoTagModel = new EventComboBoxModel(infoTags);

    private MagicAction saveAction;

    public InformationObjectNodePresenter(ExtractorRegistryUi extractorRegistry, InformationNodeManager manager) {
        this.extractorRegistry = extractorRegistry;
        this.manager = manager;
        nodeSelection = new NodeSelectionUI(manager.getNodeModel());
        
        AbstractAction loadAction = new MagicAction("Laden"){
            public void actionPerformed(ActionEvent event) {
                load();
            }
        };
        extractorRegistry.setLoadAction(loadAction);
        form = new InformationObjectNodeForm(nodeSelection, extractorRegistry.visualProxy(null,null), positionPresenter.getForm(), infoPresenter.getForm());
        
        saveAction = new MagicAction("Speichern") {
            public void actionPerformed(ActionEvent event) {
                save();
            }
        };
        form.setSaveAction(saveAction);

        positionPresenter.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent event) {
                firePropertyChange("position" + getPropertyName(event), event.getOldValue(), event.getNewValue());
            }
        });

        infoPresenter.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent event) {
                firePropertyChange("information" + getPropertyName(event), event.getOldValue(), event.getNewValue());
            }
        });
        nodeSelection.addPropertyChangeListener("selectedNode", new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent event) {
                setSelectedNodeInternal((Node)event.getNewValue());
            }
        });

    }

    private void save() {
        InformationPositionNodeBuilder builder = manager.getAnnotationNodeBuilder();
        builder.withInformationObject(info);
        builder.withPosition(selectedNode);
        builder.withDescription(infoPresenter.getDescription());
        builder.withTitle(infoPresenter.getTitle());
        builder.from(Agent.ANONYMOUS);
        for (String tag: infoPresenter.getTags()){
            builder.withInformationTag(tag);
        }
        for (String tag:positionPresenter.getTags()){
            builder.withPositionTag(tag);
        }
        InformationObjectNode informationObjectNode = builder.getNode();
        // Juhu!

    }

    private void load() {
        info = null;
        try {
            form.showWait();
            info = extractorRegistry.getSelectedExtractor().load(manager);
            InformationObjectPosts posts = manager.getPosts(info.getId());
            addInfoTags(posts);
            addPositionTags(posts);

        } catch (Exception e) {
            form.showMessage("<html>Es ist ein fehler beim Laden der URL aufgetreten:<br>" + e.getLocalizedMessage() + "</html>");
        } finally {
            if (info != null ) {
                form.showForms();
                this.infoPresenter.setTitle(info.getTitle().getTitle());
                this.positionPresenter.setTitle(info.getTitle().getTitle());
            }
        }
    }


    private void addPositionTags(InformationObjectPosts posts) {
       Lock lock = positionTags.getReadWriteLock().writeLock();
        lock.lock();
        try{
            positionTags.clear();

        } finally {
            lock.unlock();
        }
        positionPresenter.setTags(positionTags);
    }

    private void addInfoTags(InformationObjectPosts posts) {
        Lock lock = infoTags.getReadWriteLock().writeLock();
        lock.lock();
        try{
                infoTags.clear();
                Collection<TagAnnotation> annotations = posts.getTags().values();
            for (TagAnnotation annotation:annotations){
                infoTags.addAll(annotation.getPositiveTags());
            }
        } finally {
            lock.unlock();
        }
        infoPresenter.setTags(Collections.<String>emptyList());
    }
    


    private String getPropertyName(PropertyChangeEvent event) {
        String name = event.getPropertyName();
        char[] chars = name.toCharArray();
        chars[0] = Character.toUpperCase(chars[0]);
        return new String(chars);
    }

    public void setCreateMode(){
        this.nodeSelection.setEnabled(true);
    }

    public void setEditMode(){
        this.nodeSelection.setEnabled(false);
    }

    public void setSelectedNode(Node node){
        this.nodeSelection.setSelectedNode(node);
    }

    private void setSelectedNodeInternal(Node node) {
        Node old = this.selectedNode;
        this.selectedNode = node;
        firePropertyChange("selectedNode", old,node);
    }

    public Node getSelectedNode(){
        return selectedNode;
    }
    /**
     *
     * @return
     */
    public InformationObjectNodeForm getForm(){
        return form;
    }

    public void showWait() {
        this.form.showWait();
    }

    public void showMessage(String s) {
        form.showMessage(s);
    }
}
