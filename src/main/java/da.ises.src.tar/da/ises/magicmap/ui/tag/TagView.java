package da.ises.magicmap.ui.tag;

import net.sf.magicmap.client.gui.views.View;

import javax.swing.*;

/**
 * <p>
 * Class TabView ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 21:11:16
 */
public class TagView extends View {
    private final TagPresenter tags;

    public TagView(TagPresenter tags) {
        super("AUA");
        this.tags = tags;
        super.setContent(buildViewComponent());
    }

    public String getName() {
        return "Tags";
    }

    /**
     * 
     * @return
     */
    protected JComponent buildViewComponent() {
        return tags.getView();
    }
}
