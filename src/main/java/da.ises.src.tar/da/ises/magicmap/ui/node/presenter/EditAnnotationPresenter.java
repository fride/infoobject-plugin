package da.ises.magicmap.ui.node.presenter;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.matchers.Matcher;
import da.ises.magicmap.ui.node.forms.EditAnnotationForm;
import net.sf.magicmap.client.utils.AbstractModel;
import net.sf.magicmap.client.utils.DocumentAdapter;

import java.util.*;

/**
 * <p>
 * Class EditAnnotationPresenter ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 27.07.2008
 *         Time: 21:44:13
 */
public class EditAnnotationPresenter extends AbstractModel {

    private EventList<String> recomendedTags;
    private EventList<String> yourTags;

    private EditAnnotationForm form;
    private String description;
    private DocumentAdapter descriptionAdapter;

    private String title;
    private DocumentAdapter titleAdapter;

    private DocumentAdapter tagAdapter;

    private final Matcher<String> tagMatcher = new Matcher<String>() {
        public boolean matches(String string) {
            return false;
        }
    };

    public EditAnnotationPresenter() {
        recomendedTags = new BasicEventList<String>();
        yourTags = new BasicEventList<String>();

    }

    public EditAnnotationForm getForm(){
        if (form == null){
            form = new EditAnnotationForm();
            descriptionAdapter = new DocumentAdapter(form.getDescriptionDocument()) {
                public void handleChange(String s) {
                    setDescriptionInernal(s);
                }
            };
            titleAdapter = new DocumentAdapter(form.getTitle()) {
                public void handleChange(String s) {
                    setTitleInternal(s);
                }
            };
            tagAdapter = new DocumentAdapter(form.getTagDocument()) {
                public void handleChange(String s) {
                    setTagsInternal(s);
                }
            };
        }
        return form;
    }



    private void setTitleInternal(String s) {
        String old = this.title;
        this.title = s;
        firePropertyChange("title", old,s);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.titleAdapter.setDocumentContents(title);
    }

    private void setDescriptionInernal(String s) {
        String old = this.description;
        this.description = s;
        firePropertyChange("descriptionAdapter", old,s);
    }

    public void setDescription(String newDesc) {
        descriptionAdapter.setDocumentContents(newDesc);

    }

    public String getDescription() {
        return description;
    }

    public List<String> getTags(){
        final ArrayList<String> temp_tags = new ArrayList<String>();
        String tagString = this.tagAdapter.getDocumentContents();
        if (tagString != null){
            String[] strings = tagString.split(",");
            for (String tag:strings){
                temp_tags.add(tag.trim());
            }
        }
        return temp_tags;

    }

    private void setTagsInternal(String tagString) {
        final Set<String> temp_tags = new HashSet<String>();
        if (tagString != null){
            String[] strings = tagString.split(",");
            for (String tag:strings){
                String t = tag.trim();
                if (t.length() > 0)
                temp_tags.add(t);
            }
        }
        firePropertyChange("tags", null, temp_tags);
        
    }


    public void setTags(List<String> tags) {
        StringBuilder b = new StringBuilder("");
        Iterator<String> stringIterator = tags.iterator();
        while (stringIterator.hasNext()){
            b.append(stringIterator.next());
            if (stringIterator.hasNext()){
                b.append(", ");
            }
        }
        this.tagAdapter.setDocumentContents(b.toString());
    }
}
