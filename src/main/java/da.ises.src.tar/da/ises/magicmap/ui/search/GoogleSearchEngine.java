package da.ises.magicmap.ui.search;

import da.ises.core.domain.infoobject.InformationObject;
import org.antlr.stringtemplate.StringTemplate;
import org.dom4j.Document;
import org.dom4j.Node;
import sun.awt.image.ImageWatched;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedList;
import java.util.List;

/**
 * <p>
* Class GoogleSearchEngine ZUSAMMENFASSUNG
* </p>
* <p>
* DETAILS
* </p>
*
* @author Jan Friderici
*         Date: 16.03.2008
*         Time: 16:34:35
*/
public class GoogleSearchEngine implements SearchEngine {
    private StringTemplate serachUrlTemplate = new StringTemplate("http://www.google.com/search?q=$QUERY$&start=$START$&num=50");
    private int current_page;
    private String query;

    public GoogleSearchEngine() {
    }

    public List<ImageWatched.Link> search(String query) {
        this.query = query;
        return search(query, 0);
    }

    public List<ImageWatched.Link> next() {
        return search(query, current_page + 10);
    }
    private List<ImageWatched.Link> search(String query, int offset) {
        current_page = offset;
        LinkedList<ImageWatched.Link> foundLinks = new LinkedList<ImageWatched.Link>();
        serachUrlTemplate.reset();
        serachUrlTemplate.setAttribute("QUERY", URLEncoder.encode(query));
        serachUrlTemplate.setAttribute("START", offset);
        try {

            HttpURLConnection conn = (HttpURLConnection) new URL(serachUrlTemplate.toString()).openConnection();

            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestProperty(
                    "user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322)");
            conn.setRequestProperty("Referer", "http://www.google.de/");
            conn.connect();
  
            //NekoSaxParser parser = new NekoSaxParser();
            final Document document = null; //parser.getDocument(conn.getInputStream());
            final List<Node> spans = document.selectNodes("/html/body/div[@id='res']/div/div[@class='g']");
            for (Node div:spans) {
                Node anchor = div.selectSingleNode("./*/a");
                if (anchor != null) {
                    Node table = div.selectSingleNode("./table");
                    //foundLinks.add(new ImageWatched.Link(anchor.valueOf("@href"), anchor.asXML()));
                }
            }
            System.out.print(document.asXML());

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | PluginSettings | File Templates.
        }
        return foundLinks;
    }

    public int getCurrentPage() {
        return current_page;
    }

    public int getPages() {
        return 0;
    }

    public String getQueryString() {
        return null;  //To change body of implemented methods use File | PluginSettings | File Templates.
    }

    public String getName() {
        return null;  //To change body of implemented methods use File | PluginSettings | File Templates.
    }

    /**
     * @return
     */
    public String getDescription() {
        return null;  //To change body of implemented methods use File | PluginSettings | File Templates.
    }

    /**
     * @param query
     */
    public void search(String query, SearchEngineCallback callback) {
        //To change body of implemented methods use File | PluginSettings | File Templates.
    }

    /**
     * @return
     */
    public List<InformationObject> getLinks() {
        return null;  //To change body of implemented methods use File | PluginSettings | File Templates.
    }

    /**
     * @return
     */
    public int getMaxResults() {
        return 0;  //To change body of implemented methods use File | PluginSettings | File Templates.
    }

    /**
     * @param results
     */
    public void setMaxResults(int results) {
        //To change body of implemented methods use File | PluginSettings | File Templates.
    }
}
