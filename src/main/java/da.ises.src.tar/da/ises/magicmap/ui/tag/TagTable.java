package da.ises.magicmap.ui.tag;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: janfriderici
 * Date: Jul 8, 2008
 * Time: 9:48:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class TagTable {
    private JTable table;
    private JTextField newTagield;
    
}
