package da.ises.magicmap.ui.graph;

import edu.umd.cs.piccolo.PCanvas;

/**
 * <p>
 * Class InformationGraphView ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 01:15:46
 */
public class InformationGraphView {

    private PCanvas nodeCanvas;
    private PCanvas edgeCanvas;

    
}
