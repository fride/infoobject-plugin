package da.ises.magicmap.ui.information.search;

import net.sf.json.JSONArray;
import org.antlr.stringtemplate.StringTemplate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

/**
 *
 */
public abstract class OpenSearch {
    private int maxResults;
    private String query;
    private StringTemplate queryTemplate;
    private LinkedList<String> foundLinks = new LinkedList<String>();
    private String name;
    private String description;
    private Map<String,Object> searchParams = new HashMap<String, Object>();

    protected OpenSearch(String queryTemplate, String name, String description) {
        this.queryTemplate = new StringTemplate(queryTemplate);
        this.name = name;
        this.description = description;
    }

    public String getQueryString() {
        return query;
    }

    public String getName() {
        return name;
    }

    /**
     * @return
     */
    public String getDescription() {
        return description;
    }

    @SuppressWarnings({"unchecked"})
    public List<String> search(String query) throws IOException {
        this.query = query;
        queryTemplate.reset();
        foundLinks.clear();

        URL searchURL = getSearchUrl();
        System.err.println("Search: " + searchURL.toString());
        HttpURLConnection con = (HttpURLConnection) searchURL.openConnection();
        InputStream inputStream = con.getInputStream();
        StringBuilder b = new StringBuilder();
        BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
        String line = in.readLine();
        while (line != null){
            b.append(line);
            line = in.readLine();
        }

        JSONArray array = JSONArray.fromObject(b.toString());
        if (2 == array.size()){
            return (getLinks(array.getJSONArray(1)));
        }
        return Collections.emptyList();

    }

    protected abstract List< String> getLinks(JSONArray jsonArray);
    /**
     *
     * @return
     * @throws java.net.MalformedURLException
     */
    protected URL getSearchUrl() throws MalformedURLException {
        queryTemplate.reset();
        queryTemplate.setAttribute("QUERY", query);
        queryTemplate.setAttribute("MAX_RESULTS", maxResults);
        for (Map.Entry<String,Object> entry: this.searchParams.entrySet()) {
            queryTemplate.setAttribute(entry.getKey(), entry.getValue());
        }
        return new URL(queryTemplate.toString());
    }
    protected void addSearchParam(String name, Object value) {
        searchParams.put(name,value);
    }


}
