package da.ises.magicmap.ui.util;

import com.jidesoft.popup.JidePopup;
import org.apache.commons.collections15.Predicate;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

/**
 *
 */
public class PopupTextField extends JTextField {
    private JidePopup popup;
    private Predicate showPopupPredicate;
    private Runnable showPopupAction;
    private Runnable hidePopupAction;
    private Runnable keyUpAction;

    public PopupTextField(JidePopup popup) throws HeadlessException {
        this.popup = popup;
    }

    public PopupTextField(String text, JidePopup popup) throws HeadlessException {
        super(text);
        this.popup = popup;
    }

    public PopupTextField(int columns, JidePopup popup) throws HeadlessException {
        super(columns);
        this.popup = popup;
    }

    public PopupTextField(String text, int columns, JidePopup popup) throws HeadlessException {
        super(text, columns);
        this.popup = popup;
    }

    public Predicate getShowPopupPredicate() {
        return showPopupPredicate;
    }

    public void setShowPopupPredicate(Predicate showPopupPredicate) {
        this.showPopupPredicate = showPopupPredicate;
    }

    protected void processKeyEvent(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            System.out.println("e = " + e);
            if (showPopup()) {
                System.out.println("Show Popup");
                popup.updateUI();
                popup.showPopup(this);
            }
            else if (e.getID() == KeyEvent.KEY_RELEASED && showPopupAction != null) {
                showPopupAction.run();
            }
            e.consume();
        }
        else if (e.getID() == KeyEvent.KEY_RELEASED && popup.isPopupVisible() && e.getKeyCode() == KeyEvent.VK_UP && keyUpAction != null){
            keyUpAction.run();
            e.consume();
        }
        else if (e.getID() == KeyEvent.KEY_RELEASED && popup.isPopupVisible() && e.getKeyCode() == KeyEvent.VK_ESCAPE) {
            popup.hidePopup();
            if (hidePopupAction != null) hidePopupAction.run();
            e.consume();
        } else {
            super.processKeyEvent(e);
        }
    }
    protected boolean showPopup() {
        return !popup.isPopupVisible() && (showPopupPredicate == null || showPopupPredicate.evaluate(null));
    }

    public void setKeyDownAction(Runnable showPopupAction) {
        this.showPopupAction = showPopupAction;
    }

    public void setHidePopupAction(Runnable hidePopupAction) {
        this.hidePopupAction = hidePopupAction;
    }

    public void setKeyUpAction(Runnable keyUpAction) {
        this.keyUpAction = keyUpAction;
    }
}
