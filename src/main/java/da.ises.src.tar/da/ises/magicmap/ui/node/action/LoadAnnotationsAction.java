package da.ises.magicmap.ui.node.action;

import da.ises.magicmap.controller.node.InformationNodeManager;
import net.sf.magicmap.client.model.node.Node;

import java.awt.event.ActionEvent;

/**
 *
 *
 */
public class LoadAnnotationsAction extends AbstractNodeAction {

    public LoadAnnotationsAction(InformationNodeManager manager) {
        super("Informationen finden",  manager);        
    }


    /**
     *
     * @param event
     */
    public void actionPerformed(ActionEvent event) {
        Node node = getSelectedNode();
        if (node == null || node.equals(Node.EMPTY_NODE)) {
            //loadNodes(getNodeManager().getCurrentMap(), 1);
        } else {
            loadNodes(node,0);
        }
    }

    protected boolean checkEnable() {
        return true;
    }

    /**
     *
     * @param node
     * @param depth
     */
    public void loadNodes(Node node, int depth) {
        getNodeManager().explodeNode(node, depth);
        
    }

}
