package da.ises.magicmap.ui.util;

import da.ises.core.domain.tag.Tagging;
import ca.odell.glazedlists.gui.TableFormat;
import ca.odell.glazedlists.gui.WritableTableFormat;
import ca.odell.glazedlists.gui.CheckableTableFormat;
import ca.odell.glazedlists.gui.AdvancedTableFormat;

import java.util.Comparator;

/**
 * 
 */
public class TaggingTableFormat implements WritableTableFormat<Tagging>, AdvancedTableFormat<Tagging> {
    private String names[] = new String[]{
        "Tag",
        "Positiv",
        "Benutzer"
    };
    public int getColumnCount() {
        return names.length;
    }

    public String getColumnName(int i) {
        return names[i];
    }

    public Object getColumnValue(Tagging tagging, int i) {
        switch (i) {
            case 0:
                return tagging.getTag().getRawValue();
            case 1:
                return tagging.isPositive();
            case 2:
                return tagging.getUser().getUserName();
        }
        throw new IllegalStateException("Invalid column");
    }

    public boolean isEditable(Tagging tagging, int i) {
        return i == 1;
    }

    public Tagging setColumnValue(Tagging tagging, Object value, int i) {
        if (i == 1){
            if (value instanceof String){
                tagging.setPositive(Boolean.parseBoolean((String) value));
            } else if (value instanceof  Boolean) {
                tagging.setPositive((Boolean)value);
            }
        }
        return tagging;
    }


    public Class getColumnClass(int i) {
        return i == 1 ? Boolean.class : String.class;
    }

    public Comparator getColumnComparator(int i) {
        return i == 1 ? booleanComparator : stringComparator;
    }
    private Comparator<String> stringComparator = new Comparator<String>() {
        public int compare(String o1, String o2) {
            return o1.compareTo(o2);
        }
    };
    private Comparator<Boolean> booleanComparator = new Comparator<Boolean>() {
        public int compare(Boolean o1, Boolean o2) {
            return o1.compareTo(o2);
        }
    };
}
