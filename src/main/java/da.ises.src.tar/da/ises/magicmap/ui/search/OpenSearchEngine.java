package da.ises.magicmap.ui.search;

import da.ises.core.domain.infoobject.InformationObject;
import net.sf.json.JSONArray;
import org.antlr.stringtemplate.StringTemplate;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

/**
 * <p>
 * Class OpenSearchEngine ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 22.03.2008
 *         Time: 12:30:07
 */
public abstract class OpenSearchEngine implements SearchEngine {

    private int maxResults;
    private String query;
    private StringTemplate queryTemplate;
    private LinkedList<InformationObject> foundLinks = new LinkedList<InformationObject>();
    private String name;
    private String description;
    private Map<String,Object> searchParams = new HashMap<String, Object>();

    /**
     * 
     * @param queryTemplate
     * @param name
     * @param description
     */
    protected OpenSearchEngine(String queryTemplate, String name, String description) {
        this.queryTemplate = new StringTemplate(queryTemplate);
        this.name = name;
        this.description = description;
    }

    public String getQueryString() {
        return query;
    }

    public String getName() {
        return name;
    }

    /**
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param query
     */
    @SuppressWarnings({"unchecked"})
    public void search(String query, SearchEngineCallback callback) {
        this.query = query;
        queryTemplate.reset();
        foundLinks.clear();
        try {
            URL searchURL = getSearchUrl();
            System.err.println("Search: " + searchURL.toString());
            HttpURLConnection con = (HttpURLConnection) searchURL.openConnection();
            InputStream inputStream = con.getInputStream();
            StringBuilder b = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
            String line = in.readLine();
            while (line != null){
                b.append(line);
                line = in.readLine();
            }

            JSONArray array = JSONArray.fromObject(b.toString());
            if (2 == array.size()){
                    foundLinks.addAll(getLinks(array.getJSONArray(1)));
             }
            callback.searchFinished(this);
        } catch (Throwable e) {
            callback.searchFailed(this,e);
        }
    }

    /**
     * 
     * @return
     * @throws MalformedURLException
     */
    protected URL getSearchUrl() throws MalformedURLException {
        queryTemplate.reset();
        queryTemplate.setAttribute("QUERY", query);
        queryTemplate.setAttribute("MAX_RESULTS", maxResults);
        for (Map.Entry<String,Object> entry: this.searchParams.entrySet()) {
            queryTemplate.setAttribute(entry.getKey(), entry.getValue());
        }
        return new URL(queryTemplate.toString());
    }

    protected abstract  Collection<InformationObject> getLinks(List<String> list);

    /**
     * @return
     */
    public List<InformationObject> getLinks() {
        return new ArrayList<InformationObject>(foundLinks);
    }

    /**
     * @return
     */
    public int getMaxResults() {
        return maxResults;
    }

    /**
     * @param results
     */
    public void setMaxResults(int results) {
        this.maxResults = results;
    }
    protected void addSearchParam(String name, Object value) {
        searchParams.put(name,value);     
    }
}
