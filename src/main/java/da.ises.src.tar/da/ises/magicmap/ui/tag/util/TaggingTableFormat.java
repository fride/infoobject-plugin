package da.ises.magicmap.ui.tag.util;

import ca.odell.glazedlists.gui.TableFormat;
import da.ises.magicmap.domain.tag.Taggings;

/**
 * <p>
 * Class TaggingTableFormat ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 21:04:17
 */
public class TaggingTableFormat implements TableFormat<Taggings> {
    private String names[] = new String[]{
            "Tag",
            "Url",
            "Gewicht"
    };
    public int getColumnCount() {
        return names.length;
    }

    public String getColumnName(int i) {
        return names[i];
    }

    public Object getColumnValue(Taggings taggings, int i) {
        switch (i){
            case 0:
                return taggings.getTag().getRawValue();
            case 1:
                return taggings.getNode().getDisplayName();
            case 2:
                return taggings.getWeight();
        }
        throw new IllegalStateException("Column "+ i);
    }
}
