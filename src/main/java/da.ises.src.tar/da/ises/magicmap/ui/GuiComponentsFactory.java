package da.ises.magicmap.ui;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: Jul 11, 2008
 * Time: 7:10:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class GuiComponentsFactory {
}
