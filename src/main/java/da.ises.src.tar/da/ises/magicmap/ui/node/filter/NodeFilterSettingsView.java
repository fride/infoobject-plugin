package da.ises.magicmap.ui.node.filter;

import com.jgoodies.forms.factories.ButtonBarFactory;
import da.ises.magicmap.domain.node.InformationNodeModel;
import da.ises.magicmap.domain.tag.InformationTagModel;
import net.sf.magicmap.client.gui.MainGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 *
 *
 */
public class NodeFilterSettingsView {
    private TagFilterSettings tagFilter;
    private final InformationNodeModel nodeModel;

    private AbstractAction showFilterSettingsAction;


    private JTabbedPane tabs;

    /**
     *
     * @param nodeModel
     */
    public NodeFilterSettingsView(InformationNodeModel nodeModel, InformationTagModel tagModel) {
        this.nodeModel = nodeModel;
        tagFilter = new TagFilterSettings(nodeModel,tagModel);
        tabs = new JTabbedPane();
        tabs.addTab("Tags", tagFilter.getView());

    }

    /**
     *
     * @return
     */
    public AbstractAction getShowFilterSettingsAction() {
        if (showFilterSettingsAction == null) {
            showFilterSettingsAction = new AbstractAction("Filtereinstellungen") {
                public void actionPerformed(ActionEvent event) {
                    JDialog dlg = new JDialog(MainGUI.getInstance().getMainFrame());
                    JPanel mainPanel = new JPanel(new BorderLayout());
                    mainPanel.add(tabs, BorderLayout.CENTER);
                    mainPanel.add(getButtonBar(dlg), BorderLayout.SOUTH);
                    dlg.setModal(true);
                    dlg.getContentPane().add(mainPanel);
                    dlg.pack();
                    dlg.setVisible(true);
                }
            };
        }
        return showFilterSettingsAction;
    }



    public JComponent getButtonBar(final JDialog dlg) {
        JButton okButton = new JButton(new AbstractAction("Filter einstellungen Anwenden") {
            public void actionPerformed(ActionEvent event) {
                dlg.setVisible(false);
                tagFilter.applySettings();
            }
        });
        return ButtonBarFactory.buildCenteredBar(okButton);
    }
}
