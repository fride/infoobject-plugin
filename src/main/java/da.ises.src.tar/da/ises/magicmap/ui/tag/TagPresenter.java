package da.ises.magicmap.ui.tag;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.swing.EventComboBoxModel;
import ca.odell.glazedlists.swing.EventTableModel;
import ca.odell.glazedlists.util.concurrent.Lock;
import da.ises.core.infoobject.Tag;
import da.ises.magicmap.domain.tag.*;
import da.ises.magicmap.ui.tag.util.TaggingTableFormat;
import net.sf.magicmap.client.utils.AbstractModel;

import javax.swing.*;
import java.util.WeakHashMap;

/**
 * <p>
 * Class TagPresenter ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 20:41:54
 */
public class TagPresenter extends AbstractModel {
    private EventList<Tag> tags = new BasicEventList<Tag>();
    private EventList<Taggings> taggingsList = new BasicEventList<Taggings>();
    private TagModel tagModel;
    private WeakHashMap<Object[], Taggings> taggingsMap = new WeakHashMap<Object[], Taggings>();
    private TagsForm form;
    private JComponent view;

    public TagPresenter(TagModel tagModel) {
        this.tagModel = tagModel;
        this.tagModel.addTagModelListener(new TagModelListener() {
            public void tagAdded(TagEvent tag) {
                addTag(tag.getTag());
            }

            public void tagRemoved(TagEvent tag) {
                removeTag(tag.getTag());
            }

            public void taggingAdded(TaggingEvent tagging) {
                addTaggings(tagging);
            }

            public void taggingRemoved(TaggingEvent tagging) {
                
            }
        });
    }

    public JComponent getView(){
        if (view == null){
            EventComboBoxModel<Tag> tagModel = new EventComboBoxModel<Tag>(tags);
            EventTableModel<Taggings> taggingsModel = new EventTableModel<Taggings>(taggingsList, new TaggingTableFormat());
            form = new TagsForm(tagModel, taggingsModel);
            view = form.getView();
            view.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        }
        return view;
    }
    
    private void addTaggings(TaggingEvent event) {
        addTag(event.getTag());
        final Lock lock = taggingsList.getReadWriteLock().writeLock();
        try {
            lock.lock();
            final Taggings taggings = taggingsMap.get(new Object[]{event.getTag(), event.getTag()});
            if (taggings != null){
                taggings.setWeight(tagModel.nodeCount(event.getTag()));
            }
            else {
                taggingsList.add(new Taggings(event.getTag(), event.getNode(), tagModel.nodeCount(event.getTag())));
            }
        } finally {
            lock.unlock();
        }
    }

    private void removeTag(Tag tag) {

        final Lock lock = tags.getReadWriteLock().writeLock();
        try {
            lock.lock();
            tags.remove(tag);
        } finally{
            lock.unlock();
        }
    }

    private void addTag(Tag tag) {
        if (tags.contains(tag)) return;
        final Lock lock = tags.getReadWriteLock().writeLock();
        try {
            lock.lock();
            tags.add(tag);
        } finally{
            lock.unlock();
        }
    }
}
