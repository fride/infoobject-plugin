package da.ises.magicmap.ui.node.action;

import da.ises.magicmap.controller.node.InformationNodeManager;
import da.ises.magicmap.domain.node.AbstractInformationNode;

import java.awt.event.ActionEvent;


/**
 *
 * 
 */
public class FindRelatedNodesAction extends AbstractNodeAction{
    public FindRelatedNodesAction(InformationNodeManager manager) {
        super("Verwandte Informationen finden", manager);
    }

    public void actionPerformed(ActionEvent event) {
        
    }


    protected boolean checkEnable() {
        return super.checkEnable() && getSelectedNode() instanceof AbstractInformationNode;
    }

    /**
     * 
     * @return
     */
    AbstractInformationNode getInformationNode() {
        return (AbstractInformationNode) getSelectedNode();
    }
}
