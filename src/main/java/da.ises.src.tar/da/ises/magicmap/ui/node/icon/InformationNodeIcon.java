package da.ises.magicmap.ui.node.icon;

import net.sf.magicmap.client.gui.utils.icon.INodeIcon;
import net.sf.magicmap.client.gui.utils.GUIUtils;
import net.sf.magicmap.client.gui.utils.GUIBuilder;
import net.sf.magicmap.client.model.node.Node;

import javax.swing.*;
import java.awt.*;

/**
 * <p>
 * Class InformationNodeIcon ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 26.07.2008
 *         Time: 09:30:59
 */
public class InformationNodeIcon implements INodeIcon {

    private ImageIcon icon = GUIBuilder.getToolIcon("unkown.png","NodeIcons");
    private ImageIcon overLay = GUIBuilder.getToolIcon("overlay_fixiert.png","NodeIcons");


    public Icon getIcon(Node node) {
        return icon;
    }

    public Color getFgColor(Node node) {
        return Color.blue;
    }

    public Color getBgColor(Node node) {
        return Color.WHITE;
    }
}
