package da.ises.magicmap.ui.settings;

import da.ises.magicmap.application.settings.RemoteRepositorySettings;
import da.ises.magicmap.application.settings.PluginSettings;
import da.ises.magicmap.application.settings.SettingsFactory;
import da.ises.magicmap.ui.util.MenuBarUtils;
import da.ises.magicmap.ui.components.GuiComponentFactory;

import javax.swing.*;

import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.FilterList;
import ca.odell.glazedlists.impl.matchers.NotMatcher;
import ca.odell.glazedlists.matchers.Matcher;
import ca.odell.glazedlists.swing.EventTableModel;
import ca.odell.glazedlists.swing.EventComboBoxModel;
import ca.odell.glazedlists.swing.EventSelectionModel;

import java.awt.event.ActionEvent;
import java.awt.*;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import net.sf.magicmap.client.gui.MainGUI;
import net.sf.magicmap.client.gui.utils.MagicAction;
import net.sf.magicmap.client.utils.DocumentAdapter;
import org.bushe.swing.event.EventBus;

/**
 *
 *
 */
public class SettingsView {
    private JTable settingstable;
    private JButton addButton;
    private JButton delButon;
    private JButton loadButon;
    private JButton saveButon;
    private JComboBox homeBox;

    private JTextField user = new JTextField();
    private JCheckBox shared = new JCheckBox();
    private JCheckBox allowAnonymous = new JCheckBox();
    private JTextField repositoryId = new JTextField();
    
    private JComponent view;
    private EventList<RemoteRepositorySettings> remoteRepositories = new BasicEventList<RemoteRepositorySettings>();
    private RepositorySettingsTableFormat format = new RepositorySettingsTableFormat();
    private EventTableModel<RemoteRepositorySettings> repositoryModel = new EventTableModel<RemoteRepositorySettings>(remoteRepositories, format);
    private EventSelectionModel<RemoteRepositorySettings> selectionModel;
    private EventComboBoxModel<RemoteRepositorySettings> homeRepositories;


    private Matcher<RemoteRepositorySettings> localMather = new Matcher<RemoteRepositorySettings>() {
        public boolean matches(RemoteRepositorySettings remoteRepositorySettings) {
            return !remoteRepositorySettings.isLocal();
        }
    };

    private Matcher<RemoteRepositorySettings> homeMatcher = new NotMatcher<RemoteRepositorySettings>(localMather);
    private ListCellRenderer reposRenderer = new DefaultListCellRenderer(){
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel comp = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value == null) {
                comp.setText("W�hlen Sie eine Repository...");
            } else {
                comp.setText(((RemoteRepositorySettings)value).getRepositoryId());
            }
            return comp;    //To change body of overridden methods use File | PluginSettings | File Templates.
        }
    };
    private GuiComponentFactory component;

    public SettingsView(GuiComponentFactory component) {
        this.component = component;
        homeRepositories = new EventComboBoxModel<RemoteRepositorySettings>(new FilterList<RemoteRepositorySettings>(remoteRepositories,localMather));
        selectionModel = new EventSelectionModel<RemoteRepositorySettings>(remoteRepositories);
        selectionModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }



    public JComponent getRemateView(){
        FormLayout l = new FormLayout("right:p", "p");
        CellConstraints cc = new CellConstraints();
        PanelBuilder b = new DefaultFormBuilder(l);
        b.appendRelatedComponentsGapColumn();
        b.appendColumn("p:grow");

        b.appendRelatedComponentsGapColumn();
        b.appendColumn("p");
        b.add(new JLabel("Home repository:"), cc.xy(1, b.getRowCount()));
        b.add(homeBox, cc.xy(3,b.getRowCount()));

        b.appendRelatedComponentsGapRow();
        b.appendRow("p");

        int start = b.getRowCount();
        b.add(addButton, cc.xy(b.getColumnCount(),b.getRowCount()));

        b.appendRelatedComponentsGapRow();
        b.appendRow("p");

        b.add(delButon, cc.xy(b.getColumnCount(),b.getRowCount()));

        b.appendRow("p:grow");

        b.add(new JScrollPane(settingstable), cc.xywh(3,start,1,b.getRowCount()-2));
        b.add(new JLabel("Repositories"), cc.xy(1,b.getRowCount()));

        return b.getPanel();

    }
    public JComponent getLocalSettingsView() {

        createComponents();
        FormLayout l = new FormLayout("right:p", "p");
        CellConstraints cc = new CellConstraints();
        PanelBuilder b = new DefaultFormBuilder(l);
        b.appendRelatedComponentsGapColumn();
        b.appendColumn("p:grow");

        b.add(new JLabel("Benutzername"), cc.xy(1,b.getRowCount()));
        b.add(user, cc.xy(3, b.getRowCount()));

        b.appendRelatedComponentsGapRow();
        b.appendRow("p");

        b.add(new JLabel("Name der Repository"), cc.xy(1,b.getRowCount()));
        b.add(repositoryId, cc.xy(3, b.getRowCount()));

        b.appendRelatedComponentsGapRow();
        b.appendRow("p");
        b.add(new JLabel("Repository ver�ffentlichen"), cc.xy(1,b.getRowCount()));
        b.add(shared, cc.xy(3, b.getRowCount()));

        b.appendRelatedComponentsGapRow();
        b.appendRow("p");
        b.add(new JLabel("Anonymen Zugriff erlauben"), cc.xy(1,b.getRowCount()));
        b.add(allowAnonymous, cc.xy(3, b.getRowCount()));


        return b.getPanel();

    }

    public JComponent getView() {
        if (view == null) {
            createComponents();
            FormLayout l = new FormLayout("p:grow", "p");
            CellConstraints cc = new CellConstraints();
            PanelBuilder b = new DefaultFormBuilder(l);

            b.setRow(b.getRowCount());
            b.addSeparator("Lokale Einstellungen");
            b.appendRelatedComponentsGapRow();
            b.appendRow("p");
            b.add(getLocalSettingsView(), cc.xy(1,b.getRowCount(), CellConstraints.FILL, CellConstraints.FILL));
            b.appendUnrelatedComponentsGapRow();
            b.appendRow("p");

            b.setRow(b.getRowCount());
            b.addSeparator("Entfernte Repositories");
            b.appendRelatedComponentsGapRow();
            b.appendRow("p:grow");
            b.add(getRemateView(), cc.xy(1,b.getRowCount(),CellConstraints.FILL, CellConstraints.FILL));

            b.appendUnrelatedComponentsGapRow();
            b.appendRow("p");

            b.add(ButtonBarFactory.buildRightAlignedBar(loadButon,saveButon), cc.xyw(1,b.getRowCount(), b.getColumnCount()));

            view = b.getPanel();



        }
        return view;
    }

    private void createComponents() {
        settingstable = new JTable(repositoryModel);
        addButton = new JButton(new AbstractAction("+") {
            public void actionPerformed(ActionEvent e) {
                RemoteRepositorySettings s = new RemoteRepositorySettings();
                s.setRepositoryId("Neue Repository");
                remoteRepositories.add(s);
                settingstable.requestFocusInWindow();
                //selectionModel.setLeadSelectionIndex(settingstable.getRowCount()-1);
                selectionModel.setSelectionInterval(settingstable.getRowCount()-1,settingstable.getRowCount()-1);
                settingstable.editCellAt(settingstable.getRowCount()-1,0);
            }
        });
        delButon = new JButton("-");
        loadButon = new JButton(new AbstractAction("Laden") {
            public void actionPerformed(ActionEvent e) {
                load();
            }
        });
        saveButon = new JButton(new AbstractAction("Speichern") {
            public void actionPerformed(ActionEvent e) {
                save();
            }
        });

        homeBox = new JComboBox(homeRepositories);
        homeBox.setRenderer(reposRenderer);

        new DocumentAdapter(user){
            public void handleChange(String s) {
                checkEnable();
            }
        };
        new DocumentAdapter(repositoryId){
            public void handleChange(String s) {
                checkEnable();
            }
        };
        saveButon.setEnabled(false);
    }

    private void checkEnable() {
        saveButon.setEnabled(user.getText() != null &&
                user.getText().length() > 2 &&
                repositoryId.getText() != null &&
                repositoryId.getText().length() > 2);
    }

    public void load() {
        PluginSettings pluginSettings = SettingsFactory.get();
        setSettings(pluginSettings);
        
    }

    private void setSettings(PluginSettings pluginSettings) {
        format.setHomeId(pluginSettings.getHomeRepository());
        user.setText(pluginSettings.getUserName());
        repositoryId.setText(pluginSettings.getLocalRepositoryId());
        shared.setSelected(pluginSettings.isShared());
        allowAnonymous.setSelected(pluginSettings.isAllowAnonymous());
        remoteRepositories.clear();
        for (RemoteRepositorySettings reposet: pluginSettings.getRepositories().values()){
            this.remoteRepositories.add(reposet);
        }
    }

    public void save() {
        PluginSettings pluginSettings = SettingsFactory.get();
        pluginSettings.setUserName(user.getText());
        pluginSettings.setLocalRepositoryId(repositoryId.getText());
        pluginSettings.setShared(shared.isSelected());
        pluginSettings.setAllowAnonymous(allowAnonymous.isSelected());
        
        for (RemoteRepositorySettings repos: remoteRepositories) {
            pluginSettings.getRepositories().put(repos.getRepositoryId(), repos);
        }
        SettingsFactory.save(pluginSettings);
        EventBus.publish(pluginSettings);
    }
    
    public void start() {
        final JMenu menu = component.getInfoObjectMenu();
        menu.add(new JMenuItem(new MagicAction("Einstellungen") {
            public void actionPerformed(ActionEvent event) {
                showSettings(true);
            }
        }));
    }

    public void showSettings(boolean firstTime) {
        JDialog dlg = new JDialog(MainGUI.getInstance().getMainFrame());
        JComponent component = getView();
        component.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        dlg.getContentPane().add(component);
        dlg.pack();
        saveButon.setEnabled(false);
        dlg.setVisible(true);
    }
}
