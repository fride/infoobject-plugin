package da.ises.magicmap.ui.session;

import da.ises.magicmap.ui.util.MenuBarUtils;
import da.ises.magicmap.ui.log.LogEvent;
import da.ises.magicmap.application.session.LoginEventHandler;
import da.ises.magicmap.application.session.LoginEvent;
import net.sf.magicmap.client.gui.utils.MagicAction;
import net.sf.magicmap.client.gui.utils.GUIBuilder;
import net.sf.magicmap.client.gui.utils.GUIConstants;
import net.sf.magicmap.client.gui.MainFrame;
import net.sf.magicmap.client.gui.MainGUI;
import net.sf.magicmap.client.utils.Settings;

import javax.swing.*;
import java.awt.event.ActionEvent;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.CellConstraints;
import org.bushe.swing.event.annotation.AnnotationProcessor;
import org.bushe.swing.event.annotation.EventSubscriber;
import org.bushe.swing.event.EventBus;

/**
 *
 */
public class LoginAction extends MagicAction implements LoginEventHandler {

    public LoginAction() {
        super("Daises MagicSession starten", GUIConstants.ICON_CONNECT);
        setSelected(false);
        AnnotationProcessor.process(this);
    }


    private void login() {
        System.out.println("Login...");
        PanelBuilder b = new DefaultFormBuilder(new FormLayout("p,3dlu,p:grow", "p,3dlu,p,12dlu,p"));
        CellConstraints cc = new CellConstraints();
        final JTextField name = new JTextField();
        final JPasswordField password = new JPasswordField();

        b.add(new JLabel("Name"), cc.xy(1,1));
        b.add(name, cc.xy(3,1));

        b.add(new JLabel("Passwort"), cc.xy(1,3));
        b.add(password, cc.xy(3,3));
        b.add(new JButton(new AbstractAction("Login") {
            public void actionPerformed(ActionEvent event) {
                login(name.getText(), password.getPassword());
            }
        }), cc.xy(3,5));
        final JPanel jPanel = b.getPanel();
        jPanel.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));

        final JDialog dlg = new LoginDialog(MainGUI.getInstance().getMainFrame(),jPanel);
        name.setText(Settings.getClientName());

        dlg.pack();
        dlg.setVisible(true);


    }

    public void actionPerformed(ActionEvent event) {
        System.out.println("isSelected() = " + isSelected());
        login();

    }

    /**
     *
     * @param user
     * @param passwd
     */
    public void login(String user, char[] passwd) {
        //PluginApplication.get().login(user, passwd);
    }

    /**
     *
     * @param mainFrame
     */
    public void registerMenus(MainFrame mainFrame) {
        final JMenuBar bar = mainFrame.getJMenuBar();
        MenuBarUtils utils = new MenuBarUtils();
        utils.addMenuItem("Infoobekte", bar, GUIBuilder.createCheckBoxMenuItem(this,false));
    }

    @EventSubscriber(eventClass = LoginEvent.class)
    public void onEvent(LoginEvent event) {
        switch (event.getResult()) {
            case LOGGED_IN:
                setEnabled(false);
                setSelected(true);
                EventBus.publish(new LogEvent("Logged in as " + event.getUser().getUserName(), LogEvent.Type.MESSAGE));
                break;
            default:
                setEnabled(true);
                setSelected(false);
                break;
        }
    }
}
