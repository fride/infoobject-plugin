package da.ises.magicmap.ui.tag.util;

/**
 * 
 */
public class TagItem {
    private String tagRaw;
    private String authorName;
    private String serverId;
    private boolean positive;

    public TagItem() {
    }

    public TagItem(String tagRaw, String authorName, String serverId, boolean positive) {
        this.tagRaw = tagRaw;
        this.authorName = authorName;
        this.serverId = serverId;
        this.positive = positive;
    }

    public String getTagRaw() {
        return tagRaw;
    }

    public void setTagRaw(String tagRaw) {
        this.tagRaw = tagRaw;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public boolean isPositive() {
        return positive;
    }

    public void setPositive(boolean positive) {
        this.positive = positive;
    }

    public String getServerId() {
        return serverId;
    }

    public void setServerId(String serverId) {
        this.serverId = serverId;
    }

    public String toString() {
        StringBuilder b = new StringBuilder();
        b.append(positive ? "+" : "-");
        b.append(tagRaw);
        b.append(" (");
        b.append(authorName);
        b.append("@").append(serverId).append(")");
        return b.toString();
    }
}
