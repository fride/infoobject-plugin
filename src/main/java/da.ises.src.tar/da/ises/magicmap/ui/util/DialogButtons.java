package da.ises.magicmap.ui.util;

import com.jgoodies.forms.builder.ButtonBarBuilder;

import javax.swing.*;

/**
 *
 *
 */
public class DialogButtons {

    /**
     * 
     * @param actions
     * @return
     */
    public static JComponent createPanel(Action[]... actions){
        ButtonBarBuilder builder = new ButtonBarBuilder();
        for (Action[] actionGroup:actions) {
            JButton[] buttons = new JButton[actionGroup.length];
            for (int i = 0; i< actionGroup.length;++i){
                buttons[i] = new JButton(actionGroup[i]);
            }
            builder.addGriddedButtons(buttons);
        }
        return builder.getPanel();
    }

    /**
     * 
     * @param actions
     * @return
     */
    public static JComponent createPanel(Action... actions){
        ButtonBarBuilder builder = new ButtonBarBuilder();
        JButton[] buttons = new JButton[actions.length];
        for (int i = 0; i< actions.length;++i){
            buttons[i] = new JButton(actions[i]);
        }
        builder.addGriddedButtons(buttons);
        return builder.getPanel();
    }
}
