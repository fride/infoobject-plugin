package da.ises.magicmap.ui.tag.util;

/**
 * 
 */
public interface TagNodeInterface {


    /**
     * 
     * @return
     */
    TagNodeInterface getParent();

    /**
     * 
     * @return
     */
    String getTag();

    /**
     * 
     * @return
     */
    String getUser();

    /**
     * 
     * @return
     */
    String isPositive();

    /**
     * 
     * @return
     */
    String getTaggedName();
    /**
     * 
     * @return
     */
    int getChildCount();

}
