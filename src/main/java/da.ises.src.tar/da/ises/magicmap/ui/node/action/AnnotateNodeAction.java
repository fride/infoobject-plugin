package da.ises.magicmap.ui.node.action;

import da.ises.magicmap.controller.node.InformationNodeManager;
import da.ises.magicmap.ui.extractor.ExtractorRegistryUi;
import da.ises.magicmap.ui.node.presenter.InformationObjectNodePresenter;
import net.sf.magicmap.client.gui.MainGUI;

import javax.swing.*;
import java.awt.event.ActionEvent;


public class AnnotateNodeAction extends AbstractNodeAction {
    private InformationObjectNodePresenter presenter;

    public AnnotateNodeAction(ExtractorRegistryUi extractorRegistry, InformationNodeManager manager) {
        super("Verbindung zu Information anlegen",manager);
        presenter = new InformationObjectNodePresenter(extractorRegistry, manager);
    }


    public void actionPerformed(ActionEvent event) {
        final JDialog dlg = new JDialog(MainGUI.getInstance().getMainFrame());
        JComponent view = presenter.getForm().getView();
        view.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        dlg.getContentPane().add(view);
        presenter.setSelectedNode(getSelectedNode());
        presenter.showMessage("<html>Bittel w�hlen Sie einen Knoten aus und geben Sie eine URL ein.</html>");
        dlg.pack();
        dlg.setVisible(true);
    }
}
