package da.ises.magicmap.ui.node.action;

import da.ises.magicmap.controller.node.InformationNodeManager;

import java.awt.event.ActionEvent;

/**
 * <p>
 * Class EditNodeAction ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 27.07.2008
 *         Time: 23:37:58
 */
public class EditNodeAction extends AbstractNodeAction{
    /**
     * @param s
     * @param manager
     */
    public EditNodeAction(InformationNodeManager manager) {
        super("Information editieren", manager);
    }

    public void actionPerformed(ActionEvent event) {
        
    }
}
