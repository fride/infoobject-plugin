package da.ises.magicmap.ui.node;

import net.sf.magicmap.client.interfaces.MapViewListener;
import net.sf.magicmap.client.model.node.Node;
import net.sf.magicmap.client.gui.MainFrame;
import net.sf.magicmap.client.gui.utils.GUIUtils;
import edu.umd.cs.piccolo.event.PInputEvent;
import da.ises.magicmap.domain.node.AbstractInformationNode;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * 
 */
public class InformationNodeClickHandler implements MapViewListener {


    final Logger logger = LoggerFactory.getLogger(InformationNodeClickHandler.class);

    public InformationNodeClickHandler() {

    }

    public void nodeClicked(Node node, PInputEvent event) {
        logger.debug("node clicked{}. ", event);
        if (event.getClickCount() > 1 && node instanceof AbstractInformationNode) {
            handleDouble(((AbstractInformationNode)node));
        }
    }

    public void nodeRightClicked(Node node, PInputEvent event) {
        event.setHandled(false);        
    }

    private void handleDouble(AbstractInformationNode abstractInformationNode) {
        if (GUIUtils.isOsX()) {
            try {
                Runtime.getRuntime().exec("open " + abstractInformationNode.getInformationObject().getId());
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {

        }
    }

    public void rightClicked(PInputEvent event) {
        event.setHandled(false);
    }

    public void nodeFixiated(Node node) {
        
    }

    public void leftClicked(PInputEvent event) {
        // Nix zu tun ;-)
    }
}
