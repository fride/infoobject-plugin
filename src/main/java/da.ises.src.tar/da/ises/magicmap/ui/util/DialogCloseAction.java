package da.ises.magicmap.ui.util;

import net.sf.magicmap.client.gui.utils.MagicAction;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * 
 */
public abstract class DialogCloseAction extends MagicAction{
    private JDialog dlg;
    private ExceptionHandler handler;

    public static interface ExceptionHandler{
        void handleException(Exception e);
    }

    public DialogCloseAction(String s, JDialog dlg) {
        super(s);
        this.dlg = dlg;
    }

    public DialogCloseAction(String s, String s1, JDialog dlg) {
        super(s, s1);
        this.dlg = dlg;
    }

    public DialogCloseAction(String s, String s1, String s2, JDialog dlg) {
        super(s, s1, s2);
        this.dlg = dlg;
    }

    public void setHandler(ExceptionHandler handler) {
        this.handler = handler;
    }

    public void actionPerformed(ActionEvent event) {
        try {
            executeAction(event);
            dlg.setVisible(false);
            dlg = null;
        } catch (Exception e) {
            if (handler != null){
                handler.handleException(e);
            } else {
                e.printStackTrace();
            }
        }
    }

    protected abstract void executeAction(ActionEvent event) throws Exception;
}
