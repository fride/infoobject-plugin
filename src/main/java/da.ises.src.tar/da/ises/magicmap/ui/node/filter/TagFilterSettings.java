package da.ises.magicmap.ui.node.filter;

import da.ises.magicmap.domain.node.InformationNodeModel;
import da.ises.magicmap.domain.tag.InformationTagModel;
import net.sf.magicmap.client.utils.AbstractModel;
import net.sf.magicmap.client.utils.DocumentAdapter;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.util.concurrent.Lock;
import ca.odell.glazedlists.swing.EventListModel;
import ca.odell.glazedlists.swing.EventSelectionModel;

import javax.swing.*;
import javax.swing.text.PlainDocument;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.builder.DefaultFormBuilder;

import java.awt.event.*;
import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: Jul 14, 2008
 * Time: 7:32:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class TagFilterSettings extends AbstractModel {
    private final InformationNodeModel nodeModel;
    private boolean enabled;
    private TagFilter filter;
    private final EventList<String> tags = new BasicEventList<String>();
    private final EventListModel<String> tagModel = new EventListModel<String>(tags);
    private EventSelectionModel<String> tagSelectionModel = new EventSelectionModel<String>(tags);
    private final JCheckBox enableBox = new JCheckBox("Filter aktivieren");
    private  JComponent view;
    private JList list;
    private JTextField editFieled = new JTextField(9);
    private DocumentAdapter newAdapter = new DocumentAdapter(editFieled) {
        public void handleChange(String s) {

        }
    };

    public TagFilterSettings(InformationNodeModel nodeModel, InformationTagModel tagModel) {
        this.nodeModel = nodeModel;
        filter = new TagFilter(tagModel, nodeModel);
        tagSelectionModel.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                EventList<String> selected = tagSelectionModel.getSelected();
                if (selected.size() == 1) {
                    newAdapter.setDocumentContents(selected.get(0));

                }
            }
        });
        editFieled.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tags.add(editFieled.getText());
                editFieled.setText("");
            }
        });
    }
    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        updateFilter();
        if (enabled) {
            nodeModel.addFilter(filter);
        } else {
            nodeModel.removeFilter(filter);
        }
        nodeModel.filterChanged();
        firePropertyChange("enabled", !enabled, enabled);
    }

    private void updateFilter() {
        filter.setTags(tags);
    }
    public JComponent getView() {
        if (view == null) {
            FormLayout l = new FormLayout("p");
            CellConstraints cc = new CellConstraints();
            DefaultFormBuilder b = new DefaultFormBuilder(l);
            b.appendRelatedComponentsGapColumn();
            b.appendColumn("fill:p:grow");

            b.appendRow("p");
            b.add(enableBox, cc.xy(b.getColumnCount(),b.getRowCount()));
            b.appendUnrelatedComponentsGapRow();
            b.appendRow("d:grow");
            b.add(new JLabel("Tags"), cc.xy(1,b.getRowCount(),CellConstraints.RIGHT, CellConstraints.FILL));

            list = new JList(tagModel);
            //list.setLayoutOrientation(JList.HORIZONTAL_WRAP);
            list.setVisibleRowCount(6);
            JScrollPane pane = new JScrollPane(list);
            pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            b.add(pane, cc.xy(b.getColumnCount(), b.getRowCount(), CellConstraints.FILL, CellConstraints.FILL));

            b.appendRelatedComponentsGapColumn();

            b.appendColumn("p");
            b.add(new JButton("-"), cc.xy(b.getColumnCount(), b.getRowCount(), CellConstraints.CENTER, CellConstraints.BOTTOM));
            b.appendRelatedComponentsGapRow();
            b.appendRow("p");
            b.add(editFieled,cc.xy(b.getColumnCount()-2, b.getRowCount()));
            b.add(new JButton(new AbstractAction("+") {
                public void actionPerformed(ActionEvent e) {
                    tags.add(editFieled.getText());
                    editFieled.setText("");
                }
            }),cc.xy(b.getColumnCount(), b.getRowCount()));
            view = b.getPanel();
        }
        return view;
    }



    public void applySettings() {
        filter.setTags(tags);
        filter.setEnabled(enableBox.isSelected());
    }
}
