package da.ises.magicmap.ui.node.action;

import da.ises.magicmap.domain.node.AbstractInformationNode;
import da.ises.magicmap.controller.node.InformationNodeManager;
import da.ises.core.domain.infoobject.InformationObject;

import java.awt.event.ActionEvent;

/**
 *
 * 
 */
public class ExpoandNodeAction extends AbstractNodeAction {
    /**
     * @param s
     * @param nodeModel
     */
    public ExpoandNodeAction(String s, InformationNodeManager nodeModel) {
        super(s, nodeModel);
    }

    public void actionPerformed(ActionEvent event) {
        if (checkEnable()) {
            AbstractInformationNode node = (AbstractInformationNode) getSelectedNode();
            InformationObject informationObject = node.getInformationObject();
            
        }

    }

    protected boolean checkEnable() {
        return super.checkEnable() && getSelectedNode() instanceof AbstractInformationNode ;
    }
}
