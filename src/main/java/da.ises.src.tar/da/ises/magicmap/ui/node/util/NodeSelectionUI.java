package da.ises.magicmap.ui.node.util;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.swing.EventComboBoxModel;
import ca.odell.glazedlists.util.concurrent.Lock;
import net.sf.magicmap.client.gui.forms.UserInterface;
import net.sf.magicmap.client.interfaces.NodeModelListener;
import net.sf.magicmap.client.model.node.ClientNode;
import net.sf.magicmap.client.model.node.INodeModel;
import net.sf.magicmap.client.model.node.Node;
import net.sf.magicmap.client.model.node.NodeModel;
import net.sf.magicmap.client.utils.AbstractModel;

import javax.swing.*;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

/**
 * <p>
 * Class NodeSelectionUI ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 27.07.2008
 *         Time: 17:44:11
 */
public class NodeSelectionUI extends AbstractModel implements UserInterface {
    private INodeModel nodeModel;
    private EventList<Node> nodeList;
    private EventComboBoxModel<Node> eventNodeModel;
    private JComboBox comboView;
    private JList listView;
    private Node selectedNode;

    public NodeSelectionUI(INodeModel nodeModel) {
        this.nodeModel = nodeModel;
        nodeList = new BasicEventList<Node>();
        eventNodeModel = new EventComboBoxModel<Node>(nodeList);
        addNode(Node.EMPTY_NODE);
        nodeModel.addNodeModelListener(new NodeModelListener() {
            public void nodeAddedEvent(Node node) {
                addNode(node);
            }

            public void nodeUpdatedEvent(Node node, int i, Object o) {
                
            }

            public void nodeRemovedEvent(Node node) {
                removeNode(node);
            }
        });
    }

    public void setEnabled(boolean enabled){
        visualProxy(null,null).setEnabled(enabled);
    }
    private void removeNode(Node node) {
        Lock lock = nodeList.getReadWriteLock().writeLock();
        try {
            lock.lock();
            nodeList.remove(node);
        } finally {
            lock.unlock();
        }
    }

    private void addNode(Node node) {
        Lock lock = nodeList.getReadWriteLock().writeLock();
        try {
            lock.lock();
            nodeList.add(node);
        } finally {
            lock.unlock();
        }
    }

    public void setSelectedNode(Node node){
        Node old = this.selectedNode;
        this.selectedNode = node;
        if (eventNodeModel.getSelectedItem() != node){
            this.eventNodeModel.setSelectedItem(node);
        }
        firePropertyChange("selectedNode",old,selectedNode);

    }
    public JComponent visualProxy(String s, JComponent jComponent) throws IllegalArgumentException {
        JComponent proxy = null;
        if ("combo".equals(s)){
            proxy = createCombo();
        } else if ("listView".equals(s)){
            proxy = createList();
        }
        return proxy;
    }

    private JComponent createList() {
        if (listView == null){
            listView = new JList(eventNodeModel);
            listView.setCellRenderer(new NodeCellrenderer());
            listView.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            listView.addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent event) {
                    setSelectedNode((Node) listView.getSelectedValue());
                }
            });
        }
        return listView;
    }

    private JComponent createCombo() {
        if (comboView == null) {
            comboView = new JComboBox(eventNodeModel);
            comboView.addItemListener(new ItemListener() {
                public void itemStateChanged(ItemEvent event) {
                    setSelectedNode((Node)comboView.getSelectedItem());
                }
            });
            comboView.setRenderer(new NodeCellrenderer());
        }
        return comboView;
    }

    public static void main(String[] args) {
           NodeModel m = new NodeModel();
        NodeSelectionUI ui = new NodeSelectionUI(m);
        JFrame f = new JFrame();
        JSplitPane p = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                new JScrollPane(ui.visualProxy("list",null)), ui.visualProxy("combo",null));
        f.getContentPane().add(p);
        f.pack();
        f.setVisible(true);
        ClientNode c = new ClientNode(m);
        c.setDisplayName("Client 1");
        m.addNode(c);
        ui.addPropertyChangeListener("selectedNode", new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent event) {
                System.out.println("event = " + event);
            }
        });
    }

}
