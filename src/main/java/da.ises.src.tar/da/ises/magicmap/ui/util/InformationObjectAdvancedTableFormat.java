package da.ises.magicmap.ui.util;

import da.ises.core.domain.infoobject.InformationObject;
import ca.odell.glazedlists.gui.AdvancedTableFormat;

import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: janfriderici
 * Date: Jul 8, 2008
 * Time: 1:01:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class InformationObjectAdvancedTableFormat implements AdvancedTableFormat<InformationObject> {
    private String columns[] = new String[]{
        "Eigenschaft",
        "Wert"
    };
    public Class getColumnClass(int i) {
        return null;
    }

    public Comparator getColumnComparator(int i) {
        return null;  //To change body of implemented methods use File | PluginSettings | File Templates.
    }

    public int getColumnCount() {
        return 0;  //To change body of implemented methods use File | PluginSettings | File Templates.
    }

    public String getColumnName(int i) {
        return null;  //To change body of implemented methods use File | PluginSettings | File Templates.
    }

    public Object getColumnValue(InformationObject informationObject, int i) {
        return null;  //To change body of implemented methods use File | PluginSettings | File Templates.
    }
}
