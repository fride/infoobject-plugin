package da.ises.magicmap.ui.extractor;

import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.InformationObjectFactory;
import net.sf.magicmap.client.utils.Pair;
import org.openrdf.model.Graph;

import javax.swing.*;
import java.io.IOException;

/**
     *
 */
public interface ExtractorUI {

    /**
     *
     * @return get the name to use in the combo box.
     */
    String getName();

    /**
     *
     * @return a description for tool tips.
     */
    String getDescription();

    /**
     * Get the view to create and load an information object.
     *
     * @return a view.
     */
    JComponent getView();

    /**
     * 
     * @param factory the factory to create the information object.
     * @return the loaded infomation object.
     */
    InformationObject load(InformationObjectFactory factory) throws IOException;

    /**
     * 
     * @param action ---
     */
    void setLoadAction(Action action);
}
