package da.ises.magicmap.ui.session;


import javax.swing.*;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.CellConstraints;
import org.bushe.swing.event.annotation.AnnotationProcessor;
import org.bushe.swing.event.annotation.EventSubscriber;
import da.ises.magicmap.application.session.LoginEventHandler;
import da.ises.magicmap.application.session.LoginEvent;

/**
 * Created by IntelliJ IDEA.
* User: jfr
* Date: Jul 9, 2008
* Time: 6:26:47 PM
* To change this template use File | Settings | File Templates.
*/
public class LoginDialog extends JDialog implements LoginEventHandler {
    private final JLabel errorLabel;

    /**
     *
     * @param parent
     * @param mainView
     */
    public LoginDialog(JFrame parent, JComponent mainView) {
        super (parent);
        errorLabel = new JLabel();
        errorLabel.setBorder(BorderFactory.createEmptyBorder(12,4,4,4));
        PanelBuilder b = new DefaultFormBuilder(new FormLayout("p:grow", "p,3dlu,p,p"));
        CellConstraints cc = new CellConstraints();
        b.add(new JLabel("Geben Sie einen Namen und ein Passowrt ein."),cc.xy(1,1));
        b.add(mainView, cc.xy(1,3));
        b.add(errorLabel, cc.xy(1,4));
        errorLabel.setVisible(false);
        AnnotationProcessor.process(this);
        getContentPane().add(b.getPanel());

    }
    @EventSubscriber(eventClass = LoginEvent.class)
    public void onEvent(LoginEvent event) {
        switch (event.getResult()) {
            case LOGGED_IN:
                setVisible(false);
                break;
            case FAILED:
                showLoginFailed(event);
                break;
            default:
                // NOP
                break;

        }
    }

    private void showLoginFailed(LoginEvent event) {
        errorLabel.setText("Login failed for user $user$".replace("$user$", event.getUser().getUserName()));
        errorLabel.setVisible(true);
        this.pack();
    }
}
