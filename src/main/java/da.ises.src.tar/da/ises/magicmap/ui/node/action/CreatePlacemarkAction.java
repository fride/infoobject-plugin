package da.ises.magicmap.ui.node.action;

import da.ises.magicmap.controller.node.InformationNodeManager;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.geom.Point2D;

import net.sf.magicmap.client.gui.MainGUI;
import net.sf.magicmap.client.model.node.MapNode;
import net.sf.magicmap.client.model.node.Node;
import net.sf.magicmap.client.interfaces.MapViewListener;
import org.bushe.swing.event.annotation.AnnotationProcessor;
import org.bushe.swing.event.annotation.EventSubscriber;
import edu.umd.cs.piccolo.event.PInputEvent;

/**
 * <p>
 * Class CreatePlacemarkAction ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 19.07.2008
 *         Time: 15:24:35
 */
public class CreatePlacemarkAction extends AbstractNodeAction implements MapViewListener {
    private Point2D lastClickedPosition;

    /**
     * @param s
     * @param manager
     */
    public CreatePlacemarkAction(String s, InformationNodeManager manager) {
        super(s, manager);
        AnnotationProcessor.process(this);
    }

    @Override
    protected boolean checkEnable() {
        return true;
    }

    /**
     * 
     * @param event
     */
    public void actionPerformed(ActionEvent event) {
        String value = JOptionPane.showInputDialog(MainGUI.getInstance().getMainFrame(),
                "Bitte geben Sie einen Namen f�r den Placemark Knoten ein");
        if (value == null) {

        } else {
            //MapView view = (MapView) MainGUI.getInstance().getJComponent("mapView");
            this.getNodeManager().createPlacemark(value,(int)lastClickedPosition.getX(), (int)lastClickedPosition.getY(),0);
        }
    }

    @EventSubscriber(eventClass = MapNode.class)
    public void onMapLoaded(MapNode node) {
        setEnabled(true);

    }

    public void nodeClicked(Node node, PInputEvent event) {
        
    }

    public void nodeRightClicked(Node node, PInputEvent event) {
        
    }

    public void rightClicked(PInputEvent event) {
        lastClickedPosition = event.getPosition();
    }

    public void nodeFixiated(Node node) {
        
    }

    public void leftClicked(PInputEvent event) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
