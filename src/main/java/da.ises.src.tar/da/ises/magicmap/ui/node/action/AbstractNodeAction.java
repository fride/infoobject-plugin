package da.ises.magicmap.ui.node.action;

import da.ises.magicmap.controller.node.InformationNodeManager;
import net.sf.magicmap.client.gui.utils.MagicAction;
import net.sf.magicmap.client.model.node.INodeModelSelectionListener;
import net.sf.magicmap.client.model.node.NodeModelSelectionEvent;
import net.sf.magicmap.client.model.node.Node;
import org.bushe.swing.event.annotation.AnnotationProcessor;

/**
 * Baseclass for edit, create and delete actions. all actions need the annotation space and
 * the node model.
 */
public abstract class AbstractNodeAction extends MagicAction implements INodeModelSelectionListener {
    private final InformationNodeManager manager;
    private Node selectedNode;
    /**
     * 
     * @param s
     * @param manager
     */
    public AbstractNodeAction(String s, InformationNodeManager manager) {
        super(s);
        this.manager = manager;
        init();
    }




    private void init() {
        AnnotationProcessor.process(this);
        setEnabled(false);
    }

    protected InformationNodeManager getNodeManager() {
        return manager;
    }

    public void selectionChanged(NodeModelSelectionEvent event) {
        selectedNode = event.getSelectedNode();
        setEnabled(checkEnable());
    }

    protected boolean checkEnable() {
        return  selectedNode != null && !selectedNode.equals(Node.EMPTY_NODE);
    }


    public Node getSelectedNode() {
        return selectedNode;
   
    }

    
}
