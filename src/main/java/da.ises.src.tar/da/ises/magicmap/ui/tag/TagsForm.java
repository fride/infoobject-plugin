package da.ises.magicmap.ui.tag;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import da.ises.core.infoobject.Tag;

import javax.swing.*;
import javax.swing.table.TableModel;
import java.awt.*;

/**
 * <p>
 * Class TagForm ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 20:56:36
 */
public class TagsForm {
    private JList tagList;
    private JTable taggingsTable;


    public TagsForm(ComboBoxModel tagModel, TableModel taggingsModel) {
        tagList = new JList(tagModel);
        tagList.setVisibleRowCount(4);
        tagList.setLayoutOrientation(JList.VERTICAL_WRAP);
        tagList.setCellRenderer(new DefaultListCellRenderer(){
            @Override
            public Component getListCellRendererComponent(JList jList, Object o, int i, boolean b, boolean b1) {
                final JLabel label = (JLabel) super.getListCellRendererComponent(jList, o, i, b, b1);
                if (o != null){
                    label.setText(((Tag)o).getRawValue());
                }
                return label;
            }
        });

        taggingsTable = new JTable(taggingsModel);
    }

    public JList getTagList() {
        return tagList;
    }

    public JTable getTaggingsTable() {
        return taggingsTable;
    }

    public JComponent getView(){
        FormLayout l = new FormLayout("p");
        CellConstraints cc = new CellConstraints();
        PanelBuilder b = new DefaultFormBuilder(l);
        b.appendRelatedComponentsGapColumn();
        b.appendColumn("fill:p:grow");

        b.appendRow("fill:p:grow");

        b.add(new JLabel("Tags"), cc.xy(1,1));
        JScrollPane pane = new JScrollPane(tagList);
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        b.add(pane, cc.xy(3,1));

        b.appendRelatedComponentsGapRow();
        b.appendRow("fill:p:grow");

        b.add(new JLabel("Taggings"), cc.xy(1,b.getRowCount()));
        pane = new JScrollPane(taggingsTable);
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        b.add(pane, cc.xy(3,b.getRowCount()));
        return b.getPanel();

    }
}
