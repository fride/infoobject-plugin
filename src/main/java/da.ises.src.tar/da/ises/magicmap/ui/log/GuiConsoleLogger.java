package da.ises.magicmap.ui.log;

import net.sf.magicmap.client.gui.views.ConsoleView;
import org.bushe.swing.event.EventBus;
import org.bushe.swing.event.EventTopicSubscriber;
import org.bushe.swing.event.annotation.EventSubscriber;
import org.bushe.swing.event.annotation.AnnotationProcessor;

import java.util.regex.Pattern;

import da.ises.magicmap.application.session.MapSessionEventHandler;
import da.ises.magicmap.application.session.SessionEventHandler;
import da.ises.magicmap.application.session.MagicSession;
import da.ises.magicmap.application.session.MapSession;


/**
 *
 */
public class GuiConsoleLogger implements SessionEventHandler, MapSessionEventHandler {
    private ConsoleView view;

    public GuiConsoleLogger(final ConsoleView view) {
        this.view = view;
        view.append("Event Logger started.");
        AnnotationProcessor.process(this);
    }

    @EventSubscriber(eventClass = LogEvent.class)
    public void onEvent(LogEvent event) {
        StringBuilder b = new StringBuilder();

        switch (event.getType()) {
            case ERROR:
                b.append("Error: ");
                break;
            case WARNING:
                b.append("Warning: ");
                break;
            default:
                break;

        }
        b.append(event.getMessage());
        view.append(b.toString());
    }

    @EventSubscriber(eventClass = MagicSession.class)
    public void onEvent(MagicSession session) {
        view.append("Session started");
    }

    @EventSubscriber(eventClass = MapSession.class)
    public void onEvent(MapSession mapSession) {
        view.append("Map session started");
    }
}
