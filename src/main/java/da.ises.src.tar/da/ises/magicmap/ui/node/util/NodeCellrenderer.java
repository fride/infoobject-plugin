package da.ises.magicmap.ui.node.util;

import net.sf.magicmap.client.model.node.Node;

import javax.swing.*;
import java.awt.*;

/**
 * <p>
* Class NodeCellrenderer ZUSAMMENFASSUNG
* </p>
* <p>
* DETAILS
* </p>
*
* @author Jan Friderici
*         Date: 27.07.2008
*         Time: 18:31:26
*/
public class NodeCellrenderer extends DefaultListCellRenderer {

    @Override
    public Component getListCellRendererComponent(JList jList, Object o, int i, boolean b, boolean b1) {
        JLabel label = (JLabel) super.getListCellRendererComponent(jList, o, i, b, b1);
        Node n = (Node) o;
        if (Node.EMPTY_NODE.equals(n)) {
            setText("-");
            setIcon(null);
        } else if (n != null){
            String name = n.getDisplayName();
            setText((name != null ? name : n.getName()) + " (" + n.getClass().
            getSimpleName());
        }
        return label;
    }
}
