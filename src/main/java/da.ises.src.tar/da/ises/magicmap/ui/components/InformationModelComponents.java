package da.ises.magicmap.ui.components;

/**
 * Created by IntelliJ IDEA.
 * User: janfriderici
 * Date: Jul 8, 2008
 * Time: 4:44:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class InformationModelComponents {
    private GuiComponentFactory guiComponentFactory;

    public InformationModelComponents(GuiComponentFactory guiComponentFactory) {
        this.guiComponentFactory = guiComponentFactory;
    }

    public GuiComponentFactory getMagicMapGuiComponents() {
        return guiComponentFactory;
    }
}
