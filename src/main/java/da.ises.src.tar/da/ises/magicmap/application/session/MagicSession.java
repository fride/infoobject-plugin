package da.ises.magicmap.application.session;

import net.sf.magicmap.client.model.node.MapNode;

import java.util.*;
import java.sql.Timestamp;

import org.bushe.swing.event.EventBus;

/**
 *
 */
public class MagicSession implements Iterable<MapSession>{
    private List<MapSession> mapSessions = new LinkedList<MapSession>();

    private static List<MagicSession> magicSessions = new LinkedList<MagicSession>();
    
    private Timestamp startTime;
    private Timestamp endTime;
    private final String user;
    private final String server;

    public MagicSession(Timestamp startTime, String user, String server) {
        this.startTime = startTime;
        this.user = user;
        this.server = server;
    }

    public static MagicSession createSession(String server, String user) {
        final Timestamp now = new Timestamp(Calendar.getInstance().getTimeInMillis());
        MagicSession s = new MagicSession(now, user, server);
        magicSessions.add(s);
        EventBus.publish(s);
        return s;
    }
    
    public void stop() {
        this.endTime = new Timestamp(Calendar.getInstance().getTimeInMillis());
        EventBus.publish("session.stop", this);
    }
    /**
     * 
     * @param map
     * @return
     */
    public MapSession createMapSession(MapNode map) {
        MapSession mapSession = new MapSession(map);
        mapSessions.add(mapSession);
        EventBus.publish(mapSession);
        return mapSession;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public String getUser() {
        return user;
    }

    public String getServer() {
        return server;
    }

    public Iterator<MapSession> iterator() {
        return new ArrayList<MapSession>(mapSessions).iterator();
    }
}
