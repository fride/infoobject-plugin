package da.ises.magicmap.application;

/**
 * 
 */
public interface PluginAppliationListener {

    void applicationChanged(PluginApplictionEvent event);
}
