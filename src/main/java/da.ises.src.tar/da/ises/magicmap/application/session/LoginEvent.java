package da.ises.magicmap.application.session;

import da.ises.core.domain.user.Agent;

/**
 *
 */
public class LoginEvent {
    private Agent agent;

    public enum Result {
        LOGGED_IN,
        FAILED,
        LOGGED_OUT
    }
    private final Result result;

    public LoginEvent(Agent agent, Result result) {
        this.agent = agent;
        this.result = result;
    }

    public Agent getUser() {
        return agent;
    }

    public Result getResult() {
        return result;
    }
}
