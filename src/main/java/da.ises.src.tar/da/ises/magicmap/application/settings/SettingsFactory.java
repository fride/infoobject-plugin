package da.ises.magicmap.application.settings;

import com.thoughtworks.xstream.XStream;
import da.ises.magicmap.application.PluginApplication;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.bushe.swing.event.EventBus;

/**
 *
 */
public class SettingsFactory {

    private static PluginSettings pluginSettings;
    private static XStream stream;


    public static PluginSettings get() {
        if (pluginSettings == null) {
            getStream();
            File settingsFile = getSettingsFile();
            if (settingsFile.exists()) {
                try {
                    pluginSettings = (PluginSettings) stream.fromXML(new FileInputStream(settingsFile));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }  finally {

                }
            }
            if (pluginSettings == null) {
                pluginSettings = createDefaultSettings();
            }
        }
        return pluginSettings;
    }

    public static PluginSettings createDefaultSettings() {
        PluginSettings defaultPluginSettings = new PluginSettings();
        return defaultPluginSettings;

    }

    private static File getSettingsFile() {
        File settingsFile = PluginApplication.get().getHome("pluginSettings.xml");
        return settingsFile;
    }

    private static void getStream() {
        if (stream == null) {
            stream = new XStream();
            stream.alias("pluginSettings", PluginSettings.class);
            stream.alias("repositorySettings", RemoteRepositorySettings.class);
        }
    }

    public static void save(PluginSettings pluginSettings) {
        getStream();
        try {
            stream.toXML(pluginSettings,new FileOutputStream(getSettingsFile()));
            EventBus.publish(pluginSettings);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

}
