package da.ises.magicmap.application.settings;

/**
 * 
 */
public interface PluginSettingsListener {

    /**
     * 
     * @param setting
     */
    public void settingsChanged(PluginSettings setting);
}
