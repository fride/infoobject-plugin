package da.ises.magicmap.application;

/**
 *
 * 
 */
public class NotificationManager {
}
