package da.ises.magicmap.application.settings;

import java.util.Map;
import java.util.HashMap;

/**
 * 
 */
public class PluginSettings {


    private String userName; // my user name -- the admin!
    private boolean shared;
    private boolean allowAnonymous;
    private String homeRepository;
    private String localRepositoryId;

    // Remote Repositories
    private Map<String, RemoteRepositorySettings> repositories = new HashMap<String, RemoteRepositorySettings>();


    public String getLocalRepositoryId() {
        return localRepositoryId;
    }

    public void setLocalRepositoryId(String localRepositoryId) {
        this.localRepositoryId = localRepositoryId;
    }

    public boolean isAllowAnonymous() {
        return allowAnonymous;
    }

    public void setAllowAnonymous(boolean allowAnonymous) {
        this.allowAnonymous = allowAnonymous;
    }

    public boolean isShared() {
        return shared;
    }

    public void setShared(boolean shared) {
        this.shared = shared;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getHomeRepository() {
        return homeRepository;
    }

    public void setHomeRepository(String homeRepository) {
        this.homeRepository = homeRepository;
    }

    public Map<String, RemoteRepositorySettings> getRepositories() {
        return repositories;
    }

    public void setRepositories(Map<String, RemoteRepositorySettings> repositories) {
        this.repositories = repositories;
    }
}
