package da.ises.magicmap.application;

/**
 * 
 */
public class PluginApplictionEvent {
    
    public enum Type {
        LOCAL_REPOSITORY_OPENED,
        HOME_REPOSITORY_CHANGED,
        MAP_LOADED,
        CONNECTED
    }
    private final Type type;
    
    public PluginApplictionEvent(Type type) {
        this.type = type;
    }

    public Type getType() {
        return type;
    }
}
