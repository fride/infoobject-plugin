package da.ises.magicmap.application.session;

import da.ises.core.domain.infoobject.InformationObject;
import da.ises.magicmap.domain.node.InformationObjectNode;
import net.sf.magicmap.client.model.node.INodeModel;
import net.sf.magicmap.client.model.node.MapNode;

import java.util.*;

import org.bushe.swing.event.EventBus;

/**
 * A Session on a map.
 * 
 */

public class MapSession {
    private MapNode mapNode;
    private Map<String, InformationObject> informations = new HashMap<String, InformationObject>();
    private Date sessionStart;
    private Date sessionStop;


    
    /**
     * 
     * @param mapNode
     */
    public MapSession(MapNode mapNode) {
        this.mapNode = mapNode;
        sessionStart = Calendar.getInstance().getTime();
        
    }

    /**
     * 
     */
    public void close() {
        sessionStop = Calendar.getInstance().getTime();
        EventBus.publish("mapSession.close", this);
    }


    

    /**
     * 
     * @return
     */
    public Iterable getInformationObjects() {
        return new ArrayList<InformationObject>(informations.values());
    }

    /**
     * 
     * @return
     */
    public MapNode getMapNode() {
        return mapNode;
    }

    /**
     *
     * @return
     */
    public Date getSessionStart() {
        return sessionStart;
    }

    /**
     * 
     * @return
     */
    public Date getSessionStop() {
        return sessionStop;
    }
}
