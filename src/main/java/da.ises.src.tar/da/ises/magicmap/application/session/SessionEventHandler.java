package da.ises.magicmap.application.session;

import da.ises.magicmap.application.session.MagicSession;

/**
 * 
 */
public interface SessionEventHandler {

    /**
     * 
     * @param session
     */
    public void onEvent(MagicSession session);
}
