package da.ises.magicmap.application.settings;

/**
 * 
 */
public class RemoteRepositorySettings {
    private String url;
    private String repositoryId;
    private String user;
    private String password;
    private boolean local;

    public boolean isLocal() {
        return local;
    }

    public void setLocal(boolean local) {
        this.local = local;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
        if (url != null && url.startsWith("http://")) {
            setLocal(false);
        } else {
            setLocal(true);
        }
    }

    public String getRepositoryId() {
        return repositoryId;
    }

    public void setRepositoryId(String repositoryId) {
        this.repositoryId = repositoryId;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
