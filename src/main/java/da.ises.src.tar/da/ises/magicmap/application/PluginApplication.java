package da.ises.magicmap.application;

import da.ises.core.domain.repository.InformationObjectRepository;
import da.ises.core.domain.user.Agent;
import da.ises.db4o.domain.Db4oRepository;
import da.ises.magicmap.application.session.MagicSession;
import da.ises.magicmap.application.settings.PluginSettings;
import da.ises.magicmap.application.settings.PluginSettingsListener;
import da.ises.magicmap.application.settings.SettingsFactory;
import da.ises.magicmap.ui.log.LogEvent;
import net.sf.magicmap.client.model.node.MapNode;
import net.sf.magicmap.client.utils.AbstractModel;
import net.sf.magicmap.client.utils.Settings;
import org.bushe.swing.event.EventBus;
import org.bushe.swing.event.annotation.AnnotationProcessor;
import org.bushe.swing.event.annotation.EventSubscriber;
import org.openrdf.repository.sail.SailRepository;
import org.openrdf.sail.memory.MemoryStore;

import java.io.File;
import java.sql.Timestamp;
import java.util.Calendar;

/**
 *
 */
public class PluginApplication extends AbstractModel implements PluginSettingsListener {

    private static PluginApplication instance;
    //private Map<String, AnnotationSpace> remoteSpaces = new HashMap<String, AnnotationSpace>();
    private InformationObjectRepository repository;
    private org.openrdf.repository.Repository temporaryMetadata;

    private Agent agent;
    private Timestamp sessionStart;
    private boolean connected;

    private MapNode currentMap;
    public static final String APPLICTION_LOGIN = "appliction.login";

    private PluginSettings settings;
    private MagicSession currentSession;

    public Agent getUser() {
        return agent;
    }


    public static PluginApplication get() {
        if (instance == null) {
            instance = new PluginApplication();
            EventBus.clearCache();
            EventBus.publish("appliction.start", instance);
            AnnotationProcessor.process(instance);
            instance.settings = SettingsFactory.get();
            instance.temporaryMetadata = new SailRepository(new MemoryStore());
        }
        return instance;
    }


    public InformationObjectRepository getRepository() {
        return repository;
    }

    /**
     * 
     * @return
     */
    public boolean isConnected() {
        return connected;
    }

    public void startSession() {
        this.sessionStart = new Timestamp(Calendar.getInstance().getTimeInMillis());
        this.connected = true;
        currentSession = new MagicSession(sessionStart, Settings.getClientName(), Settings.getServerURL());
        EventBus.publish(currentSession);
    }

    public void setCurrentMap(MapNode currentMap) {
        this.currentMap = currentMap;
        firePropertyChange("currentMap", null, currentMap);
        EventBus.publish("appliction.mapLoaded", currentMap);
    }

    public MapNode getCurrentMap() {
        return currentMap;
    }

  
    public File getHome() {
        File file = new File(System.getProperty("user.home") + "/.daises");
        if (!file.exists() && !file.mkdirs()) {
            EventBus.publish(new LogEvent("Cant setup home dir!", LogEvent.Type.ERROR));
            throw new RuntimeException("Cant settup home dir");
        }
        return file;
    }

    /**
     * Keeps the metadata for the session...
     * @return
     */
    public org.openrdf.repository.Repository getTemporaryMetadata() {
        return temporaryMetadata;
    }

    public File getHome(String path) {
        getHome();        
        return new File(System.getProperty("user.home") + "/.daises/"+path);
    }

    @EventSubscriber(eventClass = PluginSettings.class)
    public void settingsChanged(PluginSettings setting) {
        setup(setting);
    }

    public void setup(PluginSettings settings) {
        this.settings = settings;
        this.repository = new Db4oRepository();
        EventBus.publish(new PluginApplictionEvent(PluginApplictionEvent.Type.LOCAL_REPOSITORY_OPENED));
    }
}
