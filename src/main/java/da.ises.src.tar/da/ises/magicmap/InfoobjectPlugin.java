package da.ises.magicmap;

import da.ises.core.domain.repository.InformationObjectRepository;
import da.ises.db4o.domain.Db4oRepository;
import da.ises.magicmap.application.PluginApplication;
import da.ises.magicmap.application.settings.PluginSettings;
import da.ises.magicmap.application.settings.SettingsFactory;
import da.ises.magicmap.controller.association.AssociationManager;
import da.ises.magicmap.controller.node.InformationNodeManager;
import da.ises.magicmap.controller.position.PositionAddedHandler;
import da.ises.magicmap.controller.tag.TagAssociationHandler;
import da.ises.magicmap.controller.tag.TagManager;
import da.ises.magicmap.domain.ModelFactory;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.domain.node.PlacemarkNode;
import da.ises.magicmap.domain.node.VehicleNode;
import da.ises.magicmap.ui.components.GuiComponentFactory;
import da.ises.magicmap.ui.log.GuiConsoleLogger;
import da.ises.magicmap.ui.node.NodeGuiAssembler;
import da.ises.magicmap.ui.node.icon.InformationNodeIcon;
import da.ises.magicmap.ui.node.icon.PlacemarkNodeIcon;
import da.ises.magicmap.ui.node.icon.VehicleNodeIcon;
import da.ises.magicmap.ui.settings.SettingsView;
import da.ises.magicmap.ui.tag.TagPresenter;
import da.ises.magicmap.ui.tag.TagView;
import da.ises.magicmap.visualization.VisualizationManager;
import net.sf.magicmap.client.gui.utils.icon.NodeIconContainer;
import net.sf.magicmap.client.plugin.AbstractPlugin;
import net.sf.magicmap.client.plugin.IPluginDescriptor;
import net.sf.magicmap.client.utils.Settings;
import org.bushe.swing.event.EventBus;


/**
 *
 *
 */
public class InfoobjectPlugin extends AbstractPlugin {

    private VisualizationManager visualizationManager;
    private ModelFactory modelFactory;
    private InformationNodeManager nodeManager;

    private SettingsView settingsView;
    private AssociationManager associationManager;
    private TagManager tagManager;
    private InformationObjectRepository repository;
    private TagAssociationHandler tagAssociationHandler;

    /**
     *
     * @param descriptor xml.
     */
    public InfoobjectPlugin(IPluginDescriptor descriptor) {
        super(descriptor);
    }

    @Override
    public void setup(Settings settings) {
        super.setup(settings);
        repository = new Db4oRepository();

        setupIcons();


        modelFactory = new ModelFactory();
        GuiComponentFactory guiComponentFactory = new GuiComponentFactory();
        new GuiConsoleLogger(guiComponentFactory.getConsoleView());

        nodeManager = new InformationNodeManager(modelFactory.getNodeModel(), repository);
        
        visualizationManager = new VisualizationManager(modelFactory);
        visualizationManager.start();


        new NodeGuiAssembler(modelFactory, guiComponentFactory, nodeManager).start();

        settingsView = new SettingsView(guiComponentFactory);
        settingsView.start();

        associationManager = modelFactory.getAssociationManager();
        associationManager.start();

        // Watches the model for new nodes to create links for.
        PositionAddedHandler handler = new PositionAddedHandler(modelFactory.getAssociationManager());
        modelFactory.getAssociationManager().start();

        
        modelFactory.getNodeModel().addNodeModelListener(handler);

        /**
         * 
         */
        tagManager = new TagManager(modelFactory.getNodeModel(), modelFactory.getInformationTagModel(), associationManager);
        tagAssociationHandler = new TagAssociationHandler(modelFactory.getAssociationGraph());
        modelFactory.getInformationTagModel().addTagModelListener(tagAssociationHandler);


        final TagPresenter tagPresenter = new TagPresenter(modelFactory.getInformationTagModel());
        TagView v = new TagView(tagPresenter);
        guiComponentFactory.getViewTabPanel().addView(v);

    }

    /**
     * 
     */
    private void setupIcons() {
        NodeIconContainer.getInstance().registerNodeIcon(InformationObjectNode.NODE_TYPE, new InformationNodeIcon());
        NodeIconContainer.getInstance().registerNodeIcon(PlacemarkNode.NODE_TYPE, new PlacemarkNodeIcon());
        NodeIconContainer.getInstance().registerNodeIcon(VehicleNode.NODE_TYPE, new VehicleNodeIcon());
    }

    @Override
    public void startPlugin() {
        super.startPlugin();

    }

    /**
     * 
     */
    @Override
    public void connect() {
        super.connect();
        settingsView.load();
        PluginSettings settings = SettingsFactory.get();
        settings.setUserName(Settings.getClientName());
        PluginApplication.get().startSession();
        visualizationManager.start();

    }

    /**
     *
     */
    @Override
    public void loadMap() {
        EventBus.publish(modelFactory.getNodeModel().getCurrentMap());
        nodeManager.mapLoaded(modelFactory.getNodeModel().getCurrentMap());
        visualizationManager.mapLoaded(modelFactory.getNodeModel().getCurrentMap());
        PluginApplication.get().setCurrentMap(modelFactory.getNodeModel().getCurrentMap());
    }
}
