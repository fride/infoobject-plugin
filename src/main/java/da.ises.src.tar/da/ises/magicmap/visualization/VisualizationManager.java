package da.ises.magicmap.visualization;

import da.ises.magicmap.domain.ModelFactory;
import da.ises.magicmap.domain.association.InformationEdgeType;
import da.ises.magicmap.domain.node.AbstractInformationNode;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.domain.node.PlacemarkNode;
import da.ises.magicmap.domain.node.VehicleNode;
import da.ises.magicmap.visualization.node.VisualInformationEdge;
import da.ises.magicmap.visualization.node.VisualInformationNode;
import da.ises.magicmap.visualization.node.VisualInformationPositionEdge;
import da.ises.util.preview.PreviewService;
import net.sf.magicmap.client.gui.MainGUI;
import net.sf.magicmap.client.gui.views.MapView;
import net.sf.magicmap.client.interfaces.NodeModelListener;
import net.sf.magicmap.client.model.location.MagicGraphEvent;
import net.sf.magicmap.client.model.node.*;
import net.sf.magicmap.client.visualization.NodeCanvas;
import net.sf.magicmap.client.visualization.VisualEdge;
import net.sf.magicmap.client.visualization.VisualNode;

import java.awt.*;
import java.util.WeakHashMap;

/**
 *
 */
public class VisualizationManager {
    private final ModelFactory modelFactory;
    private NodeCanvas nodeCanvas;
    private MapView mapView;
    private WeakHashMap<AbstractInformationNode, VisualInformationNode> nodes = new WeakHashMap<AbstractInformationNode, VisualInformationNode>();
    private WeakHashMap<IMagicEdge, VisualInformationEdge> edges = new WeakHashMap<IMagicEdge, VisualInformationEdge>();
    private WeakHashMap<IMagicEdge, VisualInformationPositionEdge> positionEdges = new WeakHashMap<IMagicEdge, VisualInformationPositionEdge>();

    private PreviewService previewService = new PreviewService();
    private InformationDetailNode detailNode;

    
    /**
     *
     * @param modelFactory
     */
    public VisualizationManager(final ModelFactory modelFactory) {
        this.modelFactory = modelFactory;
        
        this.modelFactory.getAssociationGraph().addNodeGraphListener( new NodeGraphListener(){
            public void edgeAdded(MagicGraphEvent event) {
                addEdge(event.getEdge());
            }

            public void edgeRemoved(MagicGraphEvent event) {
                removeEdge(event.getEdge());
            }
        });
        this.modelFactory.getNodeModel().addNodeModelListener(new NodeModelListener() {
            public void nodeAddedEvent(Node node) {
                if (node instanceof PlacemarkNode) {
                    addPlacemark((PlacemarkNode)node);
                } else if (node instanceof VehicleNode){
                    addVehicle(((VehicleNode)node));
                }
            }

            public void nodeUpdatedEvent(Node node, int i, Object o) {
                //To change body of implemented methods use File | Settings | File Templates.
            }

            public void nodeRemovedEvent(Node node) {
                if (nodes.containsKey(node)){
                    removeNode(node);
                }
            }
        });
        MainGUI.getInstance().getNodeSelectionModel().addNodeModelSelectionListener(new INodeModelSelectionListener() {
            public void selectionChanged(NodeModelSelectionEvent event) {
                Node selectedNode = event.getSelectedNode();
                if (selectedNode instanceof InformationObjectNode){
                    showPreview(getVisualNode((AbstractInformationNode) selectedNode));
                } else {
                    hidePreview();
                }
            }
        });

    }




    private void addPlacemark(PlacemarkNode placemarkNode) {
        getNodeCanvas().addNode(new VisualNode(placemarkNode, getNodeCanvas().getContext()));
    }
    private void addVehicle(VehicleNode vehicleNode) {
           getNodeCanvas().addNode(new VisualNode(vehicleNode, getNodeCanvas().getContext()));
    }

    private void removeNode(Node node) {
        VisualInformationNode visualNode = this.nodes.remove(node);
        if (visualNode != null){
            getNodeCanvas().removeNode(node);
        }
    }

    /**
     *
     */
    public void start() {
        modelFactory.getAssociationManager().start();
    }

    public void showPreview(VisualInformationNode node){
        if (detailNode == null || node != detailNode.getVisualNode()){
            hidePreview();
            this.detailNode = new InformationDetailNode(node);
            this.detailNode.setImage(node.getPreviewImage());
            this.getNodeCanvas().addDecoration(detailNode);
        }
    }

    public void hidePreview() {
        if (this.detailNode != null){
            detailNode.getVisualNode().removeLinkedNode(detailNode);
            getNodeCanvas().removeDecoration(detailNode);
            this.detailNode = null;
        }
    }

    public void mapLoaded(MapNode node) {
        modelFactory.getAssociationGraph().getLayout().resize(new Dimension(node.getMapInfo().width, node.getMapInfo().height));


    }
    /**
     *
     */
    public void stop() {

    }

    protected void removeEdge(IMagicEdge edge){
        VisualEdge visualInformationEdge = edges.remove(edge);
        if (visualInformationEdge == null) {
            visualInformationEdge = positionEdges.remove(edge);
        }
        if (visualInformationEdge != null) {
            getNodeCanvas().removeEdge(edge);
        } else {
            System.err.println("No Edge in edges! " + edge);
        }
    }
    
    protected void addEdge(IMagicEdge edge){
        switch (InformationEdgeType.getAssociationType(edge)) {
            case ASSOCIATION:
                addAssociationEdge(edge);
                break;
            case POSITION:
                addPositionEdge(edge);
                break;
            default:
                System.err.println("Unknown edge!");
        }
    }

    private void addPositionEdge(IMagicEdge edge) {
        VisualNode vs = getNodeCanvas().getVisualNode(edge.getTargetNode());
        VisualInformationNode vt = getVisualNode((InformationObjectNode) edge.getSourceNode());

        VisualInformationPositionEdge positionEdge = getVisualPositionEdge(vs,vt,edge);
        getNodeCanvas().addEdge(positionEdge);
    }


    /**
     *
     * @param edge
     */
    private void addAssociationEdge(IMagicEdge edge) {
        AbstractInformationNode source = (AbstractInformationNode) edge.getSourceNode();
        AbstractInformationNode target = (AbstractInformationNode) edge.getTargetNode();

        VisualInformationNode visualSource = getVisualNode(source);
        VisualInformationNode visualTarget = getVisualNode(target);
        getNodeCanvas().addEdge(getVisualEdge(visualSource, visualTarget, edge));

    }

    /**
     * 
     * @return
     */
    public NodeCanvas getNodeCanvas() {
        if (nodeCanvas == null) {
            nodeCanvas = getMapView().getNodeCanvas();
        }
        return nodeCanvas;
    }

    public MapView getMapView() {
        if (mapView == null) {
            mapView = (MapView) MainGUI.getInstance().getJComponent("mapView");
        }
        return mapView;
    }

    /**
     *
     * @param node
     * @return
     */
    public VisualInformationNode getVisualNode(AbstractInformationNode node) {
        if (!nodes.containsKey(node)) {
            VisualInformationNode visualNode = new VisualInformationNode(node, getNodeCanvas().getContext());
            visualNode.setPreviewService(previewService); 
            nodes.put(node, visualNode);
            getNodeCanvas().addNode(visualNode);
        }
        return nodes.get(node);
    }
     /**
     *
     * @param vs
     * @param vt
     * @param edge
     * @return
     */
    private VisualInformationPositionEdge getVisualPositionEdge(VisualNode vs, VisualInformationNode vt, IMagicEdge edge) {
        if (!positionEdges.containsKey(edge)) {
            VisualInformationPositionEdge ve = new VisualInformationPositionEdge(edge, vs, vt, getNodeCanvas().getContext());
            positionEdges.put(edge,ve);
        }
        return positionEdges.get(edge);
    }
     /**
     *
     * @param visualSource
     * @param visualTarget
     * @param edge
     * @return
     */
    private VisualEdge getVisualEdge(VisualInformationNode visualSource, VisualInformationNode visualTarget, IMagicEdge edge) {
        if (!edges.containsKey(edge)) {
            VisualInformationEdge visualEdge = new VisualInformationEdge(edge, visualSource, visualTarget, getNodeCanvas().getContext());
            edges.put(edge, visualEdge);
        }
        return edges.get(edge);
    }


}
