package da.ises.magicmap.visualization.node;

import da.ises.magicmap.domain.node.AbstractInformationNode;
import da.ises.util.preview.PreviewService;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.util.PPaintContext;
import net.sf.magicmap.client.visualization.VisualNode;
import net.sf.magicmap.client.visualization.VisualizationContext;
import net.sf.magicmap.client.visualization.support.ToolTipFunction;

import java.awt.*;
import java.io.IOException;

/**
 * 
 */
public class VisualInformationNode extends VisualNode{

    private String toolTipTempl = "<b>$NAME$</b><br>\nTyp: $TYPE$";
    private PreviewService previewService;
    private Image previewImage;
    private ToolTipFunction tooltip = new ToolTipFunction() {
        public String getNodeName() {
            return getTooltipText();
        }
        public PNode getDetails() {
            return null;
        }
    };

    /**
     * 
     * @param node
     * @param visualizationContext
     */
    public VisualInformationNode(AbstractInformationNode node, VisualizationContext visualizationContext) {
        super(node, visualizationContext);
        addAttribute(VisualizationContext.TOOLTIP_TEXT_KEY, tooltip);
    }

    
    public Image getPreviewImage(){
        String uri = getItem().getInformationObject().getId();
        if (uri.startsWith("http://")){
            if (previewService != null){
                try {
                    previewImage = previewService.getPreview(uri);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return previewImage;
    }
    /**
     *
     * @return
     */
    public AbstractInformationNode getItem() {
        return (AbstractInformationNode) super.getItem();
    }

    /**
     * 
     * @param pPaintContext
     */
    public void paint(PPaintContext pPaintContext) {
        super.paint(pPaintContext);
    }

    public void setPreviewService(PreviewService previewService) {
        this.previewService = previewService;
    }

    protected String getTooltipText() {
        String str = toolTipTempl.replace("$NAME$", getItem().getDisplayName());
        return str.replace("$TYPE$", getItem().getInformationObject().getMimeType().getMimeType());
    }
}
