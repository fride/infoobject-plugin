package da.ises.magicmap.visualization;

import edu.umd.cs.piccolo.nodes.PImage;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import net.sf.magicmap.client.visualization.LinkedNode;
import net.sf.magicmap.client.visualization.VisualNode;

import java.awt.*;

/**
 * <p>
 * Class PreviewNode ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 21:39:21
 */
public class InformationDetailNode extends LinkedNode {

    public InformationDetailNode(VisualNode visualNode) {
        super(visualNode, new PImage());
        getNode().addInputEventListener(new PBasicInputEventHandler(){
            @Override
            public void mouseClicked(PInputEvent event) {
                super.mouseClicked(event);
                if (event.getClickCount() == 2){
                    // Open url
                    System.out.println("Event");
                }
            }
        });
    }
    

    @Override
    public PImage getNode() {
        return (PImage) super.getNode();
    }

    public void setImage(Image image){
        getNode().setImage(image);
    }
    /**
     * 
     */
    public void positionChanged() {
        getNode().centerBoundsOnPoint(getVisualNode().getX()+64, getVisualNode().getY()+64);
    }
}
