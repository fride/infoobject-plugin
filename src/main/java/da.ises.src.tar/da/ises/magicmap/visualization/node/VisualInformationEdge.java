package da.ises.magicmap.visualization.node;

import net.sf.magicmap.client.model.node.IMagicEdge;
import net.sf.magicmap.client.visualization.VisualEdge;
import net.sf.magicmap.client.visualization.VisualizationContext;

/**
 *
 * 
 */
public class VisualInformationEdge extends VisualEdge{

    public VisualInformationEdge(IMagicEdge iMagicEdge, VisualInformationNode visualNode, VisualInformationNode visualNode1, VisualizationContext visualizationContext) {
        super(iMagicEdge, visualNode, visualNode1, visualizationContext);
    }

    /**
     *
     * @return
     */
    public VisualInformationNode getSourceNode() {
        return (VisualInformationNode) super.getSourceNode();
    }

    /**
     * 
     * @return
     */
    public VisualInformationNode getTargeNnode() {
        return (VisualInformationNode)super.getTargetNode();
    }
}
