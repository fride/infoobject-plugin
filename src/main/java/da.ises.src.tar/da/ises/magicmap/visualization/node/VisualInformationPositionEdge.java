package da.ises.magicmap.visualization.node;

import net.sf.magicmap.client.visualization.VisualEdge;
import net.sf.magicmap.client.visualization.VisualNode;
import net.sf.magicmap.client.visualization.VisualizationContext;
import net.sf.magicmap.client.model.node.IMagicEdge;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: 19.06.2008
 * Time: 15:34:53
 * To change this template use File | Settings | File Templates.
 */
public class VisualInformationPositionEdge  extends VisualEdge {
    public VisualInformationPositionEdge(IMagicEdge iMagicEdge, VisualNode visualNode, VisualInformationNode visualNode1, VisualizationContext visualizationContext) {
        super(iMagicEdge, visualNode, visualNode1, visualizationContext);
    }

    public VisualInformationNode getTargeNnode() {
        return (VisualInformationNode)super.getTargetNode();
    }
}
