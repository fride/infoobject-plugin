package da.ises.magicmap.domain.tag;

import da.ises.core.infoobject.Tag;
import da.ises.magicmap.domain.node.InformationObjectNode;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.impl.BipartiteVertex;

import java.lang.ref.WeakReference;
import java.util.*;

/**
 * <p>
 * Class TagVertex ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 21.07.2008
 *         Time: 01:06:03
 */
public class TagVertex extends BipartiteVertex {
    private WeakReference<Tag> tag;

    /**
     * 
     * @param tag
     */
    public TagVertex(Tag tag) {
        this.tag = new WeakReference<Tag>(tag);
    }

    public Tag getTag() {
        return tag.get();
    }

    /**
     * Summe aller ausgehnden Kanten.
     * @return
     */
    public int getWeight() {
        Object[] internal = getEdges_internal().toArray();
        int weight = 0;
        if (internal != null) {
            for (Object o:internal){
                TagEdge edge = (TagEdge) o;
                weight += edge.isPositive() ? 1 : -1;
            }
        }
        return weight;
    }


    @Override
    public TagEdge findEdge(Vertex vertex) {
        return (TagEdge)super.findEdge(vertex);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public Set<TagEdge> getIncidentEdges() {
        return super.getIncidentEdges(); 
    }

    /**
     * 
     * @return
     */
    public Map<InformationObjectNode, Integer> getNodes(){
        Map<InformationObjectNode, Integer> nodes = new HashMap<InformationObjectNode, Integer>();
        Set<TagEdge> edges = getIncidentEdges();
        if (edges != null) {
            for (TagEdge e:edges) {
                InformationObjectNode node = e.getNode();
                nodes.put(node, e.getWeight());
            }
        }
        return nodes;
    }
}
