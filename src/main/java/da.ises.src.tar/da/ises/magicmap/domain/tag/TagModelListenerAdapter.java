package da.ises.magicmap.domain.tag;

/**
 * <p>
 * Class TagModelListenerAdapter ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 19:46:00
 */
public class TagModelListenerAdapter implements TagModelListener{
    /**
     * @param tag
     */
    public void tagAdded(TagEvent tag) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @param tag
     */
    public void tagRemoved(TagEvent tag) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @param tagging
     */
    public void taggingAdded(TaggingEvent tagging) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @param tagging
     */
    public void taggingRemoved(TaggingEvent tagging) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
