package da.ises.magicmap.domain.tag;

import edu.uci.ics.jung.graph.impl.BipartiteEdge;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.core.domain.user.Agent;
import da.ises.core.infoobject.Tag;

import java.util.Set;
import java.util.HashSet;
import java.lang.ref.WeakReference;

/**
 * <p>
 * Class TagEdge ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 21.07.2008
 *         Time: 01:08:02
 */
public class TagEdge extends BipartiteEdge {
    private final Set<Agent> positiveVotes = new HashSet<Agent>();
    private final Set<Agent> negativeVotes = new HashSet<Agent>();
    private final WeakReference<Tag> tag;
    private final WeakReference<InformationObjectNode> information;

    public TagEdge(TagVertex tag, NodeVertex node, boolean positive, Agent author) {
        super(tag, node);
        this.tag = new WeakReference<Tag>(tag.getTag());
        this.information = new WeakReference<InformationObjectNode>(node.getNode());
        addAuthor(positive,author);
    }

    public void addAuthor(boolean positive, Agent author) {
        if (positive) {
            addPositiveVote(author);
        } else {
            addNegativeVote(author);
        }
    }

    /**
     * 
     * @param agent
     */
    public void addNegativeVote(Agent agent) {
        this.negativeVotes.add(agent);
        this.positiveVotes.remove(agent);
    }
    public void addPositiveVote(Agent agent) {
        this.negativeVotes.remove(agent);
        this.positiveVotes.add(agent);
    }
    public void removeUser(Agent agent) {
        this.negativeVotes.remove(agent);
        this.positiveVotes.remove(agent);
    }
    public Tag getTag() {
        return tag.get();
    }
    public InformationObjectNode getNode() {
        return this.information.get();
    }
    public boolean isPositive() {
        return positiveVotes.size() > negativeVotes.size();
    }
    public int getWeight() {
        return positiveVotes.size() - negativeVotes.size();
    }
}
