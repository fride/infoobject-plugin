package da.ises.magicmap.domain.tag;

import da.ises.core.infoobject.Tag;

import java.util.Set;

/**
 * <p>
 * Class NewTagsEvent ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 21.07.2008
 *         Time: 00:49:15
 */
public class NewTagsEvent {
    private final Set<Tag> newTags;

    public NewTagsEvent(Set<Tag> newTags) {
        this.newTags = newTags;
    }

    public Set<Tag> getNewTags() {
        return newTags;
    }
}
