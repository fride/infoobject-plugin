package da.ises.magicmap.domain.association;

import edu.uci.ics.jung.graph.Graph;

import da.ises.magicmap.domain.association.AssociationSpringLayout;

/**
 *
 */
public class LayoutThreadManager {

    private Thread layoutThread;
    private Graph graph;
    private AssociationSpringLayout springLayout;
    private boolean terminated;
    private boolean suspended;
    private Runnable worker = new Runnable(){
        public void run(){
            while (!terminated) {
                try {
                    if (!suspended) {
                        int x = 129;
                        x = x +2;
                        springLayout.advancePositions();
                    }
                    Thread.sleep(30);
                } catch (InterruptedException ex) {
                    // nix zu dun ;-)
                }
            }
        }
    };

    /**
     *
     * @param springLayout
     */
    public LayoutThreadManager(AssociationSpringLayout springLayout) {
        this.springLayout = springLayout;
    }

    public void suspend() {
        this.suspended = true;
        layoutThread.interrupt();
    }

    public void unsupend() {
        this.suspended = false;
        layoutThread.interrupt();
    }

    public void start() {
        if (layoutThread != null) {
            return;
        }
        layoutThread = new Thread(worker,"association layout thread");
        layoutThread.setDaemon(true);
        layoutThread.start();
    }

    public void stop () {
        this.terminated = true;
        layoutThread.interrupt();
    }
}
