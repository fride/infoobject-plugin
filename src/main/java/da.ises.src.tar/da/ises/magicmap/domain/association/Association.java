package da.ises.magicmap.domain.association;

import net.sf.magicmap.client.model.node.IMagicEdge;
import net.sf.magicmap.client.model.node.Node;
import da.ises.magicmap.domain.node.AbstractInformationNode;

/**
 * <p>
 * Class Association ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 17.07.2008
 *         Time: 21:40:50
 */
public interface Association {

    public static final String ASSOCIATION_META_KEY = "association.meta";

    /**
     * 
     * @return
     */
    Node getSource();

    Node getTarget();

    /**
     * 
     * @return
     */
    String getAssociationType();


    double getWeight();
    
}
