package da.ises.magicmap.domain.association;

import org.apache.commons.collections15.Predicate;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * Class AssociationEdgeFilter ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 04.08.2008
 *         Time: 21:36:18
 */
public class AssociationEdgeFilter implements Predicate<AssociationEdge> {

    private List<AssociationFilter> filters = new ArrayList<AssociationFilter>();

    /**
     * Check if an associations is left after all filters are applied.
     * @param associationEdge
     * @return
     */
    public boolean evaluate(AssociationEdge associationEdge) {
        int associationCount = associationEdge.size();
        for (AssociationFilter filter:filters){
            Association association = associationEdge.get(filter.getAssociationTypeName());
            if (association != null && !filter.evaluate(association)){
                associationCount--;
            }

        }
        return associationCount < 0;
    }

    public void add(AssociationFilter filter) {
        this.filters.add(filter);
    }
}
