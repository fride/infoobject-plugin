package da.ises.magicmap.domain.association;

import net.sf.magicmap.client.model.node.IMagicEdge;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * <p>
 * Class AssociationEdge ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 20.07.2008
 *         Time: 15:38:27
 */
public class AssociationEdge implements Iterable<Association>{
    private final WeakReference<IMagicEdge> edge;
    private final Map<String, Association>  associations = new HashMap<String, Association>();

    public AssociationEdge(IMagicEdge edge) {
        this.edge = new WeakReference<IMagicEdge>(edge);
    }

    public IMagicEdge getEdge() {
        return edge.get();
    }


    public void put(Association association) {
        this.associations.put(association.getAssociationType(), association);        
    }
    
    public Association get(String type) {
        return associations.get(type);
    }

    public void remove(Association association) {
        associations.remove(association.getAssociationType());
    }

    public int size() {
        return associations.size();
    }

    public Iterator<Association> iterator() {
        return new ArrayList<Association>(associations.values()).iterator();
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AssociationEdge)) return false;

        AssociationEdge that = (AssociationEdge) o;

        if (edge != null ? !edge.equals(that.edge) : that.edge != null) return false;

        return true;
    }

    public int hashCode() {
        return (edge != null ? edge.hashCode() : 0);
    }
}
