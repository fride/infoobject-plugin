package da.ises.magicmap.domain.node;

import net.sf.magicmap.client.model.node.*;
import net.sf.magicmap.client.model.location.INodePlacer;
import net.sf.magicmap.client.interfaces.NodeModelListener;
import net.sf.magicmap.client.meta.MapInfo;
import net.sf.magicmap.client.utils.AbstractModel;

import java.util.*;

import da.ises.core.domain.user.Agent;
import da.ises.magicmap.ui.log.LogEvent;
import da.ises.magicmap.domain.node.NodeFilter;
import org.bushe.swing.event.EventBus;

/**
 * The NodeModel with added stuff.
 */
public class InformationNodeModel extends AbstractModel implements INodeModel {
    private final INodeModel delegate;
    private final Map<String,Node> filteredNodes = new HashMap<String,Node>();
    private final List<NodeFilter> filters = new LinkedList<NodeFilter>();
    

    /**
     * The current user owning this model. (aka. me)
     */
    private Agent agent;
    //private MultiMap<Agent, InformationObjectNode> infosByUsers = new MultiHashMap<Agent, InformationObjectNode>();

    /**
     *
     * @param delegate the original model.
     */
    public InformationNodeModel(INodeModel delegate) {
        this.delegate = delegate;
    }

    /**
     *
     * @param filter
     */
    public void addFilter(NodeFilter filter) {
        synchronized (filters) {
            this.filters.add(filter);
        }
    }

    public Iterable<NodeFilter> getFilters() {
        synchronized (filters) {
            return new ArrayList<NodeFilter>(filters);
        }
    }


    /**
     * 
     * @param node
     */
    public void addNode(Node node) {
        if (shouldInsert(node)) {
            delegate.addNode(node);
            EventBus.publish(new LogEvent("Node Added " + node.getName(), LogEvent.Type.INFO));
        }else {
            filteredNodes.put(node.getName(),node);
            EventBus.publish(new LogEvent("Node Filtered " + node.getName(), LogEvent.Type.INFO));
        }
    }

    
    public boolean shouldInsert(Node node) {
        if (node instanceof MapNode) return true;
        if (filters.size() == 0) return true;

        boolean accepted = true;
        for (NodeFilter filter:getFilters()) {
            if (!filter.evaluate(node)) {
                accepted = false;
                break;
            }
        }
        return accepted;
    }

    public synchronized void filterChanged() {
        List<Node> nodes = new ArrayList<Node>(filteredNodes.values());
        // Dirty hack that works only because the parent depth is just 1.
        // gets all Nodes first that dont have any parents.
        Collections.sort(nodes, new Comparator<Node>() {
            public int compare(Node node1, Node node2) {
                if (node2.getParentNode() == null) return 1;
                if (node1.getParentNode() == null) return -1;
                if (node1.equals(node2)) return 0;
                if (node2.getParentNode().equals(node1)) return -1;
                return 1;
            }
        });
        for (Node node:nodes){
            if (shouldInsert(node)){
                unfilterNode(node);
            }
        }
        nodes = new ArrayList<Node>(delegate.getNodes());
        for (Node node:nodes){
            if (!shouldInsert(node)){
                // call super so the filtered node will not be
                // removed ;-)
                delegate.removeNode(node);
                filteredNodes.put(node.getName(),node);
            }
        }

    }

    private void unfilterNode(Node node) {
        addNode(node);
        filteredNodes.remove(node.getName());
    }

    /**
     * get a copy of he filtered nodes.
     * @return
     */
    public Set<Node> getFilteredNodes() {
        return new HashSet<Node>(filteredNodes.values());
    }

    public void clearFilteredNodes() {
        this.filteredNodes.clear();
    }
    
    public void removeNode(Node node) {
        delegate.removeNode(node);
        this.filteredNodes.remove(node.getName());
    }

    public void updateNode(Node node, int i, Object o) {
        delegate.updateNode(node, i, o);
    }

    /**
     * 
     * @param node
     * @param s
     */
    public void rehashNode(Node node, String s) {
        delegate.rehashNode(node, s);
        if (filteredNodes.containsKey(s)){
            filteredNodes.remove(s);
            filteredNodes.put(node.getName(), node);
        }
    }

    public ArrayList<? extends Node> findNeighbors(Node node) {
        return delegate.findNeighbors(node);
    }

    public ArrayList<? extends Node> findNonNeighbors(Node node) {
        return delegate.findNonNeighbors(node);
    }

    public void addNodeModelListener(NodeModelListener nodeModelListener) {
        delegate.addNodeModelListener(nodeModelListener);
    }

    public void removeNodeModelListener(NodeModelListener nodeModelListener) {
        delegate.removeNodeModelListener(nodeModelListener);
    }

    public NodeModelListener[] nodeModelListeners() {
        return delegate.nodeModelListeners();
    }

    public Set<AccessPointSeerNode> getAccessPointSeerNodes() {
        return delegate.getAccessPointSeerNodes();
    }

    public ArrayList<LocationNode> getLocationsWithAtLeastOneAccessPoint(ArrayList<AccessPointNode> accessPointNodes) {
        return delegate.getLocationsWithAtLeastOneAccessPoint(accessPointNodes);
    }

    public ArrayList<LocationNode> getLocationsWithAtLeastOneAccessPoint(ArrayList<AccessPointNode> accessPointNodes, Node node) {
        return delegate.getLocationsWithAtLeastOneAccessPoint(accessPointNodes, node);
    }

    public Node findNode(String s) {
        return delegate.findNode(s);
    }

    public boolean nodeExists(String s) {
        return delegate.nodeExists(s);
    }

    public AccessPointNode findAccessPoint(String s) {
        return delegate.findAccessPoint(s);
    }

    public boolean accessPointExists(String s) {
        return delegate.accessPointExists(s);
    }

    public ClientNode findClient(String s) {
        return delegate.findClient(s);
    }

    public boolean clientExists(String s) {
        return delegate.clientExists(s);
    }

    public Collection<Node> getNodes() {
        return delegate.getNodes();
    }

    public void clear() {
        delegate.clear();
    }

    public void setNodePlacer(INodePlacer iNodePlacer) {
        delegate.setNodePlacer(iNodePlacer);
    }

    public INodePlacer getNodePlacer() {
        return delegate.getNodePlacer();
    }

    public void setCurrentMap(MapInfo mapInfo) {
        delegate.setCurrentMap(mapInfo);
    }

    public MapNode getCurrentMap() {
        return delegate.getCurrentMap();
    }

    public void setServerID(String s) {
        delegate.setServerID(s);
    }

    public String getServerID() {
        return delegate.getServerID();
    }

    public <K, N extends INode> INodeIndex<K, N> createIndex(NodeKeyFunction<K, N> knNodeKeyFunction) {
        return delegate.createIndex(knNodeKeyFunction);
    }

    public boolean removeIndex(INodeIndex iNodeIndex) {
        return delegate.removeIndex(iNodeIndex);
    }

    public List<? extends INodeIndex> getNodeIndexList() {
        return delegate.getNodeIndexList();
    }

    public Collection<INodeGraph> getSubGraphs() {
        return delegate.getSubGraphs();
    }

    public IMagicEdge addEdge(Node node, Node node1) {
        return delegate.addEdge(node, node1);
    }

    public IMagicEdge getEdge(Node node, Node node1) {
        return delegate.getEdge(node, node1);
    }

    public boolean removeEdge(Node node, Node node1) {
        return delegate.removeEdge(node, node1);
    }

    public Set<? extends IMagicEdge> getEdges() {
        return delegate.getEdges();
    }

    public void addNodeGraphListener(NodeGraphListener nodeGraphListener) {
        delegate.addNodeGraphListener(nodeGraphListener);
    }

    public void removeNodeGraphListener(NodeGraphListener nodeGraphListener) {
        delegate.removeNodeGraphListener(nodeGraphListener);
    }

    public NodeGraphListener[] getNodeGraphListeners() {
        return delegate.getNodeGraphListeners();
    }

    public boolean addNodeGraph(INodeGraph iNodeGraph) {
        return delegate.addNodeGraph(iNodeGraph);
    }

    public boolean removeSubGraph(INodeGraph iNodeGraph) {
        return delegate.removeSubGraph(iNodeGraph);
    }

    public Collection<EdgeType> getSupportedEdgeTypes() {
        return delegate.getSupportedEdgeTypes();
    }


  
    /**
     *
     * @param uri
     * @return
     */
    public InformationObjectNode findInformationNode(String uri) {
        return (InformationObjectNode) findNode("nfo:" + uri);
    }


    /**
     * Get the original model.
     * @return the original model.
     */
    public INodeModel getDelegate() {
        return delegate;
    }

    /**
     * Get the user owning the model.
     * @return the owner.
     */
    public Agent getUser() {
        return agent;
    }

    /**
     * Set the owner of this model.
     * @param agent the new owner.
     */
    public void setUser(Agent agent) {
        this.agent = agent;
        firePropertyChange("agent", null, agent);
    }

    public void removeFilter(NodeFilter filter) {
        this.filters.remove(filter);
    }


}
