package da.ises.magicmap.domain.tag;

import da.ises.core.infoobject.Tag;
import da.ises.magicmap.domain.node.InformationObjectNode;

/**
 * <p>
 * Taggings represnt the anonymous numbers behind a set of single Tagging ojects.
 *
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 19:57:35
 */
public class Taggings {
    private Tag tag;
    private InformationObjectNode node;
    private int weight;

    public Taggings(Tag tag, InformationObjectNode node, int weight) {
        this.tag = tag;
        this.node = node;
        this.weight = weight;
    }

    public Tag getTag() {
        return tag;
    }

    public InformationObjectNode getNode() {
        return node;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getWeight() {
        return weight;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Taggings)) return false;

        Taggings taggings = (Taggings) o;

        if (node != null ? !node.equals(taggings.node) : taggings.node != null) return false;
        if (tag != null ? !tag.equals(taggings.tag) : taggings.tag != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (tag != null ? tag.hashCode() : 0);
        result = 31 * result + (node != null ? node.hashCode() : 0);
        return result;
    }
}
