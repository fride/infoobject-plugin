package da.ises.magicmap.domain.node;

import net.sf.magicmap.client.model.node.INodeModel;

/**
 * <p>
 * Class PlaneNode ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 23:52:02
 */
public class PlaneNode extends VehicleNode{
    public PlaneNode(INodeModel iNodeModel) {
        super(iNodeModel);
    }
}
