package da.ises.magicmap.domain.tag;

import da.ises.core.infoobject.Tag;

import java.util.EventObject;

/**
 * 
 */
public class TagEvent extends EventObject {
    private final Tag tag;

    public TagEvent(TagModel model, Tag tag) {
        super(model);
        this.tag = tag;
    }

    @Override
    public TagModel getSource() {
        return (TagModel)super.getSource();
    }

    public Tag getTag() {
        return tag;
    }
}
