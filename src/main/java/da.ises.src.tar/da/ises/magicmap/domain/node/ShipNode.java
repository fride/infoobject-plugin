package da.ises.magicmap.domain.node;

import net.sf.magicmap.client.model.node.INodeModel;

/**
 * <p>
 * Class ShipNode ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 23:47:10
 */
public class ShipNode extends VehicleNode{
    public ShipNode(INodeModel iNodeModel) {
        super(iNodeModel);
    }
}
