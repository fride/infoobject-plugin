package da.ises.magicmap.domain.association;


import static da.ises.magicmap.domain.association.InformationEdgeType.EDGE_TYPE_KEY;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.domain.node.NodeFilter;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.filters.GeneralEdgeAcceptFilter;
import edu.uci.ics.jung.graph.filters.GeneralVertexAcceptFilter;
import edu.uci.ics.jung.graph.filters.SerialFilter;
import edu.uci.ics.jung.graph.filters.UnassembledGraph;
import net.sf.magicmap.client.model.node.IMagicEdge;
import net.sf.magicmap.client.model.node.MapNode;
import net.sf.magicmap.client.model.node.Node;
import net.sf.magicmap.client.model.node.jung.JungEdge;
import net.sf.magicmap.client.model.node.jung.JungNodeGraph;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.awt.*;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;


/**
 *
 * A Graph containing all assocations between:
 * <ul>
 *  <li>informations and physcals objects (position associations)</li>
 *  <li>informaions and informations (semantic assications)</li>
 */
public class AssociationGraph extends JungNodeGraph{

    private static final Log log = LogFactory.getLog("plam");
    private AssociationSpringLayout layout;
    private WeakHashMap<IMagicEdge,AssociationEdge> associations = new WeakHashMap<IMagicEdge, AssociationEdge>();

    private SerialFilter filter = new SerialFilter();
    

    /**
     * 
     */
    public AssociationGraph() {
        super(new InformationEdgeType());
        layout = new AssociationSpringLayout(getGraph());
        layout.resize(new Dimension(800,600));
    }

    public void addFilter(final AssociationEdgeFilter filter){
        final GeneralEdgeAcceptFilter adaper = new GeneralEdgeAcceptFilter() {
            public boolean acceptEdge(Edge edge) {
                return filter.evaluate(getAssociation((IMagicEdge) edge));
            }

            public String getName() {
                return filter.getClass().getSimpleName(); 
            }
        };
        this.filter.append(adaper);
    }
    public void addFilter(final NodeFilter filter){
        final GeneralVertexAcceptFilter adapter = new GeneralVertexAcceptFilter() {
            public boolean acceptVertex(Vertex vertex) {
                return filter.evaluate((Node) vertex.getUserDatum(NODE_KEY)); 
            }

            public String getName() {
                return filter.getClass().getSimpleName();
            }
        };
        this.filter.append(adapter);
    }


    public void filter(){
        UnassembledGraph filteredGraph = filter.filter(getGraph());
        getLayout().applyFilter(filteredGraph.assemble());
    }
    
    public Set<AssociationEdge> getAssociationEdges() {
        return new HashSet < AssociationEdge>(associations.values());
    }

    /**
     *
     * @return
     */
    public AssociationSpringLayout getLayout() {
        return layout;
    }

    /**
     * 
     * @param source
     * @param target
     * @return
     */
    public AssociationEdge getAssociationEdge(InformationObjectNode source, InformationObjectNode target){
        JungEdge edge = super.getEdge(source,target);
        return edge != null ? associations.get(edge) : null;
    }
  


    /**
     * Create a vertex for the given node.
     *
     * @param node
     */
    @Override
    public void insertNode(Node node) {
        if (node instanceof MapNode) return;
        if ((node instanceof InformationObjectNode) || node.isPhysical()) {
            super.insertNode(node);
        }
    }

    /**
     * Will always throw an IllegalStateException use one of the folloing methods instead.
     * Deprecated to spot errors in compiler!
     *
     * @see #insertNode(net.sf.magicmap.client.model.node.Node)
     */
    @Override
    @Deprecated
    public synchronized IMagicEdge addEdge(Node n1, Node n2) {
        throw new IllegalStateException("Use the addXYZEdge Methods please!");
    }

    /**
     * 
     * @param n1
     * @param n2
     * @param association
     * @return
     */
    public IMagicEdge addAssociation(Node n1, Node n2, Association association) {
        checkEdgeNodes(n1, n2);
        IMagicEdge edge = super.addEdge(n1, n2,new String[]{EDGE_TYPE_KEY}, new Object[]{InformationEdgeType.AssociationTyp.ASSOCIATION});
        AssociationEdge associationEdge = new AssociationEdge(edge);
        associationEdge.put(association);
        this.associations.put(edge, associationEdge);
        return edge;
    }


    /**
     * 
     * @param n1
     * @param n2
     * @param association
     */
    public void removeAssociation(InformationObjectNode n1, InformationObjectNode n2, Association association){
        AssociationEdge associationEdge = getAssociationEdge(n1, n2);
        if (associationEdge != null) {
            associationEdge.remove(association);
            if (associationEdge.size() == 0) {
                removeEdge(n1,n2);
            }
        }
    }
    /**
     *
     */
    public void removeEdges() {
        Set<JungEdge> jungEdges = getEdges();
        for (JungEdge edge : jungEdges.toArray(new JungEdge[jungEdges.size()])) {
            getGraph().removeEdge(edge);
            this.associations.clear();
        }
    }




    private void checkEdgeNodes(Node node, Node nodeTwo) {
        if (null == findVertex(node)) {
            log.info("Adding physical Node: " + node.getDisplayName());
            insertNode(node);
            //getLayout().forceMove(findVertex(node), node.getX(), node.getY());
        } else {
            log.info("physical Node: " + node.getDisplayName() +" in graph, no need to add.");
        }
        if (null == findVertex(nodeTwo)) {
            insertNode(nodeTwo);
            log.info("Adding Node: " + node.getDisplayName());
            //getLayout().forceMove(findVertex(nodeTwo), nodeTwo.getX(), nodeTwo.getY());
        }

        if (node.isPhysical()) {
            layout.setFix(findVertex(node));
        }
        if (nodeTwo.isPhysical()) {
            layout.setFix(findVertex(nodeTwo));
        }
    }

    /**
     * 
     * @param node
     */
    public void updatePosition(Node node) {
    	Vertex v = (super.findVertex(node));
    	if (v != null)
    		getLayout().forceMove(v,node.getX(), node.getY());
    }

    public IMagicEdge addPosition(InformationObjectNode source, Node annotatedNode) {
        checkEdgeNodes(source, annotatedNode);
        return super.addEdge(source, annotatedNode,new String[]{EDGE_TYPE_KEY}, new Object[]{InformationEdgeType.AssociationTyp.POSITION});
    }

    /**
     * 
     * @param source
     * @param target
     */
    public void removePosition(InformationObjectNode source, Node target){
        removeEdge(source,target);
    }


    public AssociationEdge getAssociation(IMagicEdge edge) {
        return this.associations.get(edge);
    }
}
