package da.ises.magicmap.domain.association;

import net.sf.magicmap.client.model.node.EdgeType;
import net.sf.magicmap.client.model.node.IMagicEdge;

/**
 * 
 */
public class InformationEdgeType extends EdgeType {

    public static final String EDGE_TYPE_KEY = "association.type";


    public enum AssociationTyp{
        POSITION,
        ASSOCIATION,
        NONE
    }
    /**
	 *
	 */
	public InformationEdgeType() {
		super("ASSOCIATION");
	}

	@Override
	public EdgeType getParent() {
		return getSemantic();
	}

	static {
		register(new InformationEdgeType());
	}

    /**
     * 
     * @param edge
     * @return
     */
    public static boolean isAssociationEdge(IMagicEdge edge) {
        return edge.getValue(EDGE_TYPE_KEY) != null;
    }

    /**
     *
     * @param edge
     * @return
     */
    public static AssociationTyp getAssociationType(IMagicEdge edge) {
        if (!isAssociationEdge(edge)) {
            return AssociationTyp.NONE;
        }
        else{
            return  (AssociationTyp) edge.getValue(EDGE_TYPE_KEY);
        }
    }

}
