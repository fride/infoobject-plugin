package da.ises.magicmap.domain.tag;

import edu.uci.ics.jung.graph.impl.BipartiteVertex;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.core.infoobject.Tag;

import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.HashMap;
import java.util.Collection;

/**
 * <p>
 * Class NodeVertex ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 21.07.2008
 *         Time: 01:06:59
 */
public class NodeVertex extends BipartiteVertex {
    
    private final WeakReference<InformationObjectNode> node;

    public NodeVertex(InformationObjectNode node) {
        this.node = new WeakReference<InformationObjectNode>(node);
    }

    public InformationObjectNode getNode() {
        return node.get();
    }

    /**
     * get a map with the tag weights.
     * @return
     */
    @SuppressWarnings({"unchecked"})
    public Map<Tag, Integer> getTags() {
        final Map<Tag,Integer> tags = new HashMap<Tag, Integer>();
        Collection<TagEdge> internal = getEdges_internal();
        if (internal != null) {
            TagEdge[] tagsEdges = internal.toArray(new TagEdge[internal.size()]);
            for (TagEdge e:tagsEdges) {
                tags.put(e.getTag(), e.getWeight());
            }
        }
        return tags;
    }
}
