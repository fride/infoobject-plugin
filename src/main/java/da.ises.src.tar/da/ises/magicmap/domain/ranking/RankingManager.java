package da.ises.magicmap.domain.ranking;

import net.sf.magicmap.client.model.node.Node;

import java.util.WeakHashMap;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

import org.apache.commons.collections15.Closure;
import org.apache.commons.collections15.Transformer;

/**
 * 
 */
public class RankingManager {

    private final Map<RankingFunction, Double> rankingFunctions = new HashMap<RankingFunction, Double>();
    private final WeakHashMap<Node, Double> rankings = new WeakHashMap<Node, Double>();

    private final Transformer<Node,Double> ranker = new Transformer<Node,Double>() {
        public Double transform(Node node) {
            double weight = 0.0;
            for (Map.Entry<RankingFunction, Double> f: rankingFunctions.entrySet()) {
                weight += f.getKey().transform(node) * f.getValue();
            }
            return weight;
        }
    };

    public void add(RankingFunction function){
        add(function,1.0);
    }

    /**
     * 
     * @param node
     * @return
     */
    public double getRanking(Node node){
        synchronized (rankings) {
            Double d = rankings.get(node);
            return d != null ? d.doubleValue() : 0.0;
        }
    }
    /**
     * 
     * @param function the ranking function.
     * @param weight weight for this ranking.
     */
    public void add(RankingFunction function, double weight){
        this.rankingFunctions.put(function, weight);
        refresh();
    }
    public void remove(RankingFunction function) {
        this.rankingFunctions.remove(function);
        refresh();
    }
    
    public void remove(Node node){
        synchronized (rankings) {
            rankings.remove(node);
        }

    }

    public void refresh() {
        synchronized (rankings) {
            Set<Node> nodes = rankings.keySet();
            for (Node node:nodes) {
                add(node);
            }
        }
    }
    public void add(Node node) {
        rankings.put(node, ranker.transform(node));        
    }
}
