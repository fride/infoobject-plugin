package da.ises.magicmap.domain.node;

import net.sf.magicmap.client.model.node.Node;

import java.util.ArrayList;

/**
 * <p>
 * Class DelegatingNodeFilter ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 04.08.2008
 *         Time: 22:30:23
 */
public class DelegatingNodeFilter implements NodeFilter{
    private ArrayList<NodeFilter> filters = new ArrayList<NodeFilter>();

    public void add(NodeFilter filter){
        this.filters.add(filter);
    }

    public boolean remove(NodeFilter filter){
        return this.filters.remove(filter);
    }
    /**
     * Return true if the node should be included..
     *
     * @param node the node to filter.
     * @return true if the node sould be included.
     */
    public boolean evaluate(Node node) {
        for (NodeFilter filter:filters){
            if (!filter.evaluate(node)) return false;
        }
        return true;
    }
}
