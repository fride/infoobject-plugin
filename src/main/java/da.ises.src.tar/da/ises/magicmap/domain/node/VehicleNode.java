package da.ises.magicmap.domain.node;

import net.sf.magicmap.client.model.node.Node;
import net.sf.magicmap.client.model.node.INodeModel;

import java.util.ArrayList;

/**
 * <p>
 * Class VehicleNode ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 23:45:44
 */
public abstract class VehicleNode extends Node {
    public static final int NODE_TYPE = -7324;

    public VehicleNode(INodeModel iNodeModel) {
        super(iNodeModel);
    }

    public ArrayList<? extends Node> getNeighbors() {
        return new ArrayList<Node>();
    }

    public int getType() {
        return NODE_TYPE;
    }
}
