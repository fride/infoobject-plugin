package da.ises.magicmap.domain.node;

import net.sf.magicmap.client.model.node.INodeModel;

/**
 * <p>
 * Class BusNode ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 23:46:55
 */
public class BusNode extends VehicleNode{
    public BusNode(INodeModel iNodeModel) {
        super(iNodeModel);
    }
}
