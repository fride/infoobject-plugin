package da.ises.magicmap.domain.node;

import da.ises.core.domain.user.Agent;
import da.ises.core.infoobject.Tagging;
import net.sf.magicmap.client.model.node.Node;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * Class InformationPosition ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 20.07.2008
 *         Time: 20:00:56
 */
public class ObjectNodeLink {
    private Node positionNode;
    private Map<Agent, Tagging> annotations = new HashMap<Agent, Tagging>();


    public ObjectNodeLink(Node positionNode) {
        this.positionNode = positionNode;
    }

    public ObjectNodeLink(Tagging annotation,Node positionNode) {
        this.positionNode = positionNode;
        this.annotations.put(annotation.getAgentId(), annotation);
    }
    public Node getPositionNode() {
        return positionNode;
    }

    public Map<Agent, Tagging> getAnnotations() {
        return annotations;
    }
    public void addTags(Tagging tags){
        this.annotations.put(tags.getAuthor(), tags);
    }
    
}
