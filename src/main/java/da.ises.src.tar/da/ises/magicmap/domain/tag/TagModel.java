package da.ises.magicmap.domain.tag;

import da.ises.core.infoobject.Tag;
import da.ises.magicmap.domain.node.InformationObjectNode;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * Class TagModel ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 19:27:18
 */
public interface TagModel {

    /**
     *
     * @return
     */
    List<Tag> getTags();


    /**
     *
     * @param node
     * @return
     */
    Map<Tag,Integer> getTags(InformationObjectNode node);

    /**
     *
     * @param tag
     * @return
     */
    Map<InformationObjectNode, Integer> getTaggedNodes(Tag tag);

    /**
     *
     * @param node
     * @return
     */
    List<Taggings> getTaggings(InformationObjectNode node);

    /**
     *
     * @param tag
     * @return
     */
    List<Taggings> getTaggings(Tag tag);

    int tagCount(InformationObjectNode node);

    int nodeCount(Tag tag);

    void addTagModelListener(TagModelListener l) ;
    void removeTagModelListener(TagModelListener l);
    TagModelListener[] getTagModelListeners();

}
