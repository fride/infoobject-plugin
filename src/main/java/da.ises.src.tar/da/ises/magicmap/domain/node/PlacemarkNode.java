package da.ises.magicmap.domain.node;

import net.sf.magicmap.client.model.node.Node;
import net.sf.magicmap.client.model.node.INodeModel;

import java.util.ArrayList;

/**
 * 
 */
public class PlacemarkNode extends Node {
    public static final int NODE_TYPE = InformationObjectNode.NODE_TYPE - 12;

    public PlacemarkNode(InformationNodeModel nodeModel) {
        super(nodeModel);
    }

    public ArrayList<? extends Node> getNeighbors() {
        return null;
    }

    public int getType() {
        return NODE_TYPE;
    }

    public InformationNodeModel getModel() {
        return (InformationNodeModel)super.getModel();
    }

    @Override
    public boolean isPhysical() {
        return true;
    }
}
