package da.ises.magicmap.domain.association;

import net.sf.magicmap.client.model.node.Node;
import da.ises.magicmap.domain.node.AbstractInformationNode;

/**
 * <p>
 * Class AssociationBuilder ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 17.07.2008
 *         Time: 22:09:53
 */
public abstract class AssociationBuilder {

    private AssociationGraph graph;

    public AssociationBuilder() {
    }

    public AssociationBuilder(AssociationGraph graph) {
        this.graph = graph;
    }

    /**
     * 
     * @param graph
     */
    public void setAssoiatonGraph(AssociationGraph graph){
        this.graph = graph;
    }
    /**
     *
     * @return
     */
    public abstract Association createAssociation();

    public AssociationGraph getGraph() {
        return graph;
    }
}
