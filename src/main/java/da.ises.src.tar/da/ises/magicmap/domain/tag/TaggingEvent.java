package da.ises.magicmap.domain.tag;

import da.ises.core.infoobject.Tag;
import da.ises.magicmap.domain.node.InformationObjectNode;

import java.util.EventObject;

/**
 * <p>
 * Class TagginEvent ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 19:39:40
 */
public class TaggingEvent extends EventObject {
    private final Tag tag;
    private final InformationObjectNode node;
    private final boolean positive;

    public TaggingEvent(TagModel model, Tag tag, InformationObjectNode node, boolean positive) {
        super(model);
        this.tag = tag;
        this.node = node;
        this.positive = positive;
    }

    @Override
    public TagModel getSource() {
        return (TagModel)super.getSource();
    }

    public Tag getTag() {
        return tag;
    }

    public InformationObjectNode getNode() {
        return node;
    }

    public boolean isPositive() {
        return positive;
    }
    
}
