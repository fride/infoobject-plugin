package da.ises.magicmap.domain.tag;

/**
 * <p>
 * Class TagModelListener ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 23.07.2008
 *         Time: 20:58:38
 */
public interface TagModelListener {

    /**
     * 
     * @param tag
     */
    void tagAdded(TagEvent tag);

    /**
     * 
     * @param tag
     */
    void tagRemoved(TagEvent tag);

    /**
     * 
     * @param tagging
     */
    void taggingAdded(TaggingEvent tagging);

    /**
     * 
     * @param tagging
     */
    void taggingRemoved(TaggingEvent tagging);

}
