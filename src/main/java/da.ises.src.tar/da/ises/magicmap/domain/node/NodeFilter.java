package da.ises.magicmap.domain.node;

import net.sf.magicmap.client.model.node.Node;
import org.apache.commons.collections15.Predicate;

/**
 *
 * 
 */
public interface NodeFilter extends Predicate<Node> {

    /**
     * Return true if the node should be included..
     * @param node the node to filter.
     * @return true if the node sould be included.
     */
    boolean evaluate(Node node);

}
