package da.ises.magicmap.domain.association;

import net.sf.magicmap.client.model.node.IMagicEdge;
import net.sf.magicmap.client.model.node.Node;

/**
 * <p>
 * Class GraphFilterListener ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 00:00:37
 */
public interface GraphFilterListener {

    /**
     * 
     * @param edge
     */
    void edgeFiltered(IMagicEdge edge);

    /**
     * 
     * @param node
     */
    void nodeFiltered(Node node);
}
