package da.ises.magicmap.domain;

import da.ises.magicmap.domain.association.AssociationGraph;
import da.ises.magicmap.domain.tag.InformationTagModel;
import da.ises.magicmap.domain.node.InformationNodeModel;
import da.ises.magicmap.domain.ranking.RankingManager;
import da.ises.magicmap.controller.association.AssociationManager;
import net.sf.magicmap.client.controller.Controller;
import net.sf.magicmap.client.interfaces.NodeModelListener;
import net.sf.magicmap.client.model.node.Node;

/**
 * 
 */
public class ModelFactory {
    private InformationNodeModel nodeModel;
    private AssociationGraph associationGraph;
    private AssociationManager associationManager;

    private InformationTagModel informationTagModel;


    private RankingManager rankingManager;
    public ModelFactory() {
    }
    /**
     * 
     * @return
     */
    public InformationNodeModel getNodeModel() {
        if (nodeModel == null) {
            nodeModel = new InformationNodeModel(Controller.getInstance().getNodeModel());
        }
        return nodeModel;
    }


    /**
     * 
     * @return
     */
    public AssociationGraph getAssociationGraph() {
        if (associationGraph == null) {
            associationGraph = new AssociationGraph();
            //getNodeModel().addNodeGraph(associationGraph);
        }
        return associationGraph;
    }

    /**
     * 
     * @return
     */
    public InformationTagModel getInformationTagModel() {
        if (informationTagModel == null) {
            informationTagModel = new InformationTagModel();
        }
        return informationTagModel;
    }

    /**
     * 
     * @return
     */
    public AssociationManager getAssociationManager() {
        if (associationManager == null) {
            associationManager = new AssociationManager(getAssociationGraph());
        }
        return associationManager;
    }

    /**
     * 
     * @return
     */
    public RankingManager getRankingManager() {
        if (rankingManager == null) {
            rankingManager = new RankingManager();
            getNodeModel().addNodeModelListener(new NodeModelListener() {
                public void nodeAddedEvent(Node node) {
                    rankingManager.add(node);
                }

                public void nodeUpdatedEvent(Node node, int i, Object o) {
                }

                public void nodeRemovedEvent(Node node) {
                    rankingManager.remove(node);
                }
            });
        }
        return rankingManager;
    }
}
