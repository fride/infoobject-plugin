package da.ises.magicmap.domain.ranking;

import net.sf.magicmap.client.model.node.Node;
import org.apache.commons.collections15.Transformer;

/**
 *
 * 
 */
public interface RankingFunction extends Transformer<Node, Double> {
    
    /**
     * get the ranking for the given node.
     *
     * @param node
     * @return
     */
    Double transform(Node node);
}
