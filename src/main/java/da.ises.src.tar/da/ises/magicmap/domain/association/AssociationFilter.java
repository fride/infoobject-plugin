package da.ises.magicmap.domain.association;

import org.apache.commons.collections15.Predicate;

/**
 * <p>
 * Class AssociationFilter ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 03.08.2008
 *         Time: 20:07:30
 */
public interface AssociationFilter extends Predicate<Association> {
    
    /**
     * return true if he association sould be used.
     * @param association the association to check.
     * @return
     */
    @Override
    boolean evaluate(Association association);

    /**
     * 
     * @return
     */
    String getAssociationTypeName();
}
