package da.ises.magicmap.domain.node;

import da.ises.core.domain.infoobject.InformationObject;
import net.sf.magicmap.client.model.node.Node;


/**
 *
 * 
 */
public abstract class AbstractInformationNode extends Node {
    private InformationObject informationObject;
    public static final int TAGS_CHANGED = -678762;


    /**
     * 
     * @param nodeModel
     * @param informationObject
     */
    protected AbstractInformationNode(InformationNodeModel nodeModel, InformationObject informationObject) {
        super(nodeModel);
        this.informationObject = informationObject;
        setName(informationObject.getId());
    }

   

    public InformationNodeModel getModel() {
        return (InformationNodeModel)super.getModel(); 
    }

    /**
     *
     * @return the informaion object this nodes is about.
     */
    public InformationObject getInformationObject() {
        return informationObject;
    }


    public boolean isPhysical() {
        return false;
    }
}
