package da.ises.magicmap.domain.link;

/**
 * <p>
 * Class LinkModel ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 18:17:13
 */
public class LinkModel {
   
}
