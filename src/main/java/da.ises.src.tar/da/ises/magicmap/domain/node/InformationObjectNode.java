package da.ises.magicmap.domain.node;

import da.ises.core.infoobject.Tag;
import da.ises.core.infoobject.Tagging;
import da.ises.core.domain.entity.Title;
import da.ises.core.domain.infoobject.InformationObject;
import net.sf.magicmap.client.model.node.Node;

import java.util.*;

/**
 *
 *
 */
public class InformationObjectNode extends AbstractInformationNode{

    public static int NODE_TYPE =-666;
    private String informationUri;
    
    private Map<String, Tagging> annotations = new HashMap<String, Tagging>();
    private Map<Node, ObjectNodeLink> positions = new HashMap<Node, ObjectNodeLink>();
    public static final int TAGS_ADDED = -123;
    public static final int TAGS_REMOVED = -124;
    public static final int POSITION_ADDED = -125;
    public static final int POSITION_REMOVED = -126;


    /**
     *
     *
     * @param nodeModel
     * @param informationObject
     */
    public InformationObjectNode(InformationNodeModel nodeModel, InformationObject informationObject) {
        super(nodeModel, informationObject);
        setName("nfo:" + informationObject.getId());
        super.setDisplayName(informationObject.getTitle().getTitle());
    }



    public String getUrl() {
        return getInformationObject().getId();
    }

    /**
     *
     * @param tags
     */
    public void addTags(Tagging tags) {
        this.annotations.put(tags.getAgentId(), tags);
        getModel().updateNode(this, TAGS_ADDED, tags);
    }

    /**
     * 
     * @param position
     */
    public void addPosition(ObjectNodeLink position) {
        Node positionNode = position.getPositionNode();
        if (this.positions.containsKey(positionNode)) {
            this.positions.get(positionNode);
        } else {
            this.positions.put(positionNode, position);
             getModel().updateNode(this, POSITION_ADDED, position);
        }

    }
     /**
     *
     * @return
     */
    public String getDisplayName() {
        Title title = getInformationObject().getTitle();
        return title.getTitle() != null ? title.getTitle() : getInformationObject().getId();
    }

    public long getInformationSize() {
        return getInformationObject().getSize();        
    }

    public String getMimeType() {
        return getInformationObject().getMimeType().getMimeType();
    }
    
    public Set<String> getFacets() {
        return new HashSet<String>(getInformationObject().getFacetTypes());
    }
    /**
     *
     * @param s
     */
    public void setDisplayName(String s) {
        getInformationObject().setTitle(Title.title(s));
        super.setDisplayName(s);
    }

    /**
     * All Annotated nodes.
     * @return
     */
    public ArrayList<? extends Node> getNeighbors() {
        //ArrayList<Node> neighbors = new ArrayList<Node>(positionUserMap.size());
        return null;//neighbors;
    }


    /**
     * 
     * @return
     */
    public Iterable<Tagging> tags() {
        return new ArrayList<Tagging>(annotations.values());
    }

    public Set<Tag> getTags() {
        HashSet<Tag> tags = new HashSet<Tag>();
        for (Tagging informationObject :tags()) {
            //tags.addAll(informationObject.getTags().keySet());
        }
        return tags;
    }
    /**
     * 
     * @return
     */
    public Iterable<ObjectNodeLink> getPositions(){
        return new ArrayList<ObjectNodeLink>(positions.values());
    }

    /**
     *
     * @return
     */
    public int getType() {
        return NODE_TYPE;
    }

    /**
     *
     * @param node
     * @return false.
     */
    public boolean removeNode(Node node) {
        return false;
    }

    public Collection<Tagging> getTagAnnotation() {
        return new ArrayList<Tagging>(annotations.values());
    }
}
