package da.ises.magicmap.domain.link;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * <p>
 * Class Link ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 05.08.2008
 *         Time: 18:17:21
 */
public class Link {
    private Set<String> titles = new HashSet<String>();
    private String source;
    private String target;

    public Link(String source, String target) {
        this.source = source;
        this.target = target;
    }

    public Link() {
    }

    public Link(String source, String target, String... title) {
        this.source = source;
        this.target = target;
        if (title != null){
            Collections.addAll(this.titles, title);
        }
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public Set<String> getTitles() {
        return titles;
    }

    public void setTitles(Set<String> titles) {
        this.titles = titles;
    }
}
