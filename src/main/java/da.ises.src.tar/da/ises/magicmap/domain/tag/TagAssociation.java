package da.ises.magicmap.domain.tag;

import da.ises.core.infoobject.Tag;
import da.ises.magicmap.domain.association.Association;
import da.ises.magicmap.domain.node.AbstractInformationNode;
import da.ises.magicmap.domain.node.InformationObjectNode;

import java.util.Set;
import java.util.HashSet;

/**
 * <p>
 * Class TagAssociation ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 17.07.2008
 *         Time: 21:51:31
 */
public class TagAssociation implements Association {
    private InformationObjectNode source;
    private InformationObjectNode target;
    private TagModel tagModel;
    private double weight;
    private Set<Tag> commonTags = new HashSet<Tag>();
    public static final String ASSOCIATION_NAME = "tag";

    /**
     * 
     * @param source
     * @param target
     * @param tagModel
     */
    public TagAssociation(InformationObjectNode source, InformationObjectNode target, TagModel tagModel) {
        this.source = source;
        this.target = target;
        this.tagModel = tagModel;
    }

    public void add(Tag tag){
        this.commonTags.add(tag);
    }

    public void remove(Tag tag){
        this.commonTags.remove(tag);
    }
    public void calculateWeight() {
        final double a = tagModel.tagCount(source);
        final double b = tagModel.tagCount(target);
        final double c = this.commonTags.size();
        //Tanimoto Coefficient
        weight = c / (a+b-c);
    }

    /**
     * 
     * @param weight
     */
    public void setWeight(int weight) {
        this.weight = weight;
    }

    /**
     * 
     * @return
     */
    public AbstractInformationNode getSource() {
        return source;
    }

    /**
     * 
     * @return
     */
    public AbstractInformationNode getTarget() {
        return target;
    }

    /**
     * @return
     */
    public String getAssociationType() {
        return ASSOCIATION_NAME;
    }

    public double getWeight() {
        return weight;
    }
}
