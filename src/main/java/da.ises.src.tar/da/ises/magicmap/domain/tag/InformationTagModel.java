package da.ises.magicmap.domain.tag;

import da.ises.core.infoobject.Tag;
import da.ises.core.infoobject.Tagging;
import da.ises.magicmap.domain.node.InformationObjectNode;
import edu.uci.ics.jung.graph.event.GraphEvent;
import edu.uci.ics.jung.graph.event.GraphEventListener;
import edu.uci.ics.jung.graph.event.GraphEventType;
import edu.uci.ics.jung.graph.impl.BipartiteGraph;
import edu.uci.ics.jung.graph.impl.BipartiteVertex;
import static edu.uci.ics.jung.graph.impl.BipartiteGraph.*;
import net.sf.magicmap.client.utils.AbstractModel;
import org.bushe.swing.event.annotation.AnnotationProcessor;

import java.util.*;

/**
 *
 */
public class InformationTagModel extends AbstractModel implements TagModel{

    private final BipartiteGraph tagGraph = new BipartiteGraph();
    private final WeakHashMap<Tag, TagVertex> tagVertexMap = new WeakHashMap<Tag, TagVertex>();
    private final WeakHashMap<InformationObjectNode, NodeVertex> nodeVertexMap = new WeakHashMap<InformationObjectNode, NodeVertex>();
    private final ArrayList<TagModelListener> listeners = new ArrayList<TagModelListener>();
    
    public InformationTagModel() {
        AnnotationProcessor.process(this);
        tagGraph.addListener(new GraphEventListener() {
            public void vertexAdded(GraphEvent event) {
                BipartiteVertex v = (BipartiteVertex) event.getGraphElement();
                if (v instanceof TagVertex) {
                    fireTagAdded((TagVertex)v);
                }
            }

            public void vertexRemoved(GraphEvent event) {
                BipartiteVertex v = (BipartiteVertex) event.getGraphElement();
                if (v instanceof TagVertex) {
                    fireTagRemoved((TagVertex)v);
                }
            }

            public void edgeAdded(GraphEvent event) {
                fireTaggged(((TagEdge)event.getGraphElement()));
            }

            public void edgeRemoved(GraphEvent event) {
                fireTaggingRemoved((TagEdge)event.getGraphElement());
            }
        }, GraphEventType.ALL_SINGLE_EVENTS);

    }


    /**
     * @return
     */
    @SuppressWarnings({"unchecked"})
    public List<Tag> getTags() {
        synchronized (tagGraph){
            return (List<Tag>) ((tagGraph.numVertices() >0 ) ? new ArrayList<Tag>(tagGraph.getAllVertices(CLASSA)) : Collections.emptyList());
        }
    }

    public int tagCount(InformationObjectNode node){
        NodeVertex vertex = nodeVertexMap.get(node);
        return vertex != null ? vertex.degree() : 0;
    }

    public int nodeCount(Tag tag){
        TagVertex tagVertex = tagVertexMap.get(tag);
        return tagVertex != null ? tagVertex.degree() : 0;
    }


    /**
     * @param node
     * @return
     */
    public List<Taggings> getTaggings(InformationObjectNode node) {
        List<Taggings> taggingses;
        NodeVertex vertex = nodeVertexMap.get(node);
        if (vertex != null) {
            Map<Tag, Integer> tags = vertex.getTags();
            taggingses = new ArrayList<Taggings>(tags.size());
            for (Map.Entry<Tag,Integer> tag: tags.entrySet()){
                taggingses.add(new Taggings(tag.getKey(), node,tag.getValue()));
            }
        } else {
            taggingses = Collections.emptyList();
        }
        return taggingses;
    }

    /**
     * @param tag
     * @return
     */
    public List<Taggings> getTaggings(Tag tag) {
        List<Taggings> taggingses;
        TagVertex tagVertex = tagVertexMap.get(tag);
        if (tagVertex != null){
            Map<InformationObjectNode, Integer> map = tagVertex.getNodes();
            taggingses = new ArrayList<Taggings>(map.size());
            for (Map.Entry<InformationObjectNode, Integer> node: map.entrySet()){
                taggingses.add(new Taggings(tag, node.getKey(), node.getValue()));
            }
        }else {
            taggingses = Collections.emptyList();
        }
        return taggingses;
    }

    private void fireTaggingRemoved(TagEdge tagEdge) {
        
    }


    /**
     *
     * @param node
     * @param informationObjectAnnotation
     */
    public void addTag(InformationObjectNode node, Tagging informationObjectAnnotation){
        NodeVertex nodeVertex = nodeVertexMap.get(node);
        if (nodeVertex == null) {
            nodeVertex = new NodeVertex(node);
            nodeVertexMap.put(node, nodeVertex);
            tagGraph.addVertex(nodeVertex, CLASSB);
        }
        for (Map.Entry<Tag,Boolean> tag: informationObjectAnnotation.getTags().entrySet()) {
            TagVertex tagVertex = tagVertexMap.get(tag.getKey());
            if (tagVertex == null){
                tagVertex = new TagVertex(tag.getKey());
                tagVertexMap.put(tag.getKey(),  tagVertex);
                tagGraph.addVertex(tagVertex, CLASSA);
            }
            TagEdge edge = tagVertex.findEdge(nodeVertex);
            if (edge == null) {
                edge = new TagEdge(tagVertex, nodeVertex, tag.getValue(), informationObjectAnnotation.getAuthor());
                tagGraph.addBipartiteEdge(edge);
            } else {
                edge.addAuthor(tag.getValue(), informationObjectAnnotation.getAuthor());
                fireTagChanged(edge);
            }

        }

    }



    /**
     * 
     * @param node
     * @return
     */
    public Map<Tag,Integer> getTags(InformationObjectNode node) {
        NodeVertex vertex = this.nodeVertexMap.get(node);
        return vertex != null ? vertex.getTags() : new HashMap<Tag, Integer>();
    }

    private void fireTagRemoved(TagVertex tagVertex) {
        final TagEvent e = new TagEvent(this, tagVertex.getTag());
        for (TagModelListener l:getTagModelListeners()) {
            l.tagRemoved(e);
        }
    }
    private void fireTaggged(TagEdge tagEdge) {
        final TaggingEvent e = new TaggingEvent(this, tagEdge.getTag(), tagEdge.getNode(), tagEdge.isPositive());
        for (TagModelListener l:getTagModelListeners()){
            l.taggingAdded(e);        
        }
    }
    private void fireTagChanged(TagEdge tagEdge) {
        final TaggingEvent e = new TaggingEvent(this, tagEdge.getTag(), tagEdge.getNode(), tagEdge.isPositive());
        for (TagModelListener l:getTagModelListeners()){
            l.taggingAdded(e);
        }        
    }
    
    /**
     *
     * @param tag
     */
    private void fireTagAdded(TagVertex tag) {
        final TagEvent e = new TagEvent(this, tag.getTag());
        for (TagModelListener l:getTagModelListeners()) {
            l.tagAdded(e);
        }
    }

    /**
     *
     * @param tag
     * @return
     */
    @SuppressWarnings({"unchecked"})
    public Map<InformationObjectNode, Integer> getTaggedNodes(Tag tag) {
        TagVertex tagVertex = tagVertexMap.get(tag);
        return (Map<InformationObjectNode, Integer>) (tagVertex != null ? tagVertex.getNodes() : Collections.emptyMap());
    }

    /**
     *
     * @param tags
     * @return
     */
    public Collection<InformationObjectNode> getTaggedNodes(Iterable<Tag> tags) {
        return Collections.emptyList();

    }

    public void addTagModelListener(TagModelListener l) {
        synchronized (this.listeners) {
            listeners.add(l);
        }
    }
    public void removeTagModelListener(TagModelListener l) {
        synchronized (this.listeners) {
            listeners.remove(l);
        }
    }
    public TagModelListener[] getTagModelListeners() {
        synchronized (this.listeners) {
            return listeners.toArray(new TagModelListener[listeners.size()]);
        }
    }

}
