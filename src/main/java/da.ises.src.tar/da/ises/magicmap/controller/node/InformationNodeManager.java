package da.ises.magicmap.controller.node;

import da.ises.core.infoobject.ObjectName;
import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.InformationObjectFactory;
import da.ises.core.domain.infoobject.Position;
import da.ises.core.domain.infoobject.PositionType;
import da.ises.core.domain.repository.InformationObjectPosts;
import da.ises.core.domain.repository.InformationObjectRepository;
import da.ises.core.util.Digest;
import da.ises.magicmap.domain.node.AbstractInformationNode;
import da.ises.magicmap.domain.node.InformationNodeModel;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.domain.node.PlacemarkNode;
import da.ises.magicmap.ui.log.LogEvent;
import static net.sf.magicmap.client.controller.Controller.getInstance;
import net.sf.magicmap.client.controller.ServerManager;
import net.sf.magicmap.client.gui.utils.CallbackHandler;
import net.sf.magicmap.client.interfaces.FetchPositionsCallback;
import net.sf.magicmap.client.model.node.MapNode;
import net.sf.magicmap.client.model.node.Node;
import net.sf.magicmap.client.utils.Settings;
import net.sf.magicmap.server.dto.AttributesDTO;
import net.sf.magicmap.server.dto.PositionDTO;
import org.bushe.swing.event.EventBus;
import org.bushe.swing.event.annotation.AnnotationProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 *
 *
 */
public class InformationNodeManager implements InformationObjectFactory {
    // todo
    private final InformationNodeModel nodeModel;
    private static final Logger log = LoggerFactory.getLogger(InformationNodeManager.class);
    private InformationObjectRepository repository;
    private NodeLoader nodeLoader;

    private class NodeLoader implements Runnable{
        protected boolean paused;
        protected boolean terminated;
        public void run() {
            while (!terminated) {
                if (!paused && nodeModel.getCurrentMap() != null) {
                    loadPlacemarks();
                }
                try {
                    Thread.sleep(1000 * 10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };


    public InformationNodeManager(InformationNodeModel nodeModel, InformationObjectRepository repository) {
        this.nodeModel = nodeModel;
        this.repository = repository;
        AnnotationProcessor.process(this);

    }

    /**
     *
     * @return
     */
    public InformationPositionNodeBuilder getAnnotationNodeBuilder() {
        return new InformationPositionNodeBuilder(repository, nodeModel);
    }




    public InformationObject createInformationObject(String uri) {
        InformationObjectNode node = nodeModel.findInformationNode(uri);
        InformationObject  info = node != null ? node.getInformationObject() : repository.getInformation(uri);
        return info == null ? new InformationObject(uri) : info;
    }

    /**
     *
     * @param node the node to load.
     * @param depth the depth. to load.
     * @param fliter a filter. todo
     */
    public void explodeNode(Node node, int depth, Object... fliter) {
        if (node.isPhysical()) {
            List<InformationObjectPosts> objectList = repository.findByPosition(positionFromNode(node));
            addInformations(objectList);
        } else if (node instanceof AbstractInformationNode){
            AbstractInformationNode infoNode = (AbstractInformationNode) node;
            InformationObject informationObject = infoNode.getInformationObject();

        }
        
        if (depth > 0 && node.getNodeContainer() != null){
            for (Node child: node.getNodeContainer()){
                explodeNode(child, depth-1,fliter);
            }
        }
    }
    static Position positionFromNode(Node node){
        ObjectName name = ObjectName.positionName(node.getName(), node.getModel().getServerID());
        return new Position(name, PositionType.positionType(node.getClass().getSimpleName()));
    }

    /**
     * 
     * @param uri
     * @return
     */
    public InformationObjectPosts getPosts(String uri){
        return repository.get(uri);
    }

    /**
     * Add or refresh it
     * @param objectList
     */
    private void addInformations(List<InformationObjectPosts> objectList) {
        for (InformationObjectPosts post:objectList){
            InformationObject object = post.getInfoobject();
            InformationObjectNode infoNode = nodeModel.findInformationNode(object.getId());
            if (infoNode == null) {
                infoNode = new InformationObjectNode(nodeModel, object);
                nodeModel.addNode(infoNode);
            }
            // TODO HEUTE!
            /*for (Tagging tag: TagAnnotationTransformer.transform(post.getTags().values())){
                infoNode.addTags(tag);
            }
            for (ObjectNodeLink position: PositionAnnotationTransformer.transform(nodeModel, post.getPositions().values())){
                if (position.getPositionNode() != null){
                    // Node may be no longer on map!
                    infoNode.addPosition(position);
                }
            }   */

        }
    }

  

    /**
     *
     * @param value
     * @param x
     * @param y
     * @param z
     * @return
     */
    public void createPlacemark(String value, final int x, final int y, final int z) {
        AttributesDTO attributes = new AttributesDTO();
        attributes.setKeys(new String[]{"type", "creator"});
        attributes.setValues(new String[]{"placemark", Settings.getClientName()});

        String nodeId = "placemark:" + Digest.sha1(
                Settings.getClientName(),
                value,
                nodeModel.getCurrentMap().getMapInfo().imageURL, (""+ System.currentTimeMillis()));

        final PlacemarkNode node = new PlacemarkNode(nodeModel);
        node.setDisplayName(value);
        node.setName(nodeId);
        /**
         *
         */
        getServerManager().createOrUpdatePosition("placemark", x,y,z,null,nodeId,value,true,attributes,new CallbackHandler(){
            @Override
            public void positionCreated() {
                node.setPositionSilent(x,y,z);
                node.setFix(true);
                nodeModel.addNode(node);
            }

            @Override
            public void positionCreationError(Exception e) {
                super.positionCreationError(e);
            }
        });
    }

    private ServerManager getServerManager() {
        return getInstance().getServerManager();
    }

    public void mapLoaded(MapNode currentMap) {
                
        if (nodeLoader == null) {
            nodeLoader = new NodeLoader();
            Thread t = new Thread(nodeLoader);
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            t.start();
        }
    }

    protected void loadPlacemarks() {
        final String mapName = nodeModel.getCurrentMap().getMapInfo().name;
        AttributesDTO attributes = new AttributesDTO();
        attributes.setKeys(new String[]{"type"});
        attributes.setValues(new String[]{"placemark"});

        getServerManager().getPositionsWithKeysAndValuesForMap(new String[]{"placemark"}, mapName, attributes, new FetchPositionsCallback() {
            public void positionsFetched(PositionDTO[] positionDTOs) {
                log.debug("Loaded placenmarks {}", positionDTOs);
                if (positionDTOs == null) return;
                for (PositionDTO positionDTO : positionDTOs) {
                    String nodeId = positionDTO.getIdentifier();
                    PlacemarkNode node = (PlacemarkNode) nodeModel.findNode(nodeId);
                    if (node == null) {
                        node = new PlacemarkNode(nodeModel);
                        node.setId(positionDTO.getId());
                        node.setDisplayName(positionDTO.getDisplayName());
                        node.setName(nodeId);
                        node.setPositionSilent(positionDTO.getPosX(), positionDTO.getPosY(), positionDTO.getPosZ());
                        nodeModel.addNode(node);
                    } else {
                        node.setPositionSilent(positionDTO.getPosX(), positionDTO.getPosY(), positionDTO.getPosZ());
                        node.setDisplayName(positionDTO.getDisplayName());
                    }

                }
            }

            public void positionFetchError(Exception e) {
                log.warn("Exception loading placemarks {}", e);
                EventBus.publish(new LogEvent("Fehler beim Laden der Placemarks!", LogEvent.Type.ERROR));
            }
        });
    }

    public InformationNodeModel getNodeModel(){
        return nodeModel;
    }
}
