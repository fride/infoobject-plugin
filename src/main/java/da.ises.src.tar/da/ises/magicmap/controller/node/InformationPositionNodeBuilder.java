package da.ises.magicmap.controller.node;

import da.ises.core.domain.entity.Description;
import da.ises.core.domain.entity.Title;
import da.ises.core.domain.infoobject.*;
import da.ises.core.domain.repository.InformationObjectRepository;
import da.ises.core.infoobject.Tag;
import da.ises.core.infoobject.ObjectName;
import da.ises.core.domain.user.Agent;
import da.ises.magicmap.domain.node.InformationNodeModel;
import da.ises.magicmap.domain.node.InformationObjectNode;
import net.sf.magicmap.client.model.node.Node;

import java.util.HashMap;
import java.util.Map;

/**
 *
 */
public class InformationPositionNodeBuilder {
    private Title title;
    private Title positionTitle;
    private Description description;
    private Description positionDescription;

    private Position position;
    private Map<Tag, Boolean> positionTags = new HashMap<Tag, Boolean>();
    private Map<Tag, Boolean> infoTags = new HashMap<Tag, Boolean>();
    private InformationObject infoobject;
    private final InformationNodeModel nodeModel;
    private final InformationObjectRepository repos;
    private Agent agent;
    /**
     *
     * @param repos
     * @param nodeModel
     */
    public InformationPositionNodeBuilder(InformationObjectRepository repos, InformationNodeModel nodeModel) {
        this.repos = repos;
        this.nodeModel = nodeModel;
    }

    public InformationPositionNodeBuilder withTitle(String title) {
        this.title = Title.title(title);
        return this;
    }

    public InformationPositionNodeBuilder withTitleForPosition(String title) {
        this.positionTitle = Title.title(title);
        return this;
    }
    public InformationPositionNodeBuilder from(Agent agent) {
        this.agent = agent;
        return this;
    }
    public InformationPositionNodeBuilder withDescription(String description) {
        this.description = Description.description(description);
        return this;
    }

    public InformationPositionNodeBuilder withDescriptionForPosition(String description) {
        this.positionDescription = Description.description(description);
        return this;
    }
    
    public InformationPositionNodeBuilder withPosition(Position position) {
        this.position = position;
        return this;
    }

    public InformationPositionNodeBuilder withPosition(Node node) {
        this.position = new Position(
                ObjectName.positionName(node.getName(),node.getModel().getServerID()),
                PositionType.positionType(node.getClass().getSimpleName()));
        return this;
    }

    public InformationPositionNodeBuilder withPositionTag(String tag, boolean positive) {
        this.positionTags.put(new Tag(tag), positive);
        return this;
    }

    public InformationPositionNodeBuilder withPositionTag(String tag){
        return withPositionTag(tag,true);
    }


    public InformationPositionNodeBuilder withInformationTag(String tag, boolean positive) {
        this.infoTags.put(new Tag(tag), positive);
        return this;
    }

    public InformationPositionNodeBuilder withInformationTag(String tag){
        return withInformationTag(tag,true);
    }


    public InformationPositionNodeBuilder withInformationObject(InformationObject info) {
        this.infoobject = info;
        return this;
    }
    /**
     *
     * @return
     */
    public InformationObjectNode getNode() {
        if (position == null) throw new IllegalArgumentException("Position missing");
        if (infoobject == null) throw new IllegalArgumentException("Info missing");
        if (repos.getInformation(infoobject.getId()) == null){
            repos.set(infoobject);
        }
        //this.agent = PluginApplication.get().getUser();
        PositionAnnotation positionAnnotation = new PositionAnnotation(infoobject, agent);
        positionAnnotation.setNodeName(this.position.getPositionName().getName());
        positionAnnotation.setNodeServer(this.position.getPositionName().getPositionServer());
        positionAnnotation.setTitle(positionTitle);
        positionAnnotation.setTags(positionTags);

        TagAnnotation tagAnnotation = new TagAnnotation(infoobject, title, description, agent);
        tagAnnotation.setTags(infoTags);
        
        this.repos.set(infoobject);
        this.repos.set(infoobject.getId(), positionAnnotation);
        this.repos.set(infoobject.getId(), tagAnnotation);
        
        InformationObjectNode infoNode = nodeModel.findInformationNode(infoobject.getId());
        if (infoNode == null) {
            infoNode = new InformationObjectNode(nodeModel, infoobject);
            nodeModel.addNode(infoNode);
        }
        // TODO Heute!
        //infoNode.addTags(new TagAnnotationTransformer().transform(tagAnnotation));
        //infoNode.addPosition(new PositionAnnotationTransformer(nodeModel).transform(positionAnnotation));
        return infoNode;
    }

}
