package da.ises.magicmap.controller.association;

import da.ises.magicmap.domain.association.*;
import da.ises.magicmap.domain.node.AbstractInformationNode;
import da.ises.magicmap.domain.node.InformationObjectNode;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Vertex;
import net.sf.magicmap.client.model.node.IMagicEdge;
import net.sf.magicmap.client.model.node.MapNode;
import net.sf.magicmap.client.model.node.Node;
import org.apache.commons.collections15.CollectionUtils;
import org.apache.commons.collections15.functors.NotPredicate;

import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * The Association handles the implicit and explicit associations
 * between informaion objects and information objects - positions.
 *
 */
public class AssociationManager {
    private AssociationGraph associationGraph;
    private LayoutThreadManager layoutThreadManager;
    private WeakHashMap<InformationObjectNode, Boolean> explodedMap = new WeakHashMap<InformationObjectNode, Boolean>();

    private HashMap<String, AssociationFilter> filterMap = new HashMap<String, AssociationFilter>();


    private AssociationEdgeFilter filters = new AssociationEdgeFilter();
    private HashSet<AssociationEdge> filteredEdges = new HashSet<AssociationEdge>();
    

     /**
     *
     * @param filter
     */
    public void addFilter(AssociationFilter filter){
        this.filters.add(filter);
        filterEdges();
    }

    private void filterEdges() {
        this.layoutThreadManager.suspend();
        try {
            Set<AssociationEdge> edgeSet = this.associationGraph.getAssociationEdges();
            List<AssociationEdge> newFilteredEgdes = CollectionUtils.select(edgeSet, new NotPredicate<AssociationEdge>(filters), new ArrayList<AssociationEdge>());
            for (AssociationEdge edge: filteredEdges){
                //associationGraph.addAssociation(edge);
            }
            for (AssociationEdge filteredEdge:newFilteredEgdes){
                IMagicEdge edge = filteredEdge.getEdge();
                this.associationGraph.removeEdge(edge.getSourceNode(), edge.getTargetNode());
            }

        }
        finally{
            this.layoutThreadManager.unsupend();
        }

    }

    public void filter(){

        Set<Vertex> vertices = associationGraph.getLayout().getVisibleVertices();
        Set<Edge> edges = associationGraph.getLayout().getVisibleEdges();
        try {
            layoutThreadManager.suspend();
            associationGraph.filter();
        } finally {
            layoutThreadManager.unsupend();
        }
        // Notify that this edges are new.
        //Collection<Edge> newEdges = CollectionUtils.subtract(getVisibleEdges(), edges);
    }

    /**
     * @param associationGraph the graph to put the associations in
     */
    public AssociationManager(final AssociationGraph associationGraph) {
        this.associationGraph = associationGraph;
        layoutThreadManager = new LayoutThreadManager(associationGraph.getLayout());
    }
    

    /**
     *
     * @param node
     */
    public void updateNodePosition(Node node) {
        layoutThreadManager.suspend();
        associationGraph.updatePosition(node);
        layoutThreadManager.unsupend();
    }


    /**
     *
     * @param node
     */
    public void addInformationNodeObject(InformationObjectNode node) {
        //
    }

    public void start() {
        this.layoutThreadManager.start();
    }

    public void stop() {
        this.layoutThreadManager.stop();
    }



    public AssociationEdge getAssociationEdge(InformationObjectNode n1, InformationObjectNode n2){
        return this.associationGraph.getAssociationEdge(n1,n2);        
    }

    /**
     * Adds an association between the two given nodes. Will create a new edge if
     * none exists. Otherwise it will add an association to the existing assocition edge.
     *
     * @param n1 first node
     * @param n2 second node.
     * @param builder association builder.
     * @return
     */
    public Association addAssociation(Node n1, Node n2,AssociationBuilder builder) {
        try {
            this.layoutThreadManager.suspend();
            builder.setAssoiatonGraph(associationGraph);
            da.ises.magicmap.domain.association.Association association = builder.createAssociation();
            this.associationGraph.addAssociation(n1,n2, association);
            this.associationGraph.getLayout().update();
            return association;
        } catch (Exception ex){
            throw new RuntimeException(ex);            
        }   finally {
            this.associationGraph.getLayout().update();
            this.layoutThreadManager.unsupend();
        }
    }
    /**
     *
     * @param node
     * @return
     */
    public boolean isExploded(InformationObjectNode node) {
        return Boolean.TRUE.equals(explodedMap.get(node));
    }

    /**
     *
     * @param node
     */
    public void explodeNode(InformationObjectNode node) {
        if (!isExploded(node)){
            layoutThreadManager.suspend();

            this.explodedMap.put(node, Boolean.TRUE);
            //Collection<InformationPositionNode> positions = node.getChildren();
            Set<? extends IMagicEdge> iMagicEdges = associationGraph.getEdges(node);

            for (IMagicEdge edge:iMagicEdges){
                associationGraph.removeEdge(edge.getSourceNode(), edge.getTargetNode());
            }
           /* for (InformationPositionNode position:positions) {
                System.err.printf("%s -> $s und $s", position.getDisplayName(), position.getParentNode().getDisplayName(), position.getPosition().getDisplayName());
                associationGraph.addInfopositionEdge(position, position.getParentNode());
                associationGraph.addPositionEdge(position.getPosition(), position);
            }*/
            associationGraph.getLayout().update();
            layoutThreadManager.unsupend();
        }
    }

    /**
     *
     * @param node
     */
    public void implodeNode(InformationObjectNode node) {
        if (isExploded(node)) {
            this.explodedMap.put(node, Boolean.FALSE);
            // TODO
        }
    }

    /**
     *
     * @param map
     */
    public void setCurrentMap(MapNode map) {
        this.layoutThreadManager.suspend();
        this.associationGraph.getLayout().resize(new Dimension(map.getMapInfo().width,map.getMapInfo().height));
        this.layoutThreadManager.unsupend();
    }

    /**
     * 
     * @param abstractInformationNode
     */
    public void removeNode(AbstractInformationNode abstractInformationNode) {
        try {
            this.layoutThreadManager.suspend();
            Set<? extends IMagicEdge> edges = this.associationGraph.getEdges(abstractInformationNode);
            for (IMagicEdge edge: edges) {                
                associationGraph.removeEdge(edge.getSourceNode(), edge.getTargetNode());
            }
            associationGraph.removeNode(abstractInformationNode);
        } finally {
            this.layoutThreadManager.unsupend();
        }
    }

    public void addPosition(InformationObjectNode source, Node annotatedNode) {
         try {
            this.layoutThreadManager.suspend();
            this.associationGraph.addPosition(source,annotatedNode);
            this.associationGraph.getLayout().update();
        } catch (Exception ex){
            throw new RuntimeException(ex);
        }   finally {
            this.associationGraph.getLayout().update();
            this.layoutThreadManager.unsupend();
        }
    }
}
