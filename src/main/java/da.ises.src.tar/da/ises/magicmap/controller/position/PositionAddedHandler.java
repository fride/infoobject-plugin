package da.ises.magicmap.controller.position;

import net.sf.magicmap.client.interfaces.NodeModelListener;
import net.sf.magicmap.client.model.node.Node;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.domain.node.AbstractInformationNode;
import da.ises.magicmap.domain.node.ObjectNodeLink;
import da.ises.magicmap.controller.association.AssociationManager;

/**
 * Check Node Add and change events...
 * 
 */
public class PositionAddedHandler implements NodeModelListener {
    private AssociationManager manager;

    public PositionAddedHandler(AssociationManager manager) {
        this.manager = manager;
    }

    public void nodeAddedEvent(Node node) {
        if (node instanceof InformationObjectNode){
            manager.addInformationNodeObject((InformationObjectNode) node);
            InformationObjectNode info = (InformationObjectNode) node;
            Iterable<ObjectNodeLink> iterable = info.getPositions();
            for (ObjectNodeLink position:iterable) {
                addPosition(info, position);
            }
        }
    }

    /**
     * 
     * @param node
     * @param i
     * @param o
     */
    public void nodeUpdatedEvent(Node node, int i, Object o) {
        if (node instanceof AbstractInformationNode) {
            switch (i) {
                case InformationObjectNode.POSITION_ADDED:
                    addPosition((InformationObjectNode) node, (ObjectNodeLink)o);
                    break;
                case InformationObjectNode.TAGS_ADDED:
                    break;
                default:
                    manager.updateNodePosition(node);
                    break;
            }
        }
        else {
            manager.updateNodePosition(node);
        }
    }

    private void addPosition(final InformationObjectNode source, final ObjectNodeLink target) {
        manager.addPosition(source, target.getPositionNode());
    }

    public void nodeRemovedEvent(Node node) {
        if (node instanceof AbstractInformationNode) {
            manager.removeNode((AbstractInformationNode) node);
        }
    }
}
