package da.ises.magicmap.controller.tag;

import da.ises.magicmap.domain.association.Association;
import da.ises.magicmap.domain.association.AssociationBuilder;
import da.ises.magicmap.domain.association.AssociationEdge;
import da.ises.magicmap.domain.association.AssociationGraph;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.domain.tag.*;
import org.apache.commons.collections15.CollectionUtils;
import org.apache.commons.collections15.Predicate;
import org.apache.commons.collections15.functors.AndPredicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;

/**
 * <p>
 * Class TagUpdateHandler ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 20.07.2008
 *         Time: 15:18:26
 */
// TODO Filter!
public class TagAssociationHandler implements TagModelListener{

    private static final Logger log = LoggerFactory.getLogger("tag");
    private final Object tagChangeMutex = new Object();
    private int minCommonTags;
    private Set<String> filteredTags = new HashSet<String>();
    private final AssociationGraph associationGraph;

    private final Predicate<Taggings> minCommonTagsPredicate = new Predicate<Taggings>() {
        public boolean evaluate(Taggings taggings) {
            return minCommonTags == 0 || taggings.getWeight() >= minCommonTags;
        }
    };
    private final Predicate<Taggings> filteredTagsPredicate = new Predicate<Taggings>() {
        public boolean evaluate(Taggings taggings) {
            return filteredTags.size() == 0 || filteredTags.contains(taggings.getTag().getNormalizedValue());
        }
    };


    public TagAssociationHandler(AssociationGraph associationGraph) {
        this.associationGraph = associationGraph;
    }

 

    /**
     * @param tag
     */
    public void tagAdded(TagEvent tag) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @param tag
     */
    public void tagRemoved(TagEvent tag) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @param event
     */
    public void taggingAdded(TaggingEvent event) {

        final TagModel tagModel = event.getSource();
        InformationObjectNode source = event.getNode();
        Iterable<Taggings> list = CollectionUtils.select(tagModel.getTaggings(event.getTag()), new AndPredicate<Taggings>(filteredTagsPredicate, minCommonTagsPredicate));
        for (Taggings aList : list) {
            InformationObjectNode target = aList.getNode();
            AssociationEdge edge = associationGraph.getAssociationEdge(source, target);
            final double weight = tagModel.tagCount(source);

            if (edge == null){
                final TagAssociation association = new TagAssociation(source, target, tagModel);
                association.add(event.getTag());
                associationGraph.addAssociation(source,target, association);
                association.calculateWeight();
            }
            else {
                final TagAssociation tagAssociation = (TagAssociation) edge.get(TagAssociation.ASSOCIATION_NAME);
                tagAssociation.add(event.getTag());
                tagAssociation.calculateWeight();

            }
        }

    }

    /**
     * @param tagging
     */
    public void taggingRemoved(TaggingEvent tagging) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    static class TagAnnotationBuidler extends AssociationBuilder{
        private InformationObjectNode source;
        private InformationObjectNode target;
        private InformationTagModel model;

        TagAnnotationBuidler(InformationObjectNode source, InformationObjectNode target, InformationTagModel model) {
            this.source = source;
            this.target = target;
            this.model = model;
        }

        /**
         * @return
         */
        public Association createAssociation() {
            return new TagAssociation(source, target, model);
        }
    }
}
