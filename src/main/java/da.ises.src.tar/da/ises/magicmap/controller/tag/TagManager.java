package da.ises.magicmap.controller.tag;

import da.ises.magicmap.domain.node.InformationNodeModel;
import da.ises.core.infoobject.Tagging;
import da.ises.magicmap.domain.node.InformationObjectNode;
import da.ises.magicmap.domain.node.AbstractInformationNode;
import da.ises.magicmap.domain.tag.InformationTagModel;
import da.ises.magicmap.controller.association.AssociationManager;
import net.sf.magicmap.client.interfaces.NodeModelListener;
import net.sf.magicmap.client.model.node.Node;

/**
 * <p>
 * Class TagController ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 17.07.2008
 *         Time: 21:24:23
 */
public class TagManager {
    private InformationNodeModel nodeModel;
    private InformationTagModel tagModel;
    private final AssociationManager associationManager;
    private TagAssociationHandler tagAssociationHandler;
    

    /**
     *
     * @param nodeModel
     * @param tagModel
     */
    public TagManager(final InformationNodeModel nodeModel, final InformationTagModel tagModel, AssociationManager associationManager) {
        this.nodeModel = nodeModel;
        this.tagModel = tagModel;
        this.associationManager = associationManager;
        nodeModel.addNodeModelListener(new NodeModelListener() {
            public void nodeAddedEvent(Node node) {
                if (node instanceof InformationObjectNode) {
                    InformationObjectNode info = (InformationObjectNode) node;
                    for (Tagging annotation:info.getTagAnnotation()){
                        addTags(info, annotation);
                    }
                }
            }

            public void nodeUpdatedEvent(Node node, int i, Object o) {
                if (node instanceof AbstractInformationNode) {
                    switch (i) {
                        case InformationObjectNode.TAGS_ADDED:
                            addTags((InformationObjectNode)node, (Tagging)o);
                            break;
                    }
                }
            }

            public void nodeRemovedEvent(Node node) {

            }
        });

    }

    /**
     * 
     * @param node
     * @param tags
     */
    private void addTags(final InformationObjectNode node, Tagging tags) {
        tagModel.addTag(node,tags);
    }


}
