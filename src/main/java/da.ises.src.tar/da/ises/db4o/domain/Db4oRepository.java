package da.ises.db4o.domain;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import da.ises.core.domain.entity.Version;
import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.Position;
import da.ises.core.domain.infoobject.PositionAnnotation;
import da.ises.core.domain.infoobject.TagAnnotation;
import da.ises.core.domain.repository.InformationObjectPosts;
import da.ises.core.domain.repository.InformationObjectRepository;
import da.ises.core.infoobject.Tag;
import da.ises.core.domain.user.Agent;
import da.ises.magicmap.application.PluginApplication;
import org.apache.commons.collections15.CollectionUtils;

import java.io.File;
import java.util.*;

/**
 * <p>
 * Class Db4oRepository ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 26.07.2008
 *         Time: 19:13:43
 */
public class Db4oRepository implements InformationObjectRepository {

    private final ObjectContainer objectContainer;
    private Agent agent;

    public Db4oRepository(ObjectContainer objectContainer) {
        this.objectContainer = objectContainer;
        init(objectContainer);

    }

    private void init(ObjectContainer objectContainer) {
        ObjectSet<Object> objectSet = objectContainer.get(TagList.class);
        if (objectSet.size() == 0){
            objectContainer.set(new TagList());
        }
    }

    public Db4oRepository() {
        this(Db4o.openFile(getDataBaseDir()));
    }

    static String getDataBaseDir(){
        File home = PluginApplication.get().getHome("db");
        if (!home.exists()) {
            //    if(!home.mkdirs()) throw new RuntimeException("Can't create dir " + home.getAbsolutePath());
        }
        Db4o.configure().objectClass(InformationObjectPosts.class)
                .cascadeOnUpdate(true);
        return home.getAbsolutePath();
    }


    public Agent getAgent() {
        return agent;
    }

    public void setAgent(Agent agent) {
        this.agent = agent;
    }


    /**
     * @param uri
     * @return
     */
    public InformationObjectPosts get(final String uri) {


        ObjectSet<InformationObjectPosts> postsSet = objectContainer.query(new Predicate<InformationObjectPosts>() {
            public boolean match(InformationObjectPosts o) {
                return o.getInfoobject().getId().equals(uri);
            }
        });
        InformationObjectPosts posts = postsSet.size() == 1 ? postsSet.get(0) : new InformationObjectPosts();
        //
        return posts;
    }


    /**
     * Create or saves a new information object.
     *
     * @param object the object to update or save
     * @return
     */
    public InformationObject set(InformationObject object) {
        InformationObjectPosts post = get(object.getId());

        if (post.isEmpty()) {
            post.setInfoobject(object);
            object.setVersion(Version.now());
            objectContainer.set(post);
        } else {
            InformationObject saved = post.getInfoobject();
            saved.setSize(object.getSize());
            saved.setTitle(object.getTitle());
            saved.setDescription(object.getDescription());
            saved.setMimeType(object.getMimeType());
            saved.setFacetTypes(object.getFacetTypes());
            saved.setVersion(saved.getVersion().next());
            objectContainer.set(post);
        }
        return object;
    }



    public InformationObject getInformation(final String uri){
        ObjectSet<InformationObject> objectSet = objectContainer.query( new Predicate<InformationObject>() {
            public boolean match(InformationObject informationObject) {
                return uri.equals(informationObject.getId());
            }
        });

        return objectSet.size() > 0 ? objectSet.get(0) : null;
    }

    /**
     * @param position
     * @return
     */
    public PositionAnnotation set(final String uri, final PositionAnnotation position) {
        InformationObjectPosts objectPosts = get(uri);
        if (objectPosts == null) throw new IllegalArgumentException("Info not found " + uri);
        
        PositionAnnotation savedPosition = null;//objectPosts.getPositions().get(new Pair<Agent, ObjectName>(position.getCreator(), position.getPosition().getPositionName()));
        if (savedPosition == null) {
            savedPosition = position;
            savedPosition.setInformation(objectPosts.getInfoobject());
            //objectPosts.getPositions().put(new Pair<Agent, ObjectName>(position.getCreator(), position.getPosition().getPositionName()),position);
        } else {
            savedPosition.setTags(position.getTags());
            savedPosition.setTitle(position.getTitle());
            savedPosition.setDescription(position.getDescription());
        }
        objectContainer.set(objectPosts);
        addTags(position.getTags(), position.getCreator());
        return position;
    }




    /**
     * @param position
     * @return
     */
    public boolean remove(PositionAnnotation position) {
        ObjectSet<Object> objectSet = objectContainer.get(position);
        if (objectSet.size() == 1) {
            this.objectContainer.delete(objectSet.get(0));
        }
        return objectSet.size() == 1;
    }

    /**
     * @param tagging
     * @return
     */
    public TagAnnotation set(String uri, TagAnnotation tagging) {
        InformationObjectPosts objectPosts = get(uri);
        if (objectPosts == null) throw new IllegalArgumentException("Info not found " + uri);

        TagAnnotation saved = objectPosts.getTags().get(tagging.getCreator());
        if (saved == null) {
            saved = tagging;
            objectPosts.getTags().put(saved.getCreator(), saved);
        } else {
            saved.setTags(tagging.getTags());
            saved.setTitle(tagging.getTitle());
            saved.setDescription(tagging.getDescription());
        }
        objectContainer.set(objectPosts);
        addTags(tagging.getTags(), tagging.getCreator());
        return saved;
    }

    public boolean remove(TagAnnotation tags) {
        ObjectSet<Object> found = objectContainer.get(tags);
        if (found.size() == 1) {
            objectContainer.delete(found.get(0));
        }
        return found.size() == 1;
    }

    /**
     * @return
     */
    public List<InformationObject> list() {
        return new ArrayList<InformationObject>(objectContainer.<InformationObject>query(InformationObject.class));
    }

    /**
     * @param tags
     * @return
     */
    public List<InformationObjectPosts> findByTags(final Collection<String> tags) {
        ObjectSet<InformationObjectPosts> foundPosts = objectContainer.query(new Predicate<InformationObjectPosts>() {
            public boolean match(InformationObjectPosts o) {
                Collection<TagAnnotation> collection = o.getTags().values();
                for (TagAnnotation tagging : collection) {
                    if (CollectionUtils.intersection(tagging.getPositiveTags(), tags).size() > 0) return true;
                }
                return false;
            }
        });
        return foundPosts.size() > 0 ? new ArrayList<InformationObjectPosts>(foundPosts)  : Collections.<InformationObjectPosts>emptyList();
    }

    /**
     * @param position
     * @return
     */
    public List<InformationObjectPosts> findByPosition(final Position position) {
        ObjectSet<InformationObjectPosts> objectPosts = objectContainer.query(new Predicate<InformationObjectPosts>() {
            public boolean match(InformationObjectPosts o) {
                Collection<PositionAnnotation> positions = o.getPositions().values();
                for (PositionAnnotation annotation:positions) {
                    //if (annotation.getPosition().equals(position)) return true;
                }
                System.err.println("Nix d" + positions) ;
                return false;
            }
        });
        return new ArrayList<InformationObjectPosts>(objectPosts);
    }

    /**
     * @return
     */
    public List<Tag> loadTags() {
        ObjectSet<Object> tagListSet = objectContainer.get(TagList.class);
        return new ArrayList<Tag>(((TagList)tagListSet.get(0)).getTags());
    }

    private TagList getTagList() {
        ObjectSet<Object> tagListSet = objectContainer.get(TagList.class);
        return (TagList)tagListSet.get(0);
    }
    private void addTags(Map<Tag, Boolean> tags, Agent creator) {
        TagList list = getTagList();
        list.getTags().addAll(tags.keySet());
        list.getUserTags().putAll(creator,tags.keySet());
        objectContainer.set(list);
    }
}
