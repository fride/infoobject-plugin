package da.ises.db4o.domain;

import da.ises.core.infoobject.Tag;
import da.ises.core.domain.user.Agent;

import java.util.*;

import org.apache.commons.collections15.MultiMap;
import org.apache.commons.collections15.multimap.MultiHashMap;

/**
 * <p>
 * Class TagList ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 27.07.2008
 *         Time: 16:08:23
 */
public class TagList {
    private final Set<Tag> tags = new HashSet<Tag>();
    private final MultiMap<Agent, Tag> userTags = new MultiHashMap<Agent, Tag>();
    
    public Set<Tag> getTags() {
        return tags;
    }

    public MultiMap<Agent, Tag> getUserTags() {
        return userTags;
    }
}
