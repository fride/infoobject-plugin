package da.ises.client;

import da.ises.core.domain.user.Agent;

/**
 *
 */
public class ClientSession {
    private Agent agent;
    
}
