package da.ises.util.preview;

import org.antlr.stringtemplate.StringTemplate;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * Class PreviewService ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 28.07.2008
 *         Time: 15:48:02
 */
public class PreviewService {


    private StringTemplate previewTempl = new StringTemplate("http://images.websnapr.com/?size=T&key=key&url=$URL$");
    private Map<String, Image> cache = new HashMap<String, Image>();
    /**
     * 
     * @param uri
     * @return
     */
    public Image getPreview(String uri) throws IOException {
        Image image = cache.get(uri);
        if (image == null){
            previewTempl.reset();
            previewTempl.setAttribute("URL", uri);
            System.out.println("previewTempl = " + previewTempl.toString());
            URL url = new URL(previewTempl.toString());
            URLConnection urlConnection = url.openConnection();
            System.out.println("urlConnection = " + urlConnection.getContentType());
            image = ImageIO.read(urlConnection.getInputStream());
        }
        if (image != null){
            cache.put(uri,image);
        }
        return image;
    }

    public void clear(String uri){
        cache.remove(uri);
    }

    public static void main(String[] args) {
        final PreviewService service = new PreviewService();
        final JPanel p = new JPanel(new BorderLayout());
        final JLabel l = new JLabel();
        final JTextField f = new JTextField();
        final JButton load = new JButton();
        KeyStroke ks = KeyStroke.getKeyStroke(KeyEvent.VK_L,KeyEvent.META_MASK);//, Event.CTRL_MASK);

        load.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                System.out.println("event = " + event);
                ImageIcon icon = null;
                try {
                    icon = new ImageIcon(service.getPreview(f.getText()));
                } catch (IOException e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
                l.setIcon(icon);
            }
        });
        p.add(f,BorderLayout.NORTH);
        p.add(l,BorderLayout.CENTER);
        p.add(load,BorderLayout.SOUTH);
        JFrame fr = new JFrame();
        fr.getContentPane().add(p);
        fr.pack();
        fr.setVisible(true);

    }
}
