package da.ises.util;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: Jul 13, 2008
 * Time: 6:56:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class ModelExporter {
}
