package da.ises.server;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: 15.06.2008
 * Time: 22:19:07
 * To change this template use File | Settings | File Templates.
 */
public class StorageServer {
}
