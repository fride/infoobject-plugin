package da.ises.json.client;

/**
 * TOdo as fast as possible.
 */
public class JsonInformationPositionSpaceImpl {
}
