package da.ises.html.base.ui;

import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.InformationObjectFactory;
import da.ises.html.base.extractor.HtmlExtractor;
import da.ises.magicmap.ui.extractor.ExtractorUI;

import javax.swing.*;

import net.sf.magicmap.client.utils.DocumentAdapter;
import net.sf.magicmap.client.utils.AbstractModel;

import java.io.IOException;
import java.net.URL;

/**
 * 
 */
public class GenericUrlExtractorUI extends AbstractModel implements ExtractorUI {
    private JTextField text = new JTextField();
    private final HtmlExtractor extractor;
    
    private DocumentAdapter urlDocument  = new DocumentAdapter(text) {
        public void handleChange(String s) {
            checkUrl();
        }


    };
    private boolean valid;
    private Action loadAction;

    public GenericUrlExtractorUI(HtmlExtractor extractor) {
        this.extractor = extractor;
    }

    private void checkUrl() {
        try {
            final URL url = new URL(text.getText());
            final String host = url.getHost();
            if (host == null || host.length() < 1) throw new RuntimeException("no host");
            setValid(true);
        } catch (Exception e) {
            setValid(false);
        }
    }

    public String getName() {
        return "Bitte geben Sie eine Adresse(URL) ein";
    }

    public String getDescription() {
        return "Bitte geben Sie eine URL ein:";
    }

    public JComponent getView() {
        return text;
    }

    /**
     * 
     * @param factory
     * @return
     * @throws IOException
     */
    public InformationObject load(InformationObjectFactory factory) throws IOException {
        return extractor.load(text.getText(),factory); 
    }

    public void setLoadAction(Action action) {
        this.loadAction = action;
    }

    private void setValid(boolean valid) {
        if (this.valid != valid) {
            this.valid = valid;
            loadAction.setEnabled(valid);
            firePropertyChange("valid", valid, !valid);
        }
    }
}
