package da.ises.html.base.extractor;

import da.ises.core.rdf.RDFContainer;
import da.ises.core.extractor.DataSource;
import da.ises.core.extractor.ExtractorException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xerces.parsers.AbstractSAXParser;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.DocumentResult;
import org.dom4j.io.DocumentSource;
import org.dom4j.io.SAXReader;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.net.URL;
import java.util.*;


/**
 *
 *
 */
public class XmlHandler {

	private final AbstractSAXParser saxParser;
	private final List<DomExtractor> extractors = new LinkedList<DomExtractor>();
	private final Set<String> mimeTypes = new HashSet<String>();
	private final XsltExtractorManager xsltExtractorManager = new XsltExtractorManager();

	public static interface DomExtractor {
		/**
		 *
		 * @param object
		 * @param document
		 * @throws java.io.IOException
		 */
		void extract(RDFContainer object, Document document) throws IOException;
	}

	public static interface XsltExtractor extends DomExtractor{
		String getName();
		URL getXsltResource();
	}
	/**
	 *
	 * @param saxParser sax parser - for html...
	 * @param mimeTypes mime types
	 */
	protected XmlHandler(AbstractSAXParser saxParser, String... mimeTypes) {
		this.saxParser = saxParser;
		Collections.addAll(this.mimeTypes,mimeTypes);
		this.extractors.add(xsltExtractorManager);
	}

	public XmlHandler(AbstractSAXParser saxParser){
		this(saxParser, "application/xml");
	}

	public String[] getSuportedMimeTypes() {
		return mimeTypes.toArray(new String[mimeTypes.size()]);
	}

	public void addDomExtractor(DomExtractor extractor){
		this.extractors.add(extractor);
	}
	public void addXsltExtractor(XsltExtractor extractor){
		this.xsltExtractorManager.registerTransformer(extractor);
	}
	/**
	 *
	 * @param object
	 * @param dataSource
	 * @throws IOException
	 */
	public void extract(RDFContainer object, DataSource dataSource) throws IOException {
		if (!mimeTypes.contains(dataSource.getMimeType())){
			throw new IOException("Cant extract Mime: " + dataSource.getMimeType());
		}
		try {
			Document xml = getXml(dataSource);
            parseDom(object, xml);
		} catch (DocumentException e) {
			throw new IOException("Cant parse XML: " + e.getMessage());
		} finally{
			dataSource.dispose();
		}
	}

	/**
	 *
	 * @param dataSource
	 * @return
	 * @throws da.ises.core.extractor.ExtractorException
	 */
	public Document getDocument(DataSource dataSource) throws ExtractorException {
		try {
			return getXml(dataSource);
		} catch (DocumentException e) {
			throw new ExtractorException("Cant parse xml! " + e.getMessage());
		} catch (IOException e) {
			throw new ExtractorException(e.getMessage());
		}
	}

	/**
	 *
	 * @param object
	 * @param xml
	 * @throws IOException
	 */
	protected void parseDom(RDFContainer object, Document xml) throws IOException {
		for (DomExtractor handler: extractors){
			handler.extract(object, xml);
		}
	}

	/**
	 *
	 * @param dataSource
	 * @return
	 * @throws DocumentException
	 */
	protected Document getXml(DataSource dataSource) throws DocumentException, IOException {
		return new SAXReader(saxParser).read(dataSource.getInputStream());
	}

	/**
	 *
	 *
	 */
	public static class XsltExtractorManager implements DomExtractor{

		private static final Log log = LogFactory.getLog("plaim");
		private TransformerFactory factory = TransformerFactory.newInstance();

		private final Map<String, Transformer> transformerMap = new HashMap<String, Transformer>();
		private final Map<String, XsltExtractor> extractorMap = new HashMap<String, XsltExtractor>();

		public XsltExtractorManager() {
			System.err.println("me");
		}

		public void registerTransformer(XsltExtractor extractor) {
			try {
				StreamSource source = new StreamSource(extractor.getXsltResource().openConnection().getInputStream());
				transformerMap.put(extractor.getName(), factory.newTransformer(source));
				extractorMap.put(extractor.getName(), extractor);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (TransformerConfigurationException e) {
				e.printStackTrace();
			}
		}

		/**
		 *
		 * @param object
		 * @param source
		 * @throws java.io.IOException
		 */
		public void extract(RDFContainer object,Document source) throws IOException{
			log.info("Transforming");
			DocumentResult res = new DocumentResult();
			for (XsltExtractor extractor : extractorMap.values()) {
				Transformer transformer = transformerMap.get(extractor.getName());
				try {
					transformer.setParameter("document_uri", object.getDescribedUri());
					//transformer.setParameter("language", object.getMetaData().getLanguage()); // U.A f�r Wiki!
					transformer.transform(new DocumentSource(source), res);
					extractor.extract(object, res.getDocument());
				} catch (TransformerException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
