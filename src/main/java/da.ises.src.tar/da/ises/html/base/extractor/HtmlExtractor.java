package da.ises.html.base.extractor;

import da.ises.core.domain.entity.MimeType;
import da.ises.core.domain.entity.Title;
import da.ises.core.domain.entity.Version;
import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.InformationObjectFactory;
import da.ises.core.extractor.AbstractHtmlExtractor;
import da.ises.core.extractor.DataSource;
import da.ises.html.base.DaIsesInfo;
import da.ises.magicmap.ui.util.HtmlSaxParserFactory;
import foxtrot.Task;
import foxtrot.Worker;
import net.sf.magicmap.client.utils.HtmlSaxParser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openrdf.model.BNode;
import org.openrdf.model.Graph;
import org.openrdf.model.URI;
import org.openrdf.model.ValueFactory;
import org.openrdf.model.impl.GraphImpl;
import org.openrdf.model.impl.URIImpl;
import org.openrdf.model.vocabulary.RDF;
import org.openrdf.model.vocabulary.RDFS;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

/**
 *
 */
public class HtmlExtractor extends AbstractHtmlExtractor {

    private final HtmlSaxParser saxParser;

    private final Log log = LogFactory
            .getLog("plaim");

    public HtmlExtractor(HtmlSaxParser saxParser) {
        this.saxParser = saxParser;
    }

    public String getExtractorId() {
        return "text/html";

    }

    public InformationObject load(String uri, InformationObjectFactory factory) throws IOException {
        final InformationObject information = factory.createInformationObject(uri);
        final Version version = information.getVersion();
        final Graph g = new GraphImpl();
        if (version == null) {
            try {
                Worker.post(new Task() {
                    public Object run() throws Exception {
                        load(information, g);
                        return null;
                    }
                });
            } catch (Exception e) {
                throw new IOException(e.getMessage());
            }

        }
        return information;

    }

    /**
     *
     * @param information
     * @param graph
     * @throws IOException
     */
    private void load(InformationObject information, Graph graph) throws IOException{
        final URI uri = new URIImpl(information.getId());
        final DataSource dataSource = new DataSource(new URL(uri.toString()));

        if (!"text/html".equals(dataSource.getMimeType())){
            throw new IOException("Cant extract Mime: " + dataSource.getMimeType());
        }
        try {
            information.setSize(dataSource.getContentsSize());
            information.setMimeType(MimeType.mimeType(dataSource.getMimeType()));

            log.info("Reading doc");
            Document xml = getDocument(dataSource);

            log.info("Doc read");

            final ValueFactory factory = graph.getValueFactory();

            information.setMimeType(MimeType.mimeType(dataSource.getContentType()));
            information.setSize(dataSource.getContentsSize());

            //factory.createLiteral("Ht")
            System.out.print(dataSource.getContentsSize());
            System.out.print(dataSource.getContentType());
            System.out.print(dataSource.getServerResponse());


            String title = xml.valueOf("//*[name()='title']");
            if (title == null || title.length() < 1) {
                throw new IOException("Empty Document!");
                // System.out.println("xml.asXML() = " + xml.asXML());
                // System.out.println("ist aber:" + new String(dataSource.getData()));
            }
            System.out.println("title = " + title);
            information.setTitle(Title.title(title));
            final String description = xml.valueOf("//meta[@name='description']/@content");
            if (description != null) {
                graph.add(uri, RDFS.COMMENT, factory.createLiteral(description));
            }
            getLinks(xml, graph,dataSource.getUrl());
            information.getMetaData().addAll(graph);
        } catch (DocumentException de) {
            throw new IOException(de.getMessage());
        }
    }

    @SuppressWarnings({"unchecked"})
    private void getLinks(Document xml, Graph graph, URL base) {
        List<org.dom4j.Node> list = xml.selectNodes("//a");

        if (list == null ) return;
        ValueFactory factory = graph.getValueFactory();
        for (org.dom4j.Node n: list) {
            String href = n.valueOf("@href");
            try {
                URL link = new URL(base, href);
                BNode bNode = factory.createBNode();
                graph.add(bNode, RDF.TYPE, DaIsesInfo.Link);
                graph.add(bNode, DaIsesInfo.source, new URIImpl(base.toString()));
                graph.add(bNode, DaIsesInfo.target, new URIImpl(link.toString()));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     *
     * @param dataSource
     * @return
     * @throws DocumentException
     * @throws java.io.IOException
     */
    protected Document getDocument(DataSource dataSource) throws DocumentException, IOException {
        SAXReader saxReader = new SAXReader(HtmlSaxParserFactory.getSaxParser());
        saxReader.setIgnoreComments(true);
        saxReader.setValidation(false);
        return saxReader.read(dataSource.getUrl()); 
    }

    public static void main(String[] args) throws IOException {
        HtmlExtractor extractor = new HtmlExtractor(HtmlSaxParserFactory.getSaxParser());
        extractor.load(new InformationObject(new URIImpl("http://de.wikipedia.org/wiki/Berlin")), new GraphImpl());
        extractor.load(new InformationObject(new URIImpl("http://www.spiegel.de")), new GraphImpl());
    }

}