package da.ises.html.base;

import org.openrdf.model.ValueFactory;
import org.openrdf.model.URI;
import org.openrdf.model.impl.ValueFactoryImpl;

/**
 *
 */
public class DaIsesInfo {
    public static final String NAMESPACE = "http://www.magicmap.de/2008/07/daises-nfo#";

    public static final URI Facet;
    public static final URI Link;
    public static final URI source;
    public static final URI target;


    static {
        final ValueFactory factory = new ValueFactoryImpl();
        Link = factory.createURI(NAMESPACE, "Link");
        Facet = factory.createURI(NAMESPACE, "Facet");
        source = factory.createURI(NAMESPACE, "source");
        target = factory.createURI(NAMESPACE, "target");
    }
}
