package da.ises.html.base.extractor.xslt;

/**
 * <p>
 * Class XsltExtractorFactory ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 02.08.2008
 *         Time: 14:11:24
 */
public class XsltExtractor {
}
