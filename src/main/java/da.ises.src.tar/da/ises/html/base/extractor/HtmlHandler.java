package da.ises.html.base.extractor;

import net.sf.magicmap.client.utils.HtmlSaxParser;

import org.dom4j.Document;
import org.dom4j.Node;
import org.openrdf.model.ValueFactory;

import java.io.IOException;
import java.net.URL;

import da.ises.html.base.extractor.XmlHandler;
import da.ises.core.rdf.voc.DC;
import da.ises.core.rdf.RDFContainer;
import da.ises.magicmap.ui.util.HtmlSaxParserFactory;

/**
 *
 */
public class HtmlHandler extends XmlHandler {

	/**
	 *
	 */
	public HtmlHandler() {
		super(HtmlSaxParserFactory.getSaxParser(), "text/html");
	}

	/**
	 *
	 * @param container
	 * @param xml
	 * @throws java.io.IOException
	 */
	protected void parseDom(final RDFContainer container, Document xml) throws IOException {
		final Node node = xml.selectSingleNode("//*[local-name()='title']");
        final ValueFactory fact = container.getValueFactory();
        if (node != null){
            container.set(DC.Title, fact.createLiteral(node.valueOf("text()")));

		}
		Node iconNode = node.selectSingleNode("//*[@rel='shortcut icon']");
        URL baseURL = new URL(container.getDescribedUri().toString());
        if (iconNode != null){

            //container.getMetaData().setDepiction(new URL(baseURL, iconNode.valueOf("@href")).toString());
		}
        final String lang = xml.getRootElement().valueOf("@lang");
        if (lang != null) {
            container.set(DC.Language, fact.createLiteral(lang));
        }
		super.parseDom(container, xml);
	}

}
