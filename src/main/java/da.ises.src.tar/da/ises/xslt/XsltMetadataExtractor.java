package da.ises.xslt;

import da.ises.core.extractor.ExtractorException;
import da.ises.core.extractor.MetadataExtractor;
import da.ises.core.extractor.MetadataExtractorResult;
import da.ises.magicmap.ui.util.HtmlSaxParserFactory;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.xerces.parsers.AbstractSAXParser;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.DocumentSource;
import org.dom4j.io.SAXReader;
import org.openrdf.rio.RDFParser;
import org.openrdf.rio.helpers.StatementCollector;
import org.openrdf.rio.turtle.TurtleParserFactory;

import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * <p>
 * Class XsltExtractor ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 02.08.2008
 *         Time: 14:25:37
 */
public class XsltMetadataExtractor implements MetadataExtractor {

    static HttpClient httpClient = new HttpClient(new MultiThreadedHttpConnectionManager());
    private final AbstractSAXParser saxParser = HtmlSaxParserFactory.getSaxParser();
    private TransformerFactory factory = TransformerFactory.newInstance();
    private final Set<Transformer> transformers = new HashSet<Transformer>();

    /**
     * 
     * @param xslt
     * @throws IOException
     * @throws TransformerConfigurationException
     */
    public void addXslt(String xslt) throws IOException, TransformerConfigurationException {
        URL xsltUrl = xslt.startsWith("classpath:") ?
                getClass().getClassLoader().getResource(xslt.substring("classpath:".length())) :
                new URL(xslt);
        StreamSource source = new StreamSource(xsltUrl.openConnection().getInputStream());
        transformers.add(factory.newTransformer(source));
    }

    /**
     * @param uri
     * @return a result.
     */
    public MetadataExtractorResult extract(String uri) {
        final MetadataExtractorResult result = new MetadataExtractorResult(uri, new Timestamp(System.currentTimeMillis()));
        final TurtleParserFactory parserFactory = new TurtleParserFactory();
        try {
            URL url = new URL(uri);
            StringWriter stringWriter = new StringWriter();
            final Result transformResult = new StreamResult(stringWriter);


            for (Transformer transformer: this.transformers){
                transformer.setParameter("base_uri", uri);
                transformer.setParameter("source_host", url.getHost());
                transformer.setParameter("source_protocol", url.getProtocol());
                transformer.setParameter("source_file", url.getFile());
                transformer.transform(new DocumentSource(getDocument(uri)), transformResult);

                String rdf = stringWriter.toString();
                if (rdf != null && rdf.length() > 0){
                    System.out.println("parsing = " + stringWriter.toString());
                    RDFParser rdfParser = parserFactory.getParser();
                    rdfParser.setRDFHandler(new StatementCollector());
                    rdfParser.parse(new StringReader(stringWriter.toString()), uri);
                }
            }
        } catch (MalformedURLException e) {
            result.setError(e);
        } catch (Exception e){
            result.setError(e);
        }
        return result;
    }
    /**
     *
     * @param dataSource
     * @return
     * @throws da.ises.core.extractor.ExtractorException
     */
    public Document getDocument(String uri) throws ExtractorException {
        final GetMethod m = new GetMethod(uri);
        try {
            int result = httpClient.executeMethod(m);
            Header contentType = m.getResponseHeader("Content-Type");
            Header lastModified =  m.getResponseHeader("Last-Modified");
            System.out.println("result = " + m.getResponseHeaders());
            Document document = new SAXReader(saxParser).read(m.getResponseBodyAsStream());
            return document;
        } catch (DocumentException e) {
            throw new ExtractorException("Cant parse xml! " + e.getMessage());
        } catch (IOException e) {
            throw new ExtractorException(e.getMessage());
        } finally{
            m.releaseConnection();
        }
    }

    public static void main(String[] args) throws Exception, TransformerConfigurationException {
        XsltMetadataExtractor extractor = new XsltMetadataExtractor();
        extractor.addXslt("classpath:da/ises/xslt/html.xsl");
        extractor.addXslt("classpath:da/ises/xslt/mediawiki.xsl");
        //extractor.extract("http://www.spiegel.de");
        System.out.println("--------------------------");
        MetadataExtractorResult result = extractor.extract("http://de.wikipedia.org/wiki/Berlin");
        if (result.getError() != null){
            throw result.getError();
        }

    }

}
