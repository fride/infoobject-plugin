package da.ises.core.search;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: 16.06.2008
 * Time: 13:04:24
 * To change this template use File | Settings | File Templates.
 */
public interface Query {
}
