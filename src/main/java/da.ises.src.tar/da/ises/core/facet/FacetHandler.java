package da.ises.core.facet;

import da.ises.core.domain.infoobject.InformationObject;

/**
 * 
 */
public interface FacetHandler {


    /**
     * 
     * @param object
     * @return
     */
    boolean canHandle(InformationObject object);
    
    /**
     * 
     * @param object
     */
    void handle(InformationObject object);
}
