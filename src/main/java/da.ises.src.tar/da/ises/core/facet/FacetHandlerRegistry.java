package da.ises.core.facet;

import da.ises.core.domain.infoobject.InformationObject;

import java.util.Set;
import java.util.HashSet;

/**
 *
 * 
 */
public class FacetHandlerRegistry {

    private Set<FacetHandler> handlers = new HashSet<FacetHandler>();

    private static FacetHandlerRegistry instance;

    public static FacetHandlerRegistry get() {
        if (instance == null) {
            instance = new FacetHandlerRegistry();
        }
        return instance;
    }

    public boolean register(FacetHandler handler) {
        return this.handlers.add(handler);
    }

    public void handle(InformationObject object) {
        for (FacetHandler handler:handlers) {
            if (handler.canHandle(object)) {
                handler.handle(object);
            }

        }
    }
}
