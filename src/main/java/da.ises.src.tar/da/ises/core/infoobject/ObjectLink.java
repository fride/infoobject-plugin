package da.ises.core.infoobject;

import da.ises.core.domain.BaseObject;
import net.sf.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/**
 * <p>
 * Class ObjectLink ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 01:19:53
 */
public class ObjectLink extends BaseObject {
    private String uri;
    private ObjectName object;
    private Set<String> linkTypes = new HashSet<String>();
    private String agentId;

    public ObjectLink() {
    }

    public ObjectLink(ObjectName object) {
        this.object = object;
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public ObjectName getObject() {
        return object;
    }

    public void setObject(ObjectName object) {
        this.object = object;
    }

    public Set<String> getLinkTypes() {
        return linkTypes;
    }

    public void setLinkTypes(Set<String> linkTypes) {
        this.linkTypes = linkTypes;
    }

    @Override
    public String toString() {
        return JSONObject.fromObject(this).toString();
    }
}
