package da.ises.core.infoobject;

import da.ises.core.domain.entity.Description;
import da.ises.core.domain.entity.Title;

import java.util.List;

/**
 * <p>
 * Class InformationObjectRepository ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 01:25:07
 */
public interface InformationObjectRepository {


    /**
     * 
     * @param name
     * @return
     */
    List<InformationObject2> findInformationsByObject(ObjectName name);

    /**
     * 
     * @param tags
     * @return
     */
    List<InformationObject2> findTaggings(Iterable<Tag> tags);




    List<Tag> findTags();

    /**
     *
     * @param taggings
     * @param title
     * @param description
     */
    void publishTaggings(Iterable<Tagging> taggings, Title title, Description description);

    /**
     *
     * @param links
     */
    void publishObjectLinks(Iterable<ObjectLink> links);

    /**
     *
     * @param data
     */
    void publishInformations(Iterable<InformationData> data);


    /**
     * 
     * @param tagging
     */
    void deleteTagging(Tagging tagging);
}
