package da.ises.core.infoobject;

import net.sf.json.JSONObject;
import org.apache.commons.collections15.MultiMap;
import org.apache.commons.collections15.multimap.MultiHashMap;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * Class InformationObject2 ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 22:35:54
 */
public class InformationObject2 {
    private InformationData metadata;
    private MultiMap<String, Tagging> taggings = new MultiHashMap<String, Tagging>();
    private Map<ObjectName, ObjectLink> objectLinks = new HashMap<ObjectName, ObjectLink>();


    public InformationData getMetadata() {
        return metadata;
    }

    public void setMetadata(InformationData metadata) {
        this.metadata = metadata;
    }

    public MultiMap<String, Tagging> getTaggings() {
        return taggings;
    }

    public void setTaggings(MultiMap<String, Tagging> taggings) {
        this.taggings = taggings;
    }

    public Map<ObjectName, ObjectLink> getObjectLinks() {
        return objectLinks;
    }

    public void setObjectLinks(Map<ObjectName, ObjectLink> objectLinks) {
        this.objectLinks = objectLinks;
    }

    @Override
    public String toString() {
        return JSONObject.fromObject(this).toString();
    }
}
