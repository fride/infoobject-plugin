package da.ises.core.infoobject;

import net.sf.json.JSONObject;

/**
 *
 */
public class Tagging {

    private String tagged;
    private Tag tag;
    private boolean positive;
    private String agentId;
    private String id;

    public Tagging() {
    }

    public Tagging(String tagged, String tag, boolean positive, String agentid) {
        this.tagged = tagged;
        this.tag = new Tag(tag);
        this.positive = positive;
        this.agentId = agentid;
    }

    public String getTagged() {
        return tagged;
    }

    public void setTagged(String tagged) {
        this.tagged = tagged;
    }

    public Tag getTag() {
        return tag;
    }

    public void setTag(Tag tag) {
        this.tag = tag;
    }

    public boolean isPositive() {
        return positive;
    }

    public void setPositive(boolean positive) {
        this.positive = positive;
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return JSONObject.fromObject(this).toString();
    }
}
