package da.ises.core.infoobject;

import net.sf.json.JSONObject;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.net.URLCodec;

public class Tag {
    private final String rawValue;
    private String normalizedValue;
    private static URLCodec codec = new URLCodec();

    /**
     * @param rawValue the raw value. "Ein dooles Ding" eg.
     */
    public Tag(String rawValue) {
        this.rawValue = rawValue;
        this.normalizedValue = normalize(rawValue);

    }


    /**
     *
     * @return
     */
    public String getRawValue() {
        return rawValue;
    }

    /**
     *
     * @return
     */
    public String getNormalizedValue() {
        return normalizedValue;
    }

    /**
     *
     * @param rawValue
     * @return
     */
    public static String normalize(String rawValue) {
        try {
            return codec.encode(rawValue.toLowerCase());
        } catch (EncoderException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String toString() {
        return JSONObject.fromObject(this).toString();
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Tag)) return false;

        Tag tag = (Tag) o;

        if (normalizedValue != null ? !normalizedValue.equals(tag.normalizedValue) : tag.normalizedValue != null)
            return false;

        return true;
    }

    public int hashCode() {
        return (normalizedValue != null ? normalizedValue.hashCode() : 0);
    }
}
