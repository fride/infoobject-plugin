package da.ises.core.util;

/**
 * Created by IntelliJ IDEA.
 * User: janfriderici
 * Date: Jul 5, 2008
 * Time: 2:11:17 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Startable {
}
