package da.ises.core.rdf.voc;

import org.openrdf.model.URI;
import org.openrdf.model.ValueFactory;
import org.openrdf.model.impl.ValueFactoryImpl;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: 07.06.2008
 * Time: 10:54:35
 * To change this template use File | Settings | File Templates.
 */
public class FOAF {

     public static final String NAMESPACE = "http://xmlns.com/foaf/0.1/";

    public static final URI AGENT;
    public static final URI DOCUMENT;
    public static final URI mbox_sha1sum;
    public static final URI name;
    public static final URI holdsAccount;
    public static final URI OnlineAccount;

    static{
        final ValueFactory factory = new ValueFactoryImpl();
        AGENT = factory.createURI(NAMESPACE,"Agent");
        DOCUMENT = factory.createURI(NAMESPACE,"Document");
        mbox_sha1sum = factory.createURI(NAMESPACE,"mbox_sha1sum");
        name = factory.createURI(NAMESPACE,"name");
        holdsAccount = factory.createURI(NAMESPACE,"holdsAccount");
        OnlineAccount = factory.createURI(NAMESPACE,"OnlineAccount");

    }
}
