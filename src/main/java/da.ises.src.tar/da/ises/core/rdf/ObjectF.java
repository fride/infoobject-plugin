package da.ises.core.rdf;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: 07.06.2008
 * Time: 13:28:06
 * To change this template use File | Settings | File Templates.
 */
public interface ObjectF {

    Object create(RDFContainer container);
}
