package da.ises.core.rdf.voc;

import org.openrdf.model.URI;
import org.openrdf.model.ValueFactory;
import org.openrdf.model.impl.ValueFactoryImpl;

/**
 *
 * 
 */
public class SKOS {

    public static String NAMESPACE= "http://www.w3.org/2008/05/skos#";


    public static final URI Concept;

    
    static{
        final ValueFactory factory = new ValueFactoryImpl();
        Concept = factory.createURI(NAMESPACE,"Concept");

    }
}
