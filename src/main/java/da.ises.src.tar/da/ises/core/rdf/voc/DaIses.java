
package da.ises.core.rdf.voc;

import org.openrdf.model.ValueFactory;
import org.openrdf.model.URI;
import org.openrdf.model.impl.ValueFactoryImpl;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryException;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.rio.RDFFormat;
import org.openrdf.rio.RDFParseException;

import java.io.IOException;
import java.net.URL;

public class
        DaIses{
    public static final String NAMESPACE = "http://www.magicmap.de/2008/07/daises#";

    ;

    public static void loadModel(Repository repository) {
        URL resource = DaIses.class.getClassLoader().getResource("da/ises/voc/daises.n3");
        RepositoryConnection connection = null;
        try {
            connection = repository.getConnection();
            connection.add(resource, resource.toString(), RDFFormat.N3);
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (RDFParseException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (RepositoryException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (RepositoryException e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            }
        }
    }

    // Classes
    public static final URI Version;
    public static final URI Annotation;
    public static final URI InfoObjectAnnotation;
    public static final URI Tagging;
    public static final URI InfoObject;
    public static final URI Admin;
    public static final URI Tag;
    public static final URI Role;
    public static final URI PositionAnnotation;
    public static final URI Entity;
    public static final URI Position;
    public static final URI User;
    public static final URI isPositive;
    public static final URI isTagging;
    public static final URI hasPosition;
    public static final URI hasInformation;
    public static final URI objectSize;
    public static final URI hasTagging;
    public static final URI userPass;
    public static final URI creationDate;
    public static final URI tagRaw;
    public static final URI modificationDate;
    public static final URI infoFacet;
    public static final URI nodeServer;
    public static final URI hasOldVersion;
    public static final URI nodeType;
    public static final URI repositoryId;
    public static final URI userName;
    public static final URI isVersion;
    public static final URI hasTag;
    public static final URI isOldVersion;
    public static final URI desription;
    public static final URI hasVersion;
    public static final URI hasRole;
    public static final URI TagPost;
    public static final URI tags;
    public static final URI PositionPost;
    public static final URI hasTagPost;
    public static final URI hasPositionPost;

    static {
        final ValueFactory factory = new ValueFactoryImpl();
        Version = factory.createURI(NAMESPACE,"Version");
        Annotation = factory.createURI(NAMESPACE,"Tagging");
        InfoObjectAnnotation = factory.createURI(NAMESPACE,"InfoObjectAnnotation");
        Tagging = factory.createURI(NAMESPACE,"Tagging");
        InfoObject = factory.createURI(NAMESPACE,"InfoObject");
        Admin = factory.createURI(NAMESPACE,"Admin");
        Tag = factory.createURI(NAMESPACE,"Tag");
        Role = factory.createURI(NAMESPACE,"Role");
        PositionAnnotation = factory.createURI(NAMESPACE,"PositionAnnotation");
        Entity = factory.createURI(NAMESPACE,"Entity");
        Position = factory.createURI(NAMESPACE,"Position");
        User = factory.createURI(NAMESPACE,"Agent");
        isPositive = factory.createURI(NAMESPACE,"isPositive");
        isTagging = factory.createURI(NAMESPACE,"isTagging");
        hasPosition = factory.createURI(NAMESPACE,"hasObject");
        hasInformation = factory.createURI(NAMESPACE,"hasInformation");
        objectSize = factory.createURI(NAMESPACE,"objectSize");
        hasTagging = factory.createURI(NAMESPACE,"hasTagging");
        userPass = factory.createURI(NAMESPACE,"userPass");
        creationDate = factory.createURI(NAMESPACE,"creationDate");
        tagRaw = factory.createURI(NAMESPACE,"tagRaw");
        modificationDate = factory.createURI(NAMESPACE,"modificationDate");
        infoFacet = factory.createURI(NAMESPACE,"infoFacet");
        nodeServer = factory.createURI(NAMESPACE,"nodeServer");
        hasOldVersion = factory.createURI(NAMESPACE,"hasOldVersion");
        nodeType = factory.createURI(NAMESPACE,"nodeType");
        repositoryId = factory.createURI(NAMESPACE,"repositoryId");
        userName = factory.createURI(NAMESPACE,"userName");
        isVersion = factory.createURI(NAMESPACE,"isVersion");
        hasTag = factory.createURI(NAMESPACE,"hasTag");
        isOldVersion = factory.createURI(NAMESPACE,"isOldVersion");
        desription = factory.createURI(NAMESPACE,"desription");
        hasVersion = factory.createURI(NAMESPACE,"hasVersion");
        hasRole = factory.createURI(NAMESPACE,"hasRole");
        TagPost = factory.createURI(NAMESPACE,"TaggingPost");
        tags = factory.createURI(NAMESPACE,"tags");
        PositionPost = factory.createURI(NAMESPACE,"PositionPost");
        hasTagPost = factory.createURI(NAMESPACE,"hasTagPost");
        hasPositionPost = factory.createURI(NAMESPACE,"hasPositionPost");
    }
}

