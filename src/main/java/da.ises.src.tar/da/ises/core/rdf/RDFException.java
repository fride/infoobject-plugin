package da.ises.core.rdf;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: 07.06.2008
 * Time: 14:31:27
 * To change this template use File | Settings | File Templates.
 */
public class RDFException extends RuntimeException{
    public RDFException() {
    }

    public RDFException(String s) {
        super(s);
    }

    public RDFException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public RDFException(Throwable throwable) {
        super(throwable);
    }
}
