package da.ises.core.rdf;

import org.openrdf.model.URI;

/**
 *
 * 
 */
public interface RDFContainerFactory {

    /**
     * 
     * @param uri the uri the container describes.
     * @return  a container for the uri
     */
    RDFContainer create(URI uri);

    /**
     * 
     * @param uri the uri.
     * @return a container for the uri
     */
    RDFContainer create(String uri);
    
}
