package da.ises.core.rdf;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: 07.06.2008
 * Time: 13:47:04
 * To change this template use File | Settings | File Templates.
 */
public class RDFContainerException extends RDFException{
    public RDFContainerException() {
    }

    public RDFContainerException(String s) {
        super(s);
    }

    public RDFContainerException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public RDFContainerException(Throwable throwable) {
        super(throwable);
    }
}
