package da.ises.core.rdf;

import da.ises.core.rdf.RDFException;
import org.openrdf.model.*;
import org.openrdf.model.impl.GraphImpl;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.RepositoryException;
import org.openrdf.repository.RepositoryResult;
import org.openrdf.repository.Repository;

import java.util.Collection;
import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;

import da.ises.core.rdf.RDFContainerException;

/**
 * Vereinfacht den Umgang mi RDF Repositories.....
 *
 */
public class RDFContainer{
    private final URI uri;
    private final Graph graph;

    /**
     *
     * @param uri
     * @param graph
     */
    public RDFContainer(URI uri, Graph graph) {
        this.uri = uri;
        this.graph = graph;
    }

    public RDFContainer(URI uri) {
        this (uri, new GraphImpl());
    }
    /**
     * @return
     */
    public URI getDescribedUri() {
        return uri;
    }

    /**
     * @param property
     * @param value
     */
    public void add(URI property, String value) {
        ValueFactory factory = getValueFactory();
        add(property,factory.createLiteral(value));
    }

    /**
     * @param property
     * @param value
     */
    public void add(URI property, Number value) {

    }

    /**
     * @param property
     * @param value
     */
    public void add(URI property, Boolean value) {
        ValueFactory factory = getValueFactory();
        add(property,factory.createLiteral(value));
    }

    private void add(URI property, Value value) throws RDFContainerException {
        graph.add(uri,property,value);


    }

    /**
     * @param property
     * @param value
     */
    public void add(URI property, Resource value) {
        ValueFactory factory = getValueFactory();
        //addAll(property,factory.createLiteral(value));
    }

    /**
     * @param statements
     * @throws da.ises.core.rdf.RDFContainerException
     *
     */
    public void addAll(Statement... statements) throws RDFContainerException {
        for (Statement statement:statements) {
            graph.add(statement);
        }
    }

    /**
     * @param property
     * @throws da.ises.core.rdf.RDFContainerException
     *
     */
    public boolean removeAll(URI property) throws RDFContainerException {
        Iterator<Statement> statementIterator = graph.match(getDescribedUri(), property, null);
        while (statementIterator.hasNext()) {
            graph.remove(statementIterator.next());
        }
        return true;
    }



    /**
     * @param property
     * @param value
     * @return
     * @throws da.ises.core.rdf.RDFContainerException
     *
     */
    public boolean remove(URI property, Value value) throws RDFContainerException {
        Iterator<Statement> statementIterator = graph.match(getDescribedUri(), property, value);
        boolean removed = false;
        while (statementIterator.hasNext()) {
            removed = removed || graph.remove(statementIterator.next());
        }
        return removed;
    }

    /**
     * @param statement
     * @throws da.ises.core.rdf.RDFContainerException
     *
     */
    public void remove(Statement statement) throws RDFContainerException {
        graph.remove(statement);
    }

    /**
     * @return
     */
    public ValueFactory getValueFactory() {
        return graph.getValueFactory();
    }

    /**
     * @param property
     * @return
     */
    public String getString(URI property) {
        Iterator<Statement> statementIterator = graph.match(getDescribedUri(), property, null);
        if (statementIterator.hasNext()) {
            return statementIterator.next().getObject().stringValue();
        }
        return null;
    }

    /**
     * @param property
     * @return
     */
    public Value getValue(URI property) {
        Iterator<Statement> statementIterator = graph.match(getDescribedUri(), property, null);
        if (statementIterator.hasNext()) {
            return statementIterator.next().getObject();
        }
        return null;
    }

    /**
     * @param property
     * @return
     */
    public URI getUri(URI property) {
        Iterator<Statement> statementIterator = graph.match(getDescribedUri(), property, null);
        if (statementIterator.hasNext()) {
            return (URI)statementIterator.next().getObject();
        }
        return null;
    }

    /**
     * @param property
     * @return
     */
    public Collection<Value> getAll(URI property) {
        List<Value> values = new LinkedList<Value>();
        Iterator<Statement> statementIterator = graph.match(getDescribedUri(), property, null);
        while (statementIterator.hasNext()) {
            values.add(statementIterator.next().getObject());
        }
        return values;
    }

    /**
     * @param property
     * @param value
     */
    public void set(URI property, Value value) {
        remove(property,null);
        graph.add(getDescribedUri(), property,value);

    }


}
