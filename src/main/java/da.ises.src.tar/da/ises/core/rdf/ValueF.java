package da.ises.core.rdf;

import org.openrdf.model.Value;
import org.openrdf.model.ValueFactory;

/**
 *
 */
public interface ValueF {

    /**
     *
     * @param factory
     * @return
     */
    Value transform(ValueFactory factory);
}