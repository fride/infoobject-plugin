package da.ises.core.rdf.voc;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: 07.06.2008
 * Time: 10:54:40
 * To change this template use File | Settings | File Templates.
 */
public class DOAP {
}
