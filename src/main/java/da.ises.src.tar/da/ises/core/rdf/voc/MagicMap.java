package da.ises.core.rdf.voc;

import org.openrdf.model.URI;
import org.openrdf.model.ValueFactory;
import org.openrdf.model.impl.ValueFactoryImpl;

/**
 *
 *
 */
public class MagicMap {

    public static String NAMESPACE= "http://www.plugin.de/2008/06/infoobject#";


    /**
     * A position for an information.
     */
    public static final URI InfoPosition;

    /**
     * A Facet for an information. An information can has as many facets as it wants.
     */
    public static final URI InfoFacet;

    /**
     * A Node.
     */
    public static final URI MagicNode;

    /**
     * a property of an information
     */
    public static final URI atNode;
    public static final URI hasInfo;
    public static final URI hasFacet;
    public static final URI Node;
    public static final URI tagged;
    public static final URI MagicUser;
    public static final URI MagicServer;
    public static final URI InfoObject;



    static{
        final ValueFactory factory = new ValueFactoryImpl();
        InfoFacet = factory.createURI(NAMESPACE,"InfoFacet");
        MagicNode = factory.createURI(NAMESPACE,"MagicNode");
        atNode = factory.createURI(NAMESPACE,"atNode");
        hasInfo = factory.createURI(NAMESPACE,"hasInfo");
        hasFacet = factory.createURI(NAMESPACE,"hasFacet");
        InfoPosition = factory.createURI(NAMESPACE,"InfoPosition");
        Node = factory.createURI(NAMESPACE,"Node");
        serverId = factory.createURI(NAMESPACE,"serverId");
        tagged = factory.createURI(NAMESPACE,"tagged");
        MagicUser = factory.createURI(NAMESPACE,"magicUser");
        MagicServer = factory.createURI(NAMESPACE,"magicServer");
        InfoObject = factory.createURI(NAMESPACE,"DaIses");

    }

    public static URI serverId;
}
