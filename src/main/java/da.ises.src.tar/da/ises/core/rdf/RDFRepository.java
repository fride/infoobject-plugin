package da.ises.core.rdf;

import da.ises.core.rdf.RDFContainerFactory;
import org.openrdf.repository.Repository;

/**
 * Wrapper.....
 */
public interface RDFRepository extends RDFContainerFactory {

    /**
     * 
     * @return
     */
    public Repository getRepository();
}
