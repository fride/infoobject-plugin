package da.ises.core.domain.user;

import da.ises.core.domain.entity.AbstractEntity;
import da.ises.core.util.Digest;
import org.openrdf.model.URI;
import org.openrdf.model.impl.URIImpl;

/**
 *
 */
public class Agent extends AbstractEntity {
    private String userName;
    private Password password;
    private boolean admin;
    private boolean guest;
    private String jabberID;
    public static final Agent ANONYMOUS = new Agent("anonymous", Password.password(""));


    public Agent() {
    }

    /**
     * @param subjectResource
     * @param userName the users name.
     */
    public Agent(String userName, Password password) {
        super(Digest.sha1(userName));
        this.userName = userName;
        this.password = password;
    }

    public String getJabberID() {
        return jabberID;
    }

    public void setJabberID(String jabberID) {
        this.jabberID = jabberID;
    }

    /**
     * 
     * @return
     */
    public String getUserName() {
        return userName;
    }

    /**
     * 
     * @return
     */
    public Password getPassword() {
        return password;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public boolean isGuest() {
        return guest;
    }

    public void setGuest(boolean guest) {
        this.guest = guest;
    }


    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(Password password) {
        this.password = password;
    }


}
