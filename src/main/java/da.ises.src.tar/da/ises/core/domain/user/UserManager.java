package da.ises.core.domain.user;

import da.ises.core.domain.user.Agent;

/**
 * 
 */
public interface UserManager {

    /**
     * 
     * @param name the name - in magic map.
     * @param password a password.
     * @param email the email for this user.
     * @return
     */
    Agent create(String name, String password, String email);

    /**
     * 
     * @param name
     * @return
     */
    Agent load(String name);

    /**
     * 
     * @param agent
     * @return
     */
    Agent store(Agent agent);

    /**
     * 
     * @param agent
     * @return
     */
    boolean delete(Agent agent);
}
