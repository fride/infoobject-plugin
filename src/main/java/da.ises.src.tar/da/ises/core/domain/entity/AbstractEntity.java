package da.ises.core.domain.entity;

/**
 * An Entity and Subject. Subjects an be Annotated.... 
 */
public class AbstractEntity implements Entity {
    private String id;
    private Version version;

    public AbstractEntity() {
    }

    public AbstractEntity(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setVersion(Version version) {
        this.version = version;
    }


    public Version getVersion() {
        return version;
    }
}
