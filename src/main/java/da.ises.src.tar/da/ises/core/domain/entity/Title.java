package da.ises.core.domain.entity;

/**
 * A an entities title.
 */
public class Title {
    
    private final String title;

    /**
     *
     * @param title
     */
    public Title(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    /**
     * 
     * @param title
     * @return
     */
    public static Title title(String title) {
        return title != null ? new Title(title) : null;
    }

    public String toString() {
        return title;
    }

    /**
     * 
     * @param o
     * @return
     */
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Title)) return false;

        Title title1 = (Title) o;

        if (title != null ? !title.equals(title1.title) : title1.title != null) return false;

        return true;
    }

    public int hashCode() {
        return (title != null ? title.hashCode() : 0);
    }
}
