package da.ises.core.domain.entity;

import java.sql.Timestamp;


/**
 * A modification of an entity.
 */
public class Version {

    private final Timestamp creationDate;
    private final Timestamp modificationDate;
    private final String username;
    private final Long version;
    private static Version NEVER = null;
    
    /**
     * 
     * @param creationDate the creation date.
     * @param modificationDate
     * @param username
     * @param version
     */
    public Version(Timestamp creationDate, Timestamp modificationDate, String username, Long version) {
        this.creationDate = creationDate;
        this.modificationDate = modificationDate;
        this.username = username;
        this.version = version;
    }

    /**
     * 
     * @return
     */
    public Timestamp getCreationDate() {
        return creationDate;
    }

    /**
     * 
     * @return
     */
    public Timestamp getModificationDate() {
        return modificationDate;
    }

    /**
     * 
     * @return
     */
    public String getUsername() {
        return username;
    }

    /**
     * 
     * @return
     */
    public Long getVersion() {
        return version;
    }

    /**
     * 
     * @return
     */
    public static Version now() {
        Timestamp rightNow = new Timestamp(System.currentTimeMillis());
        return new Version(rightNow,rightNow, "anonymous", 0l);
    }

    /**
     * 
     * @param start
     * @return
     */
    public static Version now(Long start) {
        Timestamp rightNow = new Timestamp(System.currentTimeMillis());
        return new Version(new Timestamp(start), rightNow, "anonymous", 0l);
    }


    /**
     * 
     * @param other the other modification to compare to
     * @return true if this modification is newer than the other.
     */
    public boolean isNewer(Version other){
        return this.modificationDate.after(other.modificationDate);
    }
    /**
     * 
     * 
     * @param user
     * @return
     */
    public static Version now(String user) {
        Timestamp rightNow = new Timestamp(System.currentTimeMillis());
        return new Version(rightNow, rightNow, user, 0l);
    }
    
    /**
     * 
     * @param other
     * @return
     */
    public static Version nowAfter(Version other) {
        if (other.equals(never())) throw new IllegalArgumentException();
        Timestamp start =(other.getModificationDate());
        Timestamp modification = new Timestamp(System.currentTimeMillis());
        return new Version(start,modification,other.getUsername(), other.getVersion()+1);
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Version)) return false;

        Version that = (Version) o;

        if (creationDate != null ? !creationDate.equals(that.creationDate) : that.creationDate != null) return false;
        if (modificationDate != null ? !modificationDate.equals(that.modificationDate) : that.modificationDate != null)
            return false;
        if (username != null ? !username.equals(that.username) : that.username != null) return false;
        if (version != null ? !version.equals(that.version) : that.version != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (creationDate != null ? creationDate.hashCode() : 0);
        result = 31 * result + (modificationDate != null ? modificationDate.hashCode() : 0);
        result = 31 * result + (username != null ? username.hashCode() : 0);
        result = 31 * result + (version != null ? version.hashCode() : 0);
        return result;
    }

    /**
     * 
     * @return
     */
    public static Version never() {
        if (NEVER == null){
            NEVER = new Version(null,null,null,0l);
        }
        return NEVER;
    }


    public Version next() {
        return new Version(getCreationDate(),new Timestamp(System.currentTimeMillis()), getUsername(), getVersion() +1);
    }

    public Version next(String user) {
        return new Version(getCreationDate(),new Timestamp(System.currentTimeMillis()),user, getVersion() +1);
    }
}
