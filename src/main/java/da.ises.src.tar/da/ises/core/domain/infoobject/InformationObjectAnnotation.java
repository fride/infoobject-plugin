package da.ises.core.domain.infoobject;

import da.ises.core.domain.entity.Auditable;
import da.ises.core.domain.entity.Version;
import da.ises.core.domain.user.Agent;

/**
 * <p>
 * Baseclass for Objects whishing to annotate uris (information objects).
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 24.07.2008
 *         Time: 23:19:15
 */
public abstract class InformationObjectAnnotation implements Auditable {
    private InformationObject information;
    private Agent creator;
    private Version version;

    /**
     * @param information
     * @param creator
     */
    public InformationObjectAnnotation(InformationObject information, Agent creator) {
        this.information = information;
        this.creator = creator;
    }


    public Agent getCreator() {
        return creator;
    }

    public void setCreator(Agent creator) {
        this.creator = creator;
    }

    public InformationObject getInformation() {
        return information;
    }

    public void setInformation(InformationObject information) {
        this.information = information;
    }

    public Version getVersion() {
        return this.version;
    }

    public void setVersion(Version version) {
        this.version = version;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InformationObjectAnnotation)) return false;

        InformationObjectAnnotation that = (InformationObjectAnnotation) o;

        if (creator != null ? !creator.equals(that.creator) : that.creator != null) return false;
        if (information != null ? !information.equals(that.information) : that.information != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (information != null ? information.hashCode() : 0);
        result = 31 * result + (creator != null ? creator.hashCode() : 0);
        return result;
    }
    public abstract void accept(AnnotationVisitor visitor);
}
