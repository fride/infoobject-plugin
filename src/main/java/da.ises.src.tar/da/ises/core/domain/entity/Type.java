package da.ises.core.domain.entity;

/**
 * <p>
 * Class Type ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 26.07.2008
 *         Time: 16:19:14
 */
public class Type {
    private final String type;
    
    public Type(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return type;
    }
    
    public static Type type(String typeName) {
        return new Type(typeName);
    }
}
