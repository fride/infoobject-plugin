package da.ises.core.domain.infoobject;

public class PositionType {
	private final String typeName;

    public PositionType(String typeName) {
        this.typeName = typeName;
    }

    public String getTypeName() {
        return typeName;
    }

    /**
     * 
     * @param name
     * @return
     */
    public static PositionType positionType(String name) {
        return new PositionType(name);
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PositionType)) return false;

        PositionType that = (PositionType) o;

        if (typeName != null ? !typeName.equals(that.typeName) : that.typeName != null) return false;

        return true;
    }

    public int hashCode() {
        return (typeName != null ? typeName.hashCode() : 0);
    }
}
