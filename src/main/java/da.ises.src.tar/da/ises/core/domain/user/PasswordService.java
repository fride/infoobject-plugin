package da.ises.core.domain.user;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: 16.06.2008
 * Time: 14:18:36
 * To change this template use File | Settings | File Templates.
 */
public class PasswordService {

    
}
