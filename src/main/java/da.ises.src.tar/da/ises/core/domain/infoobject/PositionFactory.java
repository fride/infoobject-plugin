package da.ises.core.domain.infoobject;

/**
 * 
 */
public interface PositionFactory {

    /**
     * 
     * @param server
     * @param name
     * @return
     */
    Position createPosition(String server, String name);
}
