package da.ises.core.domain.infoobject;

/**
 * 
 */
public interface InformationObjectFactory {

    /**
     * 
     * @param uri the infos uri.
     * @return a new inormation object or an existing one.
     */
    InformationObject createInformationObject(String uri);
}
