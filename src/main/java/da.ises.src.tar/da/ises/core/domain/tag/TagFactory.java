package da.ises.core.domain.tag;

import org.openrdf.model.URI;
import da.ises.core.infoobject.Tag;

/**
 * 
 */
public interface TagFactory {

    /**
     * 
     * @param rawText
     * @return
     */
    Tag createTag(String rawText);
    
    /**
     * 
     * @param rawText
     * @param positiv
     * @return
     */
    Tagging createTagging(String rawText, boolean positiv, URI tagged);
}
