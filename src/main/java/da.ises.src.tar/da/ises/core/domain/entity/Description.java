package da.ises.core.domain.entity;

import java.util.Locale;

/**
 *
 * An entities description. 
 */
public class Description {

    private final String description;
    private final String locale;

    public Description(String description, String locale) {
        this.description = description;
        this.locale = locale;
    }


    /**
     * 
     * @param str
     * @return
     */
    public static Description description(String str) {
        return str != null ?description(str, Locale.getDefault()) : null;
    }

    public String getLocale() {
        return locale;
    }
    /**
     * 
     * @param str
     * @param locale
     * @return
     */
    public static Description description(String str, Locale locale) {
        return new Description(str, locale.getLanguage());
    }

    public String toString() {
        return description;
    }

    /**
     * 
     * @return
     */
    public String getText() {
        return description;
    }
}
