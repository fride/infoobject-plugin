package da.ises.core.domain.entity;

/**
 * 
 */
public interface Entity extends Auditable{

    /**
     * Get the Entities unique id.
     *
     * @return a unique resource as the id.
     */
    String getId();

    /**
     * 
     * @return
     */
    Version getVersion();

    /**
     * 
     * @param version set the modification date.
     */
    void setVersion(Version version);
}
