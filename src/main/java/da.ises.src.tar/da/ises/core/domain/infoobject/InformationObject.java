package da.ises.core.domain.infoobject;

import da.ises.core.domain.entity.AbstractEntity;
import da.ises.core.domain.entity.Description;
import da.ises.core.domain.entity.MimeType;
import da.ises.core.domain.entity.Title;
import org.openrdf.model.Graph;
import org.openrdf.model.URI;
import org.openrdf.model.impl.GraphImpl;

import java.util.HashSet;
import java.util.Set;

/**
 *
 *
 */
public class InformationObject extends AbstractEntity {
    private Title title;
    private Description description;
    private MimeType mimeType;
    private Long size;
    private Graph metaData = new GraphImpl();
    private Set<String> facetTypes = new HashSet<String>();
    
    /**
     *
     * @param informationuri
     */
    public InformationObject(URI informationuri) {
        setId(informationuri.stringValue());
    }

    

    public InformationObject(String uri) {
        super(uri);
    }

    /**
     * 
     * @param uri the informations uri.
     * @param title a title for the document painted at by uri.
     * @param mimeType the mmetype
     * @param size the size in bytes.
     */
    public InformationObject(String uri, Title title, MimeType mimeType, Long size) {
        super(uri);
        this.title = title;
        this.mimeType = mimeType;
        this.size = size;
    }

 


    public void setTitle(Title title) {
        this.title = title;
    }

    public Title getTitle() {
        return title;
    }

    public MimeType getMimeType() {
        return mimeType;
    }

    public void setMimeType(MimeType mime) {
        this.mimeType = mime;
    }

    public Description getDescription() {
        return description;
    }

    public void setDescription(Description description) {
        this.description = description;
    }

    public Long getSize() {
        return size;
    }

    /**
     *
     * @param size
     */
    public void setSize(Long size) {
        this.size = size;
    }


    public Graph getMetaData() {
        return metaData;
    }

    public void setMetaData(Graph metaData) {
        this.metaData = metaData;
    }

    public Set<String> getFacetTypes() {
        return facetTypes;
    }

    public void setFacetTypes(Set<String> facetTypes) {
        this.facetTypes = facetTypes;
    }


}
