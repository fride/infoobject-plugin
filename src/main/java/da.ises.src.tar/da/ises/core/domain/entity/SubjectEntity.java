package da.ises.core.domain.entity;

import org.openrdf.model.URI;

/**
 *
 * 
 */
public interface SubjectEntity extends Entity{
    /**
     *
     * @return the uri identifying this entity.
     */
    URI getResourceId();
}
