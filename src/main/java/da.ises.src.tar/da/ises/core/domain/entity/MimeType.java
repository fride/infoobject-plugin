package da.ises.core.domain.entity;

/**
 * 
 */
public class MimeType {
    private String mimeType;

    /**
     * 
     * @param mimeType
     */
    public MimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getMimeType() {
        return mimeType;
    }

    /**
     * 
     * @param type
     * @return
     */
    public static MimeType mimeType(String type) {
        return new MimeType(type);
    }

    public String toString() {
        return mimeType;
    }

    /**
     * 
     * @param o
     * @return
     */
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MimeType)) return false;

        MimeType mimeType1 = (MimeType) o;
        return !(mimeType != null ? !mimeType.equals(mimeType1.mimeType) : mimeType1.mimeType != null);

    }

    public int hashCode() {
        return (mimeType != null ? mimeType.hashCode() : 0);
    }
}
