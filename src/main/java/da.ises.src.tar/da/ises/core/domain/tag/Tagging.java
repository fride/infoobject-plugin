package da.ises.core.domain.tag;

import da.ises.core.domain.user.Agent;
import da.ises.core.infoobject.Tag;
import org.openrdf.model.URI;

/**
 * A Relation (document,tag,tagger,(+|-)).
 * 
 */
public class Tagging {

    private Tag tag;
    private boolean positive;
    private Agent agent;
    private URI tagged;

    public Tagging() {
    }

    public Tagging(Tag tag, boolean positive, Agent agent, URI repositoryId) {
        this.tag = tag;
        this.positive = positive;
        this.agent = agent;
        this.tagged = repositoryId;
    }

    public Tag getTag() {
        return tag;
    }

    public void setTag(Tag tag) {
        this.tag = tag;
    }

    public boolean isPositive() {
        return positive;
    }

    public void setPositive(boolean positive) {
        this.positive = positive;
    }

    public Agent getUser() {
        return agent;
    }

    public void setUser(Agent agent) {
        this.agent = agent;
    }

    public URI getTagged() {
        return tagged;
    }

    public void setTagged(URI tagged) {
        this.tagged = tagged;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Tagging)) return false;

        Tagging tagging = (Tagging) o;

        if (positive != tagging.positive) return false;
        if (tagged != null ? !tagged.equals(tagging.tagged) : tagging.tagged != null)
            return false;
        if (tag != null ? !tag.equals(tagging.tag) : tagging.tag != null) return false;
        if (agent != null ? !agent.equals(tagging.agent) : tagging.agent != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (tag != null ? tag.hashCode() : 0);
        result = 31 * result + (positive ? 1 : 0);
        result = 31 * result + (agent != null ? agent.hashCode() : 0);
        result = 31 * result + (tagged != null ? tagged.hashCode() : 0);
        return result;
    }
}
