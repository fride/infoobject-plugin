package da.ises.core.domain;

import da.ises.core.domain.user.Agent;

import java.sql.Timestamp;

/**
 * <p>
 * Class Post ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 07.08.2008
 *         Time: 01:17:28
 */
public class BaseObject {
    private String id;
    private Agent creator;
    private Timestamp creationDate;
    private Timestamp modificationDate;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Agent getCreator() {
        return creator;
    }

    public void setCreator(Agent creator) {
        this.creator = creator;
    }

    public Timestamp getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Timestamp creationDate) {
        this.creationDate = creationDate;
    }

    public Timestamp getModificationDate() {
        return modificationDate;
    }

    public void setModificationDate(Timestamp modificationDate) {
        this.modificationDate = modificationDate;
    }
}
