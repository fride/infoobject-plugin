package da.ises.core.domain.repository;

import da.ises.core.domain.infoobject.*;
import da.ises.core.infoobject.Tag;

import java.util.List;
import java.util.Collection;

/**
 * <p>
 * Repository for InformationObjects and their annotations.
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 26.07.2008
 *         Time: 16:28:55
 */
public interface InformationObjectRepository {

    
    /**
     * Get an information and all its annotations  with the provided uri.
     * @param uri the inormation objects uri.
     * @return an information object.
     */
    InformationObjectPosts get(String uri);

    /**
     * Create or saves a new information object.
     * 
     * @param object the object to update or save
     * @return
     */
    InformationObject set(InformationObject object);

    /**
     *
     * @param uri the infos uri.
     * @return an information object or null if none is known.
     */
    InformationObject getInformation(String uri);

    /**
     * 
     * @param uri the infos uri.
     * @param position the position.
     * @return
     */
    PositionAnnotation set(String uri, PositionAnnotation position);

    /**
     * 
     * @param position
     * @return
     */
    boolean remove(PositionAnnotation position);
    /**
     *
     * @param uri
     * @param tagging
     * @return
     */
    TagAnnotation set(String uri, TagAnnotation tagging);


    boolean remove(TagAnnotation position);
    /**
     * 
     * @return
     */
    List<InformationObject> list();



    /**
     *
     * @param tags
     * @return
     */
    List<InformationObjectPosts> findByTags(Collection<String> tags);


    /**
     * 
     * @param position
     * @return
     */
    List<InformationObjectPosts> findByPosition(Position position);

    /**
     * 
     * @return
     */
    List<Tag> loadTags();

}
