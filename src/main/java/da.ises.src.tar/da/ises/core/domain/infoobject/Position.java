package da.ises.core.domain.infoobject;

import da.ises.core.domain.entity.Title;
import da.ises.core.infoobject.ObjectName;

/**
 *
 * 
 */
public class Position   {
    private final ObjectName name;
    private PositionType type;
    private Title title;


    public Position(ObjectName name, PositionType type) {
        this.name = name;
        this.type = type;
    }

    public void setType(PositionType type) {
        this.type = type;
    }

    public void setTitle(Title title) {
        this.title = title;
    }


    public ObjectName getPositionName() {
        return name;
    }

    public PositionType getPositionType() {
        return type;
    }

    public Title getPositionTitle() {
        return title;
    }


    
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Position)) return false;

        Position position = (Position) o;

        if (name != null ? !name.equals(position.name) : position.name != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (name != null ? name.hashCode() : 0);
        return result;
    }
}
