package da.ises.core.domain.infoobject;

/**
 * <p>
 * Class AnnotationVisitor ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 27.07.2008
 *         Time: 12:08:06
 */
public interface AnnotationVisitor {

    void visitPosition(PositionAnnotation position);
    
    void visitTagging(TagAnnotation tag);
}
