package da.ises.core.domain.infoobject;

import da.ises.core.domain.entity.Auditable;
import da.ises.core.domain.entity.Description;
import da.ises.core.domain.entity.Title;
import da.ises.core.domain.entity.Version;
import da.ises.core.infoobject.Tag;
import da.ises.core.domain.user.Agent;

import java.util.HashMap;
import java.util.Map;

/**
 *
 *
 */
public class PositionAnnotation extends InformationObjectAnnotation implements Auditable {
    private InformationObject information;
    private String nodeName;
    private String nodeServer;
    private Title title; // will be shared for all....
    private Description description; // unique for every.....
    private Map<Tag, Boolean> tags = new HashMap<Tag, Boolean>();
    private Version version;
    

    /**
     * @param information
     * @param creator
     */
    public PositionAnnotation(InformationObject information, Agent creator) {
        super(information, creator);
    }


    /**
     * 
     * @return
     */
    public InformationObject getInformation() {
        return information;
    }

    public void setInformation(InformationObject information) {
        this.information = information;
    }


    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getNodeServer() {
        return nodeServer;
    }

    public void setNodeServer(String nodeServer) {
        this.nodeServer = nodeServer;
    }

    public Title getTitle() {
        return title;
    }

    public void setTitle(Title title) {
        this.title = title;
    }

    public Description getDescription() {
        return description;
    }

    public void setDescription(Description description) {
        this.description = description;
    }

    public Map<Tag, Boolean> getTags() {
        return tags;
    }

    public void setTags(Map<Tag, Boolean> tags) {
        this.tags = tags;
    }

    

    public Version getVersion() {
        return version;
    }

    public void setVersion(Version version) {
        this.version = version;
    }
    
    public void accept(AnnotationVisitor visitor){
        visitor.visitPosition(this);        
    }
}
