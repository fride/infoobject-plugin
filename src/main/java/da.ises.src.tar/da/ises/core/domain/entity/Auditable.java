package da.ises.core.domain.entity;

/**
 * Created by IntelliJ IDEA.
 * User: janfriderici
 * Date: Jul 6, 2008
 * Time: 5:59:46 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Auditable {

    Version getVersion();

    void setVersion(Version version);
}
