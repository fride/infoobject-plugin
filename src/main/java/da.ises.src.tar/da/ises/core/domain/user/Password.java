package da.ises.core.domain.user;

import da.ises.core.util.Digest;

/**
 * 
 */
public class Password {
    private final String password;


    public Password(String password) {
        this.password = Digest.sha1(password);
    }

    public String getPassword() {
        return password;
    }

    public static Password password(String pwd) {
        return new Password(pwd);
    }
}
