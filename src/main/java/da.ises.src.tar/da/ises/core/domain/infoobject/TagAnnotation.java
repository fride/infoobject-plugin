package da.ises.core.domain.infoobject;

import da.ises.core.domain.entity.Auditable;
import da.ises.core.domain.entity.Description;
import da.ises.core.domain.entity.Title;
import da.ises.core.domain.entity.Version;
import da.ises.core.infoobject.Tag;
import da.ises.core.domain.user.Agent;
import org.openrdf.model.Graph;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 
 * A Post from a user stating that a given information is at a given position.
 * 
 */
public class TagAnnotation extends InformationObjectAnnotation implements Auditable {

    private Graph graph;
    private Title title;
    private Description description;
    private Map<Tag, Boolean> tags = new HashMap<Tag, Boolean>();
    private Version version;

 
    /**
     * 
     * @param object
     * @param title
     * @param description
     * @param agent
     */
    public TagAnnotation(InformationObject object, Title title, Description description, Agent agent) {
        super (object, agent);
        this.title = title;
        this.description = description;
    }

    /**
     * get the Posts title
     * @return the Posts tite.
     */
    public Title getTitle() {
        return title;
    }

    public void setTitle(Title title) {
        this.title = title;
    }

    public Description getDescription() {
        return description;
    }

    public void setDescription(Description description) {
        this.description = description;
    }

    /**
     * Get the rdf grph for the post.
     * @return
     */
    public Graph getGraph() {
        return graph;
    }

    /**
     * Set the rdf graph for the post.
     * @param graph
     */
    public void setGraph(Graph graph) {
        this.graph = graph;
    }

    /**
     * Set tags.
     * @param tags
     */
    public void setTags(Map<Tag, Boolean> tags) {
        this.tags = tags;
    }

    public Map<Tag, Boolean> getTags(){
        return tags;
    }

    public Version getVersion() {
        return version;
    }

    public void setVersion(Version version) {
        this.version = version;
    }

    /**
     * 
     * @param visitor
     */
    public void accept(AnnotationVisitor visitor) {
        visitor.visitTagging(this);
    }
    
    public boolean hasTag(String normalizedString){
        for (Tag tag:this.tags.keySet()){
            if (tags.get(tag) && tag.getRawValue().equals(normalizedString)) return true;
        }
        return false;
    }

    public Set<String> getPositiveTags(){
        final HashSet<String> positives = new HashSet<String>();
        for (Map.Entry<Tag,Boolean> tag:tags.entrySet()){
            if (tag.getValue()){
                positives.add(tag.getKey().getNormalizedValue());
            }
        }
        return positives;
    }

    public Set<String> getNegativeTags(){
        final HashSet<String> positives = new HashSet<String>();
        for (Map.Entry<Tag,Boolean> tag:tags.entrySet()){
            if (!tag.getValue()){
                positives.add(tag.getKey().getNormalizedValue());
            }
        }
        return positives;
    }
    /**
     *
     * @param normalizedString
     * @return true if the tag ist tgged negative!
     */
    public boolean hasNotTag(String normalizedString){
        for (Tag tag:this.tags.keySet()){
            if (!tags.get(tag) && tag.getRawValue().equals(normalizedString)) return true;
        }
        return false;
    }
}
