package da.ises.core.domain.repository;

import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.TagAnnotation;
import da.ises.core.domain.infoobject.PositionAnnotation;
import da.ises.core.domain.user.Agent;

/**
 * <p>
 * Class InformationObjectPost ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 27.07.2008
 *         Time: 14:38:21
 */
public class InformationObjectPost {
    private InformationObject information;
    private TagAnnotation tagging;
    private PositionAnnotation position;

    public InformationObject getInformation() {
        return information;
    }

    public void setInformation(InformationObject information) {
        this.information = information;
    }

    public Agent getCreator() {
        return position != null ? position.getCreator() :  null;
    }


    public TagAnnotation getTagging() {
        return tagging;
    }

    public void setTagging(TagAnnotation tagging) {
        this.tagging = tagging;
    }

    public PositionAnnotation getPosition() {
        return position;
    }

    public void setPosition(PositionAnnotation position) {
        this.position = position;
    }
}
