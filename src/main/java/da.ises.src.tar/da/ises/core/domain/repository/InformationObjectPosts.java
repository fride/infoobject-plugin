package da.ises.core.domain.repository;

import da.ises.core.domain.infoobject.InformationObject;
import da.ises.core.domain.infoobject.TagAnnotation;
import da.ises.core.domain.infoobject.PositionAnnotation;
import da.ises.core.infoobject.ObjectName;
import da.ises.core.domain.user.Agent;

import java.util.Map;
import java.util.HashMap;

import net.sf.magicmap.client.utils.Pair;

/**
 * <p>
 * Contains multiple Annotatiosn from posts for an information object.
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 27.07.2008
 *         Time: 11:58:09
 */
public class InformationObjectPosts {
    private InformationObject infoobject;
    private Map<Agent, TagAnnotation> tags = new HashMap<Agent, TagAnnotation>();
    private Map<Pair<Agent, ObjectName>, PositionAnnotation> positions = new HashMap<Pair<Agent, ObjectName>, PositionAnnotation>();
    

    /**
     * 
     * @param infoobject
     */
    public InformationObjectPosts(InformationObject infoobject) {
        this.infoobject = infoobject;
    }

    public InformationObjectPosts() {
    }

    public InformationObject getInfoobject() {
        return infoobject;
    }

    public void setInfoobject(InformationObject infoobject) {
        this.infoobject = infoobject;
    }

    public Map<Agent, TagAnnotation> getTags() {
        return tags;
    }

    public void setTags(Map<Agent, TagAnnotation> tags) {
        this.tags = tags;
    }

    public Map<Pair<Agent, ObjectName>, PositionAnnotation> getPositions() {
        return positions;
    }

    public void setPositions(Map<Pair<Agent, ObjectName>, PositionAnnotation> positions) {
        this.positions = positions;
    }
    public boolean isEmpty(){
        return infoobject == null;
    }

}
