package da.ises.core.notification;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 *
 */
public class NotificationQueue {
    BlockingQueue<Message> messageQueue = new LinkedBlockingQueue<Message>();


    
}
