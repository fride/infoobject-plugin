package da.ises.core.notification;

/**
 *
 * 
 */
public interface MessageConsumer {
}
