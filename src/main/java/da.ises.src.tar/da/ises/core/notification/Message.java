package da.ises.core.notification;

/**
 * 
 */
public class Message {
    private String message;
    private Object value;

    /**
     *
     * @param message
     * @param value
     */
    public Message(String message, Object value) {
        this.message = message;
        this.value = value;
    }

    public String getMessage() {
        return message;
    }

    public Object getValue() {
        return value;
    }
}
