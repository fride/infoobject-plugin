package da.ises.core.extractor;

import da.ises.magicmap.ui.util.HtmlSaxParserFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: Jul 10, 2008
 * Time: 5:16:53 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractHtmlExtractor {

    private final List<ExtractorListener> listeners = Collections.synchronizedList(new LinkedList<ExtractorListener>());

    
    /**
     * 
     * @param dataSource
     * @return
     * @throws DocumentException
     * @throws IOException
     */
    protected Document getDocument(DataSource dataSource) throws DocumentException, IOException {
        SAXReader saxReader = new SAXReader(HtmlSaxParserFactory.getSaxParser());
        saxReader.setIgnoreComments(true);
        saxReader.setValidation(false);
        return saxReader.read(dataSource.getUrl());
    }

    public void addExtractorListener(ExtractorListener l) {
        this.listeners.add(l);
    }

    public void removeExtractorListener(ExtractorListener l) {
        this.listeners.remove(l);
    }

    public ExtractorListener[] getExtractorListeners() {
        return listeners.toArray(new ExtractorListener[listeners.size()]);
    }
    
}
