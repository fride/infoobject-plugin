package da.ises.core.extractor;

import da.ises.core.domain.infoobject.InformationObject;

/**
 * Created by IntelliJ IDEA.
 * User: jfr
 * Date: Jul 13, 2008
 * Time: 1:07:34 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ExtractorListener {

    void extractionSarted(InformationObject object);
    void extractionFinished(InformationObject object);
    void extractionFailed(InformationObject object);
}
