package da.ises.core.extractor.html;

import da.ises.core.extractor.DataSource;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * <p>
 * Class HtmlDataSource ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 02.08.2008
 *         Time: 22:27:39
 */
public class HtmlDataSource implements DataSource.DataSourceStrategy{


    static HttpClient httpClient = new HttpClient(new MultiThreadedHttpConnectionManager());
    private URL url;
    private String mimeType;
    private byte[] data;
    
    public void setURL(URL url) {
        this.url = url;
    }

    public String getMimeType() throws IOException {
        if (mimeType == null){
            GetMethod method = new GetMethod(url.toString());
            int result = httpClient.executeMethod(method);
            method.getResponseContentLength();
        }
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public InputStream getInputStream() throws IOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Long getContentsSize() throws IOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getResponseCode() throws IOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
