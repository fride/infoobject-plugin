package da.ises.core.extractor;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;


/**
 * A source of Data. It has mime types etc...
 *
 */
public class DataSource {
	private final URL url;
	private final Log log = LogFactory
			.getLog("plaim");
	private String contentType;
	private String serverResponse;

	private Long contentsSize;
	private Date headerDate;
	private Date lastModified;
	private String responseCode;
	private boolean isOpen;
	private URLConnection connection;
	private byte[] data = null;
	private String encoding;
	private String mimeType;
	private HttpURLConnection httpConnection;

    public static interface DataSourceStrategy{
        public void setURL(URL url);
        public String getMimeType() throws IOException;
        public InputStream getInputStream() throws IOException;
        public Long getContentsSize()  throws IOException;
        public String getResponseCode()  throws IOException; 

    }
    /**
	 *
	 * @param url
	 */
	public DataSource(URL url) {
		this.url =url;
	}

	/**
	 *
	 * @return
	 * @throws java.io.IOException
	 */
	public String getContentType() throws IOException {
		if (!isOpen)open();
		return contentType;
	}

	/**
	 *
	 * @return
	 * @throws IOException
	 */
	public InputStream getInputStream() throws IOException{
		return new ByteArrayInputStream(getData());
	}

	/**
	 *
	 * @return
	 * @throws IOException
	 */
	public String getEncoding() throws IOException {
		if (!isOpen)open();
		return encoding;
	}

	public synchronized void dispose() throws IOException {
		if (isOpen) {
			if (httpConnection != null) {
				httpConnection.disconnect();
				httpConnection = null;
			}
			connection = null;
			isOpen = true;
		}
	}
	/**
	 *
	 * @return
	 * @throws IOException
	 */
	public synchronized byte[] getData() throws IOException {
		if (data == null){
			if (!isOpen) open();
			log.info("Getting data objects bytes....: " + url.toString());
			InputStream inputStream = connection.getInputStream();
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buffer = new byte[512];
			while ((inputStream.read(buffer)) > 0){
				out.write(buffer);
			}
			data = out.toByteArray();
			log.info("data objects size:" + data.length / 1024);
		}
		return data;
	}

	/**
	 *
	 * @throws IOException
	 */
	public void open() throws IOException {
		log.info("Opening data object: " + url.toString());
		connection = url.openConnection();

		if (connection instanceof HttpURLConnection) {
			this.httpConnection = (HttpURLConnection) connection;
			httpConnection.setRequestProperty("user-agent",
					"plugin/infoobject");
			httpConnection.setRequestProperty("connection", "Keep-Alive");
			httpConnection.setRequestMethod("GET");
			httpConnection.setAllowUserInteraction(false);
			httpConnection.setDoOutput(true);
			httpConnection.setDoInput(true);
			httpConnection.setUseCaches(true);
		}
		connection.connect();

		headerDate = new Date(connection.getDate());
		lastModified = new Date(connection.getLastModified());
		contentType = connection.getContentType();
		if (httpConnection != null) {
			responseCode = String.valueOf(httpConnection
					.getResponseCode());
			serverResponse = httpConnection.getResponseMessage();
		}
		this.contentsSize = new Long(connection.getContentLength());
		this.encoding = connection.getContentEncoding();
		isOpen = true;
	}

	public String getMimeType() throws IOException {
		if (mimeType == null){
			mimeType = getContentType().contains(";") ?
					   getContentType().substring(0, getContentType().indexOf(";")) :
					   getContentType();
		}
		return mimeType;
	}

	public URL getUrl() {
		return url;
	}


	public String getServerResponse() {
		return serverResponse;
	}

	public Long getContentsSize() {
		return contentsSize;
	}

	public Date getHeaderDate() {
		return headerDate;
	}

	public Date getLastModified() {
		return lastModified;
	}

	public String getResponseCode() {
		return responseCode;
	}

}
