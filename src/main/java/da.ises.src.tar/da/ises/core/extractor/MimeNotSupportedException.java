package da.ises.core.extractor;


/**
 * Created by IntelliJ IDEA.
 * User: x_fridej
 * Date: 21.05.2008
 * Time: 11:29:26
 * To change this template use File | Settings | File Templates.
 */
public class MimeNotSupportedException extends ExtractorException{

	public MimeNotSupportedException(String reason) {
		super(reason);
	}
}
