package da.ises.core.extractor;

import java.io.IOException;


/**
 *
 */
public class ExtractorException extends IOException {

	public ExtractorException() {
	}

	public ExtractorException(String s) {
		super(s);
	}
}
