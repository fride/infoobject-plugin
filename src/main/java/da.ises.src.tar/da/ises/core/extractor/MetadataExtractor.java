package da.ises.core.extractor;

/**
 * <p>
 * Class MetadataExtractor ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 02.08.2008
 *         Time: 14:20:16
 */
public interface MetadataExtractor {

    /**
     * 
     * @param uri
     * @return a result.
     */
    MetadataExtractorResult extract(String uri);
}
