package da.ises.core.extractor;

import org.openrdf.model.Graph;
import org.openrdf.model.impl.GraphImpl;

import java.sql.Timestamp;


/**
 * <p>
 * Class MetadataExtractorResult ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 02.08.2008
 *         Time: 14:21:05
 */
public class MetadataExtractorResult {

    private Graph metadataGraph = new GraphImpl();
    private String informationUri;
    private Exception error;
    private Timestamp exractionTime;


    public MetadataExtractorResult(String informationUri, Timestamp exractionTime) {
        this.informationUri = informationUri;
        this.exractionTime = exractionTime;
    }

    public void setError(Exception ex){
        this.error = ex;
    }
    public Exception getError() {
        return error;
    }

    public Timestamp getExractionTime() {
        return exractionTime;
    }

    public Graph getMetadataGraph() {
        return metadataGraph;
    }

    public String getInformationUri() {
        return informationUri;
    }
}
