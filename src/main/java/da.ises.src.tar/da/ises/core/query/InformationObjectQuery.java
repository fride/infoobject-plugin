package da.ises.core.query;

import da.ises.core.domain.infoobject.TagAnnotation;

/**
 * 
 */
public interface InformationObjectQuery extends Query<TagAnnotation>{


    /**
     *
     * @param userids
     * @return
     */
    InformationObjectQuery madeByUsers(String... userids);

    /**
     *
     * @param tags
     * @return
     */
    InformationObjectQuery matchingTags(String... tags);

    /**
     * Todo does it make senese!?
     * @param tags
     * @return
     */
    InformationObjectQuery notMatchingTags(String... tags);

    /**
     * 
     * @param filesize
     * @return
     */
    InformationObjectQuery greaterThan(Long filesize);

    /**
     *
     * @param filesize
     * @return
     */
    InformationObjectQuery smallerThan(Long filesize);

    /**
     * 
     * @param type
     * @return
     */
    InformationObjectQuery withMimeType(String type);

}
