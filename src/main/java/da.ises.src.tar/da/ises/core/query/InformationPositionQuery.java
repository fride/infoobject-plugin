package da.ises.core.query;

import da.ises.core.domain.infoobject.PositionAnnotation;

import java.util.List;

/**
 * 
 */
public interface InformationPositionQuery extends Query<PositionAnnotation>{


    /**
     *
     * @param userids
     * @return
     */
    InformationPositionQuery madeByUsers(String... userids);

    /**
     *
     * @param tags
     * @return
     */
    InformationPositionQuery matchingTags(String... tags);


    /**
     * An or Query.
     * @param nodes the nodes near.
     * @return
     */
    InformationPositionQuery nearNodes(String... nodes);
    /**
     *
     *
     * @return
     */
    List<PositionAnnotation> list();

    /**
     *
     * @return
     */
    PositionAnnotation unique();
    
}
