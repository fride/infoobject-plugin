package da.ises.core.query;

import java.util.List;

/**
 * 
 */
public interface Query<T> {


    /**
     *
     * @param userids
     * @return
     */
    Query madeByUsers(String... userids);

    /**
     *
     * @param tags
     * @return
     */
    Query matchingTags(String... tags);

    /**
     * Todo does it make senese!?
     * @param tags
     * @return
     */
    Query notMatchingTags(String... tags);

    /**
     *
     * @return
     */
    List<T> list();

    /**
     *
     * @return
     */
    T unique();
}
