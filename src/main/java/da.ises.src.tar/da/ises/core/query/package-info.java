/**
 * Package for query and ranking. Contains API Definition to query
 * for lists of ranked objects
 */
package da.ises.core.query;