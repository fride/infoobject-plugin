package org.infoobject.core.crawl;

import java.io.IOException;

/**
 * <p>
 * Class ExtractorException ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 10.08.2008
 *         Time: 01:36:05
 */
public class ExtractorException extends IOException {
    public ExtractorException() {
    }
    public ExtractorException(String s) {
        super(s);
    }
}
