package org.infoobject.core.util;

/**
 * <p>
 * Class VetoableAbstractModel ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 09.08.2008
 *         Time: 21:51:33
 */
public class VetoableAbstractModel {
}
