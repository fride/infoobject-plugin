package org.infoobject.core.infoobject.ui.util;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.FilterList;
import ca.odell.glazedlists.impl.ReadOnlyList;
import ca.odell.glazedlists.matchers.MatcherEditor;
import ca.odell.glazedlists.util.concurrent.Lock;
import net.sf.magicmap.client.interfaces.NodeModelListener;
import net.sf.magicmap.client.model.node.Node;
import org.infoobject.core.infoobject.domain.support.AbstractInformationObjectModel;
import org.infoobject.core.infoobject.domain.support.DefaultInformationObject;
import org.infoobject.magicmap.node.model.InformationObjectNode;
import org.infoobject.magicmap.node.model.InformationObjectNodeModel;

import java.util.HashSet;
import java.util.Set;

/**
 * <p>
 * Class InformationObjectListFactory ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 12.08.2008
 *         Time: 22:09:29
 */
public class InformationObjectNodeListFactory  {

    private Set<org.infoobject.core.infoobject.domain.InformationObject> unsavedObjects = new HashSet<org.infoobject.core.infoobject.domain.InformationObject>();

    private EventList<org.infoobject.core.infoobject.domain.InformationObject> informationObjects = new BasicEventList<org.infoobject.core.infoobject.domain.InformationObject>();

    private EventList<Node> nodeList = new BasicEventList<Node>();
    private final InformationObjectNodeModel nodeModel;
    private final AbstractInformationObjectModel informationObjectModel;

    public InformationObjectNodeListFactory(InformationObjectNodeModel nodeModel, AbstractInformationObjectModel informationObjectModel) {
        this.nodeModel = nodeModel;
        this.informationObjectModel = informationObjectModel;
        nodeModel.addNodeModelListener(new NodeModelListener() {
            public void nodeAddedEvent(Node node) {
                if (node.isPhysical()) {
                    add(node);
                } else if (node instanceof InformationObjectNode) {
                    add(((InformationObjectNode)node).getInformationObject());
                }
            }

            public void nodeUpdatedEvent(Node node, int i, Object o) {
                //To change body of implemented methods use File | Settings | File Templates.
            }

            public void nodeRemovedEvent(Node node) {
                if (node.isPhysical()) {
                    remove(node);
                } else if (node instanceof InformationObjectNode) {
                    //remove(((InformationObjectNode)node).getInformationObject());
                }
            }
        });
    }

    public FilterList<Node> getNodeList(MatcherEditor<Node> matcher) {
        return new FilterList<Node>(getNodeList(),matcher);
    }

    public FilterList<org.infoobject.core.infoobject.domain.InformationObject> getInformationObjectList(MatcherEditor<org.infoobject.core.infoobject.domain.InformationObject> matcher) {
        return new FilterList<org.infoobject.core.infoobject.domain.InformationObject>(getInformationObjectList(),matcher);
    }

    public ReadOnlyList<Node> getNodeList() {
        return new ReadOnlyList<Node>(nodeList);
    }

    public ReadOnlyList<org.infoobject.core.infoobject.domain.InformationObject> getInformationObjectList() {
        return new ReadOnlyList<org.infoobject.core.infoobject.domain.InformationObject>(informationObjects);
    }



    public boolean isSaved(org.infoobject.core.infoobject.domain.InformationObject object) {
        return unsavedObjects.contains(object);
    }

    /**
     *
     * @param informationObject
     */
    protected void add(DefaultInformationObject informationObject) {
        Lock lock = this.informationObjects.getReadWriteLock().writeLock();
        try {
            lock.lock();
            if (!informationObjects.contains(informationObject)){

                informationObjects.add(informationObject);
                unsavedObjects.remove(informationObject);
            }

        } finally {
            lock.unlock();
        }
    }

    protected void remobe(org.infoobject.core.infoobject.domain.InformationObject informationObject) {
        Lock lock = this.informationObjects.getReadWriteLock().writeLock();
        try {
            lock.lock();
            if (!informationObjects.contains(informationObject)){

                informationObjects.remove(informationObject);
                unsavedObjects.remove(informationObject);
            }
        } finally {
            lock.unlock();
        }
    }

    protected void remove(Node node) {
        Lock lock = this.nodeList.getReadWriteLock().writeLock();
        try {
            lock.lock();
            if (!nodeList.contains(node) && node.isPhysical()) {
                nodeList.remove(node);
            }
        } finally {
            lock.unlock();
        }
    }
    protected void add(Node node) {
        Lock lock = this.nodeList.getReadWriteLock().writeLock();
        try {
            lock.lock();
            if (!nodeList.contains(node)) {
                nodeList.add(node);
            }
        } finally {
            lock.unlock();
        }
    }

    /**
     *
     * @param informationObject
     */
    public void addUnsaved(DefaultInformationObject informationObject) {
        this.unsavedObjects.add(informationObject);
        add(informationObject);
    }
}
