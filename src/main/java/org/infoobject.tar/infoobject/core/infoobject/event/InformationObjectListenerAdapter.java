package org.infoobject.core.infoobject.event;

/**
 * <p>
 * Class InformationObjectListenerAdapter ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 10.08.2008
 *         Time: 22:15:39
 */
public class InformationObjectListenerAdapter implements InformationObjectListener{
    public void onTagging(TaggingEvent tagging) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void onTaggingRemoved(TaggingEvent tagging) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void onObjectLinking(ObjectLinkingEvent linEvent) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void onObjectLinkingRemoved(ObjectLinkingEvent linEvent) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void onMetadata(InformationMetadataEvent mEvent) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void onMetadataRemoved(InformationMetadataEvent mEvent) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
