package org.infoobject.core.relation.application;

import org.infoobject.magicmap.node.model.InformationObjectNodeGraph;

/**
 * <p>
 * Class RelationManager ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 09.08.2008
 *         Time: 13:44:43
 */
public class RelationManager {

    private final InformationObjectNodeGraph graph;

    public RelationManager(InformationObjectNodeGraph graph) {
        this.graph = graph;
    }

    
}
