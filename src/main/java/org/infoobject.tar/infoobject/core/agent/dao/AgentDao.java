package org.infoobject.core.agent.dao;

/**
 * <p>
 * Class AgentDao ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 09.08.2008
 *         Time: 00:28:08
 */
public interface AgentDao {
}
