package org.infoobject.magicmap.node.model;

import net.sf.magicmap.client.model.node.INodeModel;
import org.infoobject.magicmap.node.model.InformationObjectNode;
import org.infoobject.magicmap.node.model.InformationObjectNodeGraph;

/**
 * <p>
 * Class InformationNodeModel ZUSAMMENFASSUNG
 * </p>
 * <p>
 * DETAILS
 * </p>
 *
 * @author Jan Friderici
 *         Date: 09.08.2008
 *         Time: 17:59:51
 */
public interface InformationObjectNodeModel extends INodeModel {

    InformationObjectNode findInformationNode(String uri);
    
    InformationObjectNodeGraph getInformationObjectNodeGraph();
}
